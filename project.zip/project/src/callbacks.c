#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include <stdlib.h>
char RF[30];
char gtype[30], gmarque[30], gval[30], gvali[30], gvals[30], gdate[30], getat[30];
void on_YBbutton_LC_A_clicked(GtkWidget *objet,
                              gpointer user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(objet, "window_GC");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(objet, "window_AC");
  fenetre_afficher = create_window_AC();
  gtk_widget_show(fenetre_afficher);
}

void on_YBbutton_LC_M_clicked(GtkWidget *objet,
                              gpointer user_data)
{
  CAPTEUR c;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *dialog2;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *humidite;
  GtkWidget *comp1;
  GtkWidget *comp2;
  GtkWidget *bonne;
  GtkWidget *panne;
  GtkWidget *window_GC = lookup_widget(objet, "window_GC");
  GtkWidget *window_MC = lookup_widget(objet, "window_MC");
  window_MC = create_window_MC();
  gtk_widget_hide(window_GC);
  gtk_widget_show(window_MC);

  comp1 = lookup_widget(window_MC, "YBlabel_M_SB_V");
  comp2 = lookup_widget(window_MC, "YBlabel_M_RC_V");
  Reference = lookup_widget(window_MC, "YBentry_M_RC");
  combobox = lookup_widget(window_MC, "YBcombobox_M_MC");
  temperature = lookup_widget(window_MC, "YBradiobutton_M_T");
  humidite = lookup_widget(window_MC, "YBradiobutton_M_H");
  bonne = lookup_widget(window_MC, "YBradiobutton_M_B");
  panne = lookup_widget(window_MC, "YBradiobutton_M_P");
  Valeur = lookup_widget(window_MC, "YBspinbutton_M_V");
  Val_Inf = lookup_widget(window_MC, "YBspinbutton_M_VI");
  Val_Sup = lookup_widget(window_MC, "YBspinbutton_M_VS");

  Jour = lookup_widget(window_MC, "YBspinbutton_M_J");
  Mois = lookup_widget(window_MC, "YBspinbutton_M_M");
  Annee = lookup_widget(window_MC, "YBspinbutton_M_AN");

  gtk_entry_set_text(GTK_ENTRY(Reference), RF);
  if (strcmp(gmarque, "a") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 0);
  }
  else if (strcmp(gmarque, "b") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 1);
  }
  else if (strcmp(gmarque, "c") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 2);
  }
  else if (strcmp(gmarque, "d") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 3);
  }

  if ((strcmp(gtype, "Temperature") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(temperature), 1);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(humidite), 0);
  }
  else if ((strcmp(gtype, "Humidite") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(temperature), 0);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(humidite), 1);
  }
  if ((strcmp(getat, "Bonne") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(bonne), 1);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(panne), 0);
  }
  else if ((strcmp(getat, "Panne") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(bonne), 0);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(panne), 1);
  }

  sscanf(gdate, "%d/%d/%d", &c.d.Jour, &c.d.Mois, &c.d.Annee);
  sscanf(gval, "%f", &c.v.Valeur);
  sscanf(gvali, "%f", &c.v.Val_Inf);
  sscanf(gvals, "%f", &c.v.Val_Sup);

  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Valeur), c.v.Valeur);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Val_Inf), c.v.Val_Inf);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Val_Sup), c.v.Val_Sup);

  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Jour), c.d.Jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Mois), c.d.Mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Annee), c.d.Annee);
}

void on_YBbutton_LC_S_clicked(GtkButton *button,
                              gpointer user_data)
{
GtkWidget* p ,*afficher,*w1,*pQuestion;
afficher = lookup_widget(button, "window_GC");
GtkWidget  *YBtreeview_LC = lookup_widget(afficher, "YBtreeview_LC");

pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cet capteur ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

  suppression(RF);
	gtk_widget_destroy(pQuestion);
  affichage(YBtreeview_LC);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}
}

void on_YBbutton_LC_AFF_clicked(GtkButton *button,
                                gpointer user_data)
{
  GtkWidget *fenetre_afficher;
  GtkWidget *YBtreeview_LC;

  fenetre_afficher = lookup_widget(button, "window_GC");
  YBtreeview_LC = lookup_widget(fenetre_afficher, "YBtreeview_LC");
  gtk_widget_show(fenetre_afficher);
  affichage(YBtreeview_LC);
}

void on_YBbutton_LC_R_clicked(GtkButton *button,
                              gpointer user_data)
{
  CAPTEUR c;
  char RF[30];
  GtkWidget *window_GC;
  GtkWidget *YBentry_LC_R;
  GtkWidget *YBtreeview_LC;
  FILE *f;
  FILE *f2;

  window_GC = lookup_widget(button, "window_GC");
  YBentry_LC_R = lookup_widget(button, "YBentry_LC_R");
  strcpy(RF, gtk_entry_get_text(GTK_ENTRY(YBentry_LC_R)));
  f = fopen("capteurs.txt", "r");

  if (f != NULL)
  {
    while (fscanf(f, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
    {
      f2 = fopen("recherche.txt", "a+");
      if (f2 != NULL)
      {
        if ((strcmp(c.Ref_Cap, RF) == 0))
        {
          fprintf(f2, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat);
        }
        YBtreeview_LC = lookup_widget(window_GC, "YBtreeview_LC");
        recherche(YBtreeview_LC);
        fclose(f2);
      }
    }
    fclose(f);
  }
  remove("recherche.txt");
}

void on_YBbutton_LC_RE_clicked(GtkButton *button,
                               gpointer user_data)
{
}

void on_YBtreeview_LC_row_activated(GtkTreeView *YBtreeview_LC,
                                    GtkTreePath *path,
                                    GtkTreeViewColumn *column,
                                    gpointer user_data)
{
  CAPTEUR c;
  GtkTreeIter iter;
  gchar *reference;
  gchar *type;
  gchar *dt;
  gchar *marque;
  gchar *val;
  gchar *vali;
  gchar *vals;
  gchar *etat;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *bonne;
  GtkWidget *panne;
  GtkWidget *humidite;
  GtkWidget *window_GC = lookup_widget(YBtreeview_LC, "window_GC");
  GtkTreeModel *model = gtk_tree_view_get_model(YBtreeview_LC);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &reference, 1, &marque, 2, &type, 3, &dt, 4, &val, 5, &vali, 6, &vals, 7, &etat, -1);
    strcpy(RF, reference);
    strcpy(gmarque, marque);
    strcpy(gtype, type);
    strcpy(gdate, dt);
    strcpy(gval, val);
    strcpy(gvali, vali);
    strcpy(gvals, vals);
    strcpy(getat, etat);
  }
}

void on_YBbutton_A_A_clicked(GtkButton *button,
                             gpointer user_data)
{
  CAPTEUR c;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *dialog1;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *bonne;
  GtkWidget *panne;
  GtkWidget *humidite;
  GtkWidget *comp,*comp4;
  GtkWidget *Ref_Cap;
  int cond, cond1;
  char msg[50], *markup;
  const char *format;

  Ref_Cap = lookup_widget(button, "YBlabel_A_RC_CV");
  comp = lookup_widget(button, "YBlabel_A_SB_V");
  comp4 = lookup_widget(button, "YBlabel_A_P");
  Reference = lookup_widget(button, "YBentry_A_RC");
  combobox = lookup_widget(button, "YBcombobox_A_MC");
  temperature = lookup_widget(button, "YBradiobutton_A_T");
  humidite = lookup_widget(button, "YBradiobutton_A_H");
  bonne = lookup_widget(button, "YBradiobutton_A_B");
  panne = lookup_widget(button, "YBradiobutton_A_P");
  Valeur = lookup_widget(button, "YBspinbutton_A_V");
  Val_Inf = lookup_widget(button, "YBspinbutton_A_VI");
  Val_Sup = lookup_widget(button, "YBspinbutton_A_VS");

  Jour = lookup_widget(button, "YBspinbutton_A_J");
  Mois = lookup_widget(button, "YBspinbutton_A_M");
  Annee = lookup_widget(button, "YBspinbutton_A_AN");

  strcpy(c.Ref_Cap, gtk_entry_get_text(GTK_ENTRY(Reference)));
  strcpy(c.Marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temperature)) == TRUE)
  {
    strcpy(c.Type_Cap, "Temperature");
  }
  else
  {
    strcpy(c.Type_Cap, "Humidite");
  }

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bonne)) == TRUE)
  {
    strcpy(c.Etat, "Bonne");
  }
  else
  {
    strcpy(c.Etat, "Panne");
  }

  c.d.Jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
  c.d.Mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
  c.d.Annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));

  c.v.Valeur = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Valeur));
  c.v.Val_Inf = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Inf));
  c.v.Val_Sup = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Sup));

  cond1 = verifRef_Cap1(c.Ref_Cap);
  cond = verifRef_Cap(c.Ref_Cap);
  gtk_label_set_text(GTK_LABEL(comp), "");
  gtk_label_set_text(GTK_LABEL(comp4), "");
  gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
  if (c.v.Val_Inf > c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Val_Inf < Val_Sup");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp), markup);
  }
   else if ((strcmp("Bonne",c.Etat)==0) && c.v.Valeur<c.v.Val_Inf || c.v.Valeur>c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Valeur est hors intervalle\n Capteur est en Panne");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp4), markup);
   }
  else if (cond == 0)
  {
    gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Champs Vides!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(Ref_Cap), markup);
  }
  else if (cond1 == 0)
  {
    gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Reference existante!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(Ref_Cap), markup);
  }
  else
  {
    SupEsp(c.Ref_Cap);
    ajout(c);
    gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
    dialog1 = create_dialog1();
    gtk_widget_show(dialog1);
  }
}

void on_YBbutton_M_M_clicked(GtkButton *button,
                             gpointer user_data)
{
  CAPTEUR c;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *dialog2;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *humidite;
  GtkWidget *comp1, *comp2,*comp4;
  GtkWidget *bonne;
  GtkWidget *panne;
  int cond1;
  char msg[50], *markup;
  const char *format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";

  comp1 = lookup_widget(button, "YBlabel_M_SB_V");
  comp2 = lookup_widget(button, "YBlabel_M_RC_V");
  comp4 = lookup_widget(button, "YBlabel_M_P");
  Reference = lookup_widget(button, "YBentry_M_RC");
  combobox = lookup_widget(button, "YBcombobox_M_MC");
  temperature = lookup_widget(button, "YBradiobutton_M_T");
  humidite = lookup_widget(button, "YBradiobutton_M_H");
  bonne = lookup_widget(button, "YBradiobutton_M_B");
  panne = lookup_widget(button, "YBradiobutton_M_P");
  Valeur = lookup_widget(button, "YBspinbutton_M_V");
  Val_Inf = lookup_widget(button, "YBspinbutton_M_VI");
  Val_Sup = lookup_widget(button, "YBspinbutton_M_VS");

  Jour = lookup_widget(button, "YBspinbutton_M_J");
  Mois = lookup_widget(button, "YBspinbutton_M_M");
  Annee = lookup_widget(button, "YBspinbutton_M_AN");

  strcpy(c.Ref_Cap, gtk_entry_get_text(GTK_ENTRY(Reference)));
  strcpy(c.Marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(temperature)))
  {
    strcpy(c.Type_Cap, "Temperature");
  }
  else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(humidite)))
  {
    strcpy(c.Type_Cap, "Humidite");
  }
  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(bonne)))
  {
    strcpy(c.Etat, "Bonne");
  }
  else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(panne)))
  {
    strcpy(c.Etat, "Panne");
  }
  c.d.Jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
  c.d.Mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
  c.d.Annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));

  c.v.Valeur = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Valeur));
  c.v.Val_Inf = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Inf));
  c.v.Val_Sup = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Sup));

  cond1 = verifRef_Cap1(c.Ref_Cap);
  gtk_label_set_text(GTK_LABEL(comp2), "");
  gtk_label_set_text(GTK_LABEL(comp1), "");
  gtk_label_set_text(GTK_LABEL(comp4), "");
  if (cond1 == 1)
  {
    gtk_label_set_text(GTK_LABEL(comp2), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Reference non existante!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp2), markup);
  }
  else if (c.v.Val_Inf > c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp1), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Val_Inf < Val_Sup!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp1), markup);
  }
  else if ((strcmp("Bonne",c.Etat)==0) && c.v.Valeur<c.v.Val_Inf || c.v.Valeur>c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Valeur est hors intervalle\n Capteur est en Panne");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp4), markup);
   }
  
  else
  {
    sprintf(msg, "");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp1), markup);
    gtk_label_set_markup(GTK_LABEL(comp2), markup);
    SupEsp(c.Ref_Cap);
    modification(c.Ref_Cap, c);
    dialog2 = create_dialog2();
    gtk_widget_show(dialog2);
  }
}

void on_YBclosebutton_A_D_clicked(GtkButton *button,
                                  gpointer user_data)
{
  GtkWidget *Dialog1;
  Dialog1 = lookup_widget(button, "dialog1");
  gtk_widget_destroy(Dialog1);
}

void on_YBclosebutton_M_D_clicked(GtkButton *button,
                                  gpointer user_data)
{
  GtkWidget *Dialog2;
  Dialog2 = lookup_widget(button, "dialog2");
  gtk_widget_destroy(Dialog2);
}

void on_YBbutton_A_RE_clicked(GtkWidget *objet,
                              gpointer user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(objet, "window_AC");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(objet, "window_GC");
  fenetre_afficher = create_window_GC();
  gtk_widget_show(fenetre_afficher);
}

void on_YBbutton_M_RE_clicked(GtkWidget *objet,
                              gpointer user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(objet, "window_MC");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(objet, "window_GC");
  fenetre_afficher = create_window_GC();
  gtk_widget_show(fenetre_afficher);
}

void on_YBbutton_VA_MPD_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *valeur_alr,*Mrq_Deff,*VA,*MPD;
char msg[50], *markup;
const char *format = "<span foreground=\"#FF0000\"><b>\%s</b></span>";
valeur_alr=lookup_widget(button, "YBlabel_VA");
Mrq_Deff=lookup_widget(button, "YBlabel_MPD");
VA=lookup_widget(button, "YBcheckbutton_A_VA");
MPD=lookup_widget(button, "YBcheckbutton_A_MPD");
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
gtk_label_set_text(GTK_LABEL(valeur_alr), "");
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(VA)))
{
int resu=alarment();
char al[200];
gtk_label_set_text(GTK_LABEL(valeur_alr), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(al, "le nombre des capteurs ayant une valeur alarmante est:%d", resu);
markup = g_markup_printf_escaped(format, al);
gtk_label_set_markup(GTK_LABEL(valeur_alr), markup);
}
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(MPD)))
{
CAPTEUR c;
FILE *f;
int n=0,m=0,p=0,z=0,res=0;

f=fopen("capteurs.txt","a+");
if(f!=NULL){
while (fscanf(f, "%s %s %s %s %s %s %s %s", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
{
	if(strcmp("WEENAT",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){n++;}
	}
        else if(strcmp("RS485",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){m++;}
	}
        else if(strcmp("SH10",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){p++;}
	}
        else if(strcmp("STEVENS",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){z++;}
	}
	
}
}
fclose(f);
if(n>=m && n>=p && n>=z){res=n;}
else if(m>=n && m>=p && m>=z){res=m;}
else if(p>=n && p>=m && p>=z){res=p;}
else if(z>=m && z>=n && z>=p){res=z;}
if(res==n)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'WEENAT'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
else if(res==m)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'RS485'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
else if(res==p)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'SH10'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
else if(res==z)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'STEVENS'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
}
}

