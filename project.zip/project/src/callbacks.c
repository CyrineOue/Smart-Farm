#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"

GtkWidget *window_liste_clients;
GtkWidget *window_ajouter;
GtkWidget *window_modifier;

char id[30];char a[70];char b[70];char y[70];char d[70];char e[70];char f[70];char g[70];char h[70];char m[70];char n[70];
void on_KLtreeview_row_activated(GtkTreeView *KLtreeview,
                                 GtkTreePath *path,
                                 GtkTreeViewColumn *column,
                                 gpointer user_data)

{
  CLIENT c;
  GtkTreeIter iter;
  gchar *nom;
  gchar *prenom;
  gchar *cin;
  gint *adresse;
  gint *email;
  gint *numero;
  gchar *identifiant;
  gchar *dt;
  gchar *sexe;
  gchar *achat;
  

  window_liste_clients = lookup_widget(KLtreeview, "window_liste_clients");
  GtkTreeModel *model = gtk_tree_view_get_model(KLtreeview);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &nom, 1, &prenom, 2, &cin, 3, &adresse, 4, &email, 5, &numero, 6, &identifiant, 7, &dt, 8, &sexe,  9, &achat, -1);
    strcpy(g, identifiant);
    strcpy(h, dt);
    strcpy(m, sexe);
    strcpy(a, nom);
    strcpy(b, prenom);
    strcpy(d, adresse);
    strcpy(e, email);
    strcpy(f, numero);
    strcpy(y, cin);
    strcpy(n, achat);   
    }
 
}

void on_KLbutton_rechercher_clicked(GtkButton *button,
                                    gpointer user_data)
{
  CLIENT c;
  GtkWidget *window_liste_clients;
  GtkWidget *KLentry_recherche;
  GtkWidget *KLtreeview;
  FILE *f;
  FILE *f2;
  char id[30];

  window_liste_clients = lookup_widget(button, "window_liste_clients");
  KLentry_recherche = lookup_widget(button, "KLentry_recherche");
  strcpy(id, gtk_entry_get_text(GTK_ENTRY(KLentry_recherche)));
  f = fopen("client.txt", "r");

  if (f != NULL)
  {
    while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat) != EOF)
    {
      f2 = fopen("recherche.txt", "a+");
      if (f2 != NULL)
      {
        if ((strcmp(c.identifiant, id) == 0))
        {
          fprintf(f2, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat);
        }
        KLtreeview = lookup_widget(window_liste_clients, "KLtreeview");
        recherche(KLtreeview);
        fclose(f2);
      }
    }

    fclose(f);
  }
  remove("recherche.txt");
}

void on_KLbutton_ajouter_clicked(GtkButton *objet,
                                 gpointer user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(objet, "window_liste_clients");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(objet, "window_ajouter");
  fenetre_afficher = create_window_ajouter();
  gtk_window_set_position(GTK_WINDOW(window_modifier),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(fenetre_afficher);
}


void on_KLbutton_supprimer_clicked(GtkButton *button,
                                   gpointer user_data)
{ 

GtkWidget* p ,*afficher,*w1,*pQuestion;
afficher = lookup_widget(button, "window_liste_clients");
GtkWidget  *KLtreeview = lookup_widget(afficher, "KLtreeview");

        pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
        GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer ce client ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

        suppression(g);
	gtk_widget_destroy(pQuestion);
        affichage(KLtreeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}
 
}

void on_KLbutton_enregistrer_clicked(GtkButton *button,
                                     gpointer user_data)
{
  CLIENT c;
  
  int cond1; 
  GtkWidget *KLentry_n;
  GtkWidget *KLentry_p;
  GtkWidget *KLentry_ci;
  GtkWidget *KLentry_a;
  GtkWidget *KLentry_e;
  GtkWidget *KLentry_nu;
  GtkWidget *KLentry_i;
  GtkWidget *KLentry_ac;
  GtkWidget *jour;
  GtkWidget *mois;
  GtkWidget *annee;
  GtkWidget *choix1;
  GtkWidget *choix2; 
  GtkWidget *dialog1; 
  GtkWidget *labelx;
  GtkWidget *KLlabel1;
   

  choix1 = lookup_widget(button, "choix1");
  choix2 = lookup_widget(button, "choix2");
  jour = lookup_widget(button, "KLspinbutton_ajoutjour");
  mois = lookup_widget(button, "KLspinbutton_ajoutmois");
  annee = lookup_widget(button, "KLspinbutton_ajoutannee");
  labelx = lookup_widget(button, "labelx");

  KLlabel1 = lookup_widget(button, "KLlabel1");
  KLentry_n = lookup_widget(button, "KLentry_nom");
  KLentry_p = lookup_widget(button, "KLentry_prenom");
  KLentry_ci = lookup_widget(button, "KLentry_cin");
  KLentry_a = lookup_widget(button, "KLentry_adresse");
  KLentry_e = lookup_widget(button, "KLentry_email");
  KLentry_nu = lookup_widget(button, "KLentry_numero");
  KLentry_i = lookup_widget(button, "KLentry_identifiant");
  KLentry_ac = lookup_widget(button, "KLentry_achat");
  strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(KLentry_n)));
  strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(KLentry_p)));
  strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(KLentry_ci)));
  strcpy(c.adresse, gtk_entry_get_text(GTK_ENTRY(KLentry_a)));
  strcpy(c.email, gtk_entry_get_text(GTK_ENTRY(KLentry_e)));
  strcpy(c.numero, gtk_entry_get_text(GTK_ENTRY(KLentry_nu)));
  strcpy(c.identifiant, gtk_entry_get_text(GTK_ENTRY(KLentry_i)));
  strcpy(c.achat, gtk_entry_get_text(GTK_ENTRY(KLentry_ac)));
  c.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
  c.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
  c.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix1)))
  {
    strcpy(c.sexe, "Femme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix2)))
  {
    strcpy(c.sexe, "Homme");
  }

   cond1=verifid(c.identifiant);

  
  if((vide(KLentry_n) ==0) || (vide(KLentry_p) ==0) || (vide(KLentry_ci) ==0) || (vide(KLentry_a) ==0) || (vide(KLentry_nu) ==0) || (vide(KLentry_i) ==0) || (vide(KLentry_ac) ==0) )
   
   gtk_label_set_markup(KLlabel1,"<span foreground='red'><b>Remplir tous les champs SVP !</b></span>");
  
   else 
   if (cond1==0){
   gtk_label_set_markup(KLlabel1,"<span foreground='red'><b>Identifiant existe déjà !</b></span>");
  }
 
  else
{

  ajout(c);
  dialog1=create_dialog1();
  gtk_window_set_position(GTK_WINDOW(dialog1),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(dialog1);
  }

}
void on_KLbutton_afficher_clicked(GtkButton *button,
                                  gpointer user_data)

{
  GtkWidget *fenetre_afficher;
  GtkWidget *KLtreeview;

  fenetre_afficher = lookup_widget(button, "window_liste_clients");
  KLtreeview = lookup_widget(fenetre_afficher, "KLtreeview");
  gtk_window_set_position(GTK_WINDOW(fenetre_afficher),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(fenetre_afficher);
  affichage(KLtreeview);
}

void on_KLbutton_retour1_clicked(GtkButton *button,
                                 gpointer user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_liste_clients");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(button, "window_ajouter");
  fenetre_afficher = create_window_liste_clients();
  gtk_window_set_position(GTK_WINDOW(fenetre_afficher),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(fenetre_afficher);
}

void on_KLbutton_valider_clicked(GtkButton *button,
                                 gpointer user_data)
{
  CLIENT c;

  GtkWidget *KLentry_n;
  GtkWidget *KLentry_p;
  GtkWidget *KLentry_ci;
  GtkWidget *KLentry_a;
  GtkWidget *KLentry_e;
  GtkWidget *KLentry_nu;
  GtkWidget *KLentry_i;
  GtkWidget *KLentry_ac;
  GtkWidget *jour;
  GtkWidget *mois;
  GtkWidget *annee;
  GtkWidget *cond;
  GtkWidget *choix11;
  GtkWidget *choix22;
  GtkWidget *dialog2;
  GtkWidget *KLlabel2;


  choix11 = lookup_widget(button, "choix11");
  choix22 = lookup_widget(button, "choix22");
  jour = lookup_widget(button, "KLspinbutton_modifajoutjour");
  mois = lookup_widget(button, "KLspinbutton_modifajoutmois");
  annee = lookup_widget(button, "KLspinbutton_modifajoutannee");
  KLlabel2 = lookup_widget(button, "KLlabel2");

  KLentry_n = lookup_widget(button, "KLentry_modifnom");
  KLentry_p = lookup_widget(button, "KLentry_modifprenom");
  KLentry_ci = lookup_widget(button, "KLentry_modifcin");
  KLentry_a = lookup_widget(button, "KLentry_modifadresse");
  KLentry_e = lookup_widget(button, "KLentry_modifemail");
  KLentry_nu = lookup_widget(button, "KLentry_modifnumero");
  KLentry_i = lookup_widget(button, "KLentry_modifidentifiant");
  KLentry_ac = lookup_widget(button, "KLentry_modifachat");
  strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(KLentry_n)));
  strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(KLentry_p)));
  strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(KLentry_ci)));
  strcpy(c.adresse, gtk_entry_get_text(GTK_ENTRY(KLentry_a)));
  strcpy(c.email, gtk_entry_get_text(GTK_ENTRY(KLentry_e)));
  strcpy(c.numero, gtk_entry_get_text(GTK_ENTRY(KLentry_nu)));
  strcpy(c.identifiant, gtk_entry_get_text(GTK_ENTRY(KLentry_i)));
  strcpy(c.achat, gtk_entry_get_text(GTK_ENTRY(KLentry_ac)));
  c.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
  c.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
  c.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix11)))
  {
    strcpy(c.sexe, "Femme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix22)))
  {
    strcpy(c.sexe, "Homme");
  }
    if((vide(KLentry_n) ==0) || (vide(KLentry_p) ==0) || (vide(KLentry_ci) ==0) || (vide(KLentry_a) ==0) || (vide(KLentry_nu) ==0) || (vide(KLentry_i) ==0) || (vide(KLentry_ac) ==0) )
   
   gtk_label_set_markup(KLlabel2,"<span foreground='red'><b>Remplir tous les champs SVP !</b></span>");
  
  else {
  dialog2=create_dialog2();
  gtk_window_set_position(GTK_WINDOW(dialog2),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(dialog2);
  modification(c.identifiant,c);
 } 
}

void on_KLbutton_retour2_clicked(GtkButton *button,
                                 gpointer user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_liste_clients");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(button, "window_modifier");
  fenetre_afficher = create_window_liste_clients();
  gtk_window_set_position(GTK_WINDOW(fenetre_afficher),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(fenetre_afficher);
}



void
on_KLbutton_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
  CLIENT c;
  GtkTreeIter iter;
  gchar *nom;
  gchar *prenom;
  gchar *cin;
  gint *adresse;
  gint *email;
  gint *numero;
  gchar *identifiant;
  gchar *dt;
  gchar *sexe;
  gchar *achat;
  GtkWidget *window_liste_clients;
  GtkWidget *window_modifier;
  GtkWidget *NOM;
  GtkWidget *PRENOM;
  GtkWidget *CIN;
  GtkWidget *ADRESSE;
  GtkWidget *EMAIL;
  GtkWidget *NUMTEL;
  GtkWidget *IDENTIF;
  GtkWidget *JOUR;
  GtkWidget *MOIS;
  GtkWidget *ANNEE;
  GtkWidget *HOMME;
  GtkWidget *FEMME;
  GtkWidget *ACHAT;



    window_modifier = create_window_modifier();
    gtk_widget_hide(window_liste_clients);
    gtk_window_set_position(GTK_WINDOW(window_modifier),GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(window_modifier);
     
    sscanf(h, "%d/%d/%d", &c.d.jour, &c.d.mois, &c.d.annee);
    
    NOM = lookup_widget(window_modifier, "KLentry_modifnom");
    PRENOM = lookup_widget(window_modifier, "KLentry_modifprenom");
    CIN = lookup_widget(window_modifier, "KLentry_modifcin");
    ADRESSE = lookup_widget(window_modifier, "KLentry_modifadresse");
    EMAIL = lookup_widget(window_modifier, "KLentry_modifemail");
    NUMTEL = lookup_widget(window_modifier, "KLentry_modifnumero");
    IDENTIF = lookup_widget(window_modifier, "KLentry_modifidentifiant");
    ACHAT = lookup_widget(window_modifier, "KLentry_modifachat");
    JOUR = lookup_widget(window_modifier, "KLspinbutton_modifajoutjour");
    MOIS = lookup_widget(window_modifier, "KLspinbutton_modifajoutmois");
    ANNEE = lookup_widget(window_modifier, "KLspinbutton_modifajoutannee");
    HOMME = lookup_widget(window_modifier, "choix22");
    FEMME = lookup_widget(window_modifier, "choix11");
    gtk_entry_set_text(GTK_ENTRY(NOM), a);
    gtk_entry_set_text(GTK_ENTRY(PRENOM), b);
    gtk_entry_set_text(GTK_ENTRY(CIN), y);
    gtk_entry_set_text(GTK_ENTRY(ADRESSE), d);
    gtk_entry_set_text(GTK_ENTRY(EMAIL), e);
    gtk_entry_set_text(GTK_ENTRY(NUMTEL), f);
    gtk_entry_set_text(GTK_ENTRY(IDENTIF), g);
    gtk_entry_set_text(GTK_ENTRY(ACHAT), n);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(JOUR), c.d.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(MOIS), c.d.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(ANNEE), c.d.annee);
 
       
    if ((strcmp(c.sexe, "Homme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
    }
    else if ((strcmp(c.sexe, "Femme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
}
}


void
on_KLbutton_fid_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

   GtkWidget *max , *var ;
   CLIENT c;
   FILE *f;
   char id[50];
   char achat[20];
   char identifiant[20];
   char machats[20];
   int i;
   int j=0;

       f = fopen("client.txt", "r+");
       while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat) != EOF)
		      
       {       
	strcpy(machats,c.achat);
	sscanf (machats,"%d",&i);

	  if (i>j){
	            j =i;
	            strcpy(id,c.identifiant);}

       }
	fclose (f);
 	sprintf(achat,"%d",j);
 	max=lookup_widget (button,"KLentry_fid");
 	var=lookup_widget (button,"KLentry_fid1"); 
  	gtk_entry_set_text(GTK_ENTRY(max),achat); 
  	gtk_entry_set_text(GTK_ENTRY(var),id);    
	
    
}

