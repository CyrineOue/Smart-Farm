#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct 
{
int jour;
int mois;
int annee;
}Date;
typedef struct 
{       char identifiant[9];
	char sexe [30];
	char type[30];
	char couleur[30];
	Date date_naissance;
	char poids[50];
	char etat [30];
} troupeau ;

void ajouter_troupeaux(troupeau t);
void supprimer(char *id);
void rechercher_par_type(troupeau t,char type[]);
void afficher(GtkWidget *liste);
void afficher_rech(GtkWidget *liste);
int somme();
#endif // FONCTION_H_INCLUDED
