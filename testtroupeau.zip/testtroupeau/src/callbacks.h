#include <gtk/gtk.h>


void
on_gestion_troupeaux_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonajouterveau_clicked           (GtkWidget        *objet,
                                        gpointer         user_data);



void
on_buttonajouterbrebi_clicked          (GtkWidget        *objet,
                                        gpointer         user_data);


void
on_buttonaffiche_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonquitter_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_closebutton2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_closebutton3_clicked                (GtkWidget       *button,
                                        gpointer         user_data);




void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_buttonvalide_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_okbutton1_clicked                   (GtkWidget         *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonnombre_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonstat_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonretouraccueiladmin_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
