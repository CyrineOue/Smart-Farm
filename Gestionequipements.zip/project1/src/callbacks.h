#include <gtk/gtk.h>


/*void
on_Modification_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierLaValeur_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierLaDateDachat_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierLetat_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierLaRef_clicked               (GtkButton       *objet,
                                        gpointer         user_data);


*/

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


/*
void
on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_spinbutton1_delete_text             (GtkEditable     *editable,
                                        gint             start_pos,
                                        gint             end_pos,
                                        gpointer         user_data);

*/


void
on_buttonvalide_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmod_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonaffiche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonsupp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonmodif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonoksupp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_adminstatistiques_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongestionemp_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestiondesequipements_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_statistiques_clicked                (GtkButton       *button,
                                        gpointer         user_data);*/



void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_validermodif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_validermodif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherstatistiquescy_clicked      (GtkButton       *button,
                                        gpointer         user_data);
