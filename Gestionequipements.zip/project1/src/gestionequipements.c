#include "gestionequipements.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <gtk/gtk.h>



void ajouterequipement(equipement e)
{
FILE *f;
f=fopen("equipements.txt","a+");
if(f!=NULL)
{
 fprintf(f,"%s %s %s %d %d %d %s \n",e.reference,e.type,e.etat,e.dt.jour,e.dt.mois,e.dt.annee,e.prix);
}
fclose(f);
}

////////////////////////////////
enum
{	
	REFERENCE,
	TYPE,
	ETAT,
	DATEDACHAT,
 	PRIX,
	COLUMNS
};

void afficherlisteequipements(GtkWidget *liste,equipement e)
{       FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char datedachat[30];

store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("reference", renderer, "text",REFERENCE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type", renderer, "text", TYPE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("etat", renderer, "text", ETAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date d'achat", renderer, "text", DATEDACHAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prix", renderer, "text", PRIX, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("equipements.txt","r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen("equipements.txt","a+");
	while (fscanf(f,"%s %s %s %d %d %d %s \n",e.reference,e.type,e.etat,&e.dt.jour,&e.dt.mois,&e.dt.annee,e.prix)!=EOF)
	
{ 
 sprintf(datedachat,"%d/%d/%d",e.dt.jour,e.dt.mois,e.dt.annee);
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,REFERENCE, e.reference, TYPE, e.type, ETAT, e.etat, DATEDACHAT,datedachat,PRIX,e.prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//////////////////////////////////////////////////

void supprimerequipement(char *ref)
{

equipement e1;
FILE *f ,*g;

f=fopen("equipements.txt","r"); 
g=fopen("equipements1.txt","w"); 

if ((f==NULL) || (g==NULL))
{
return ; 
}
else 
{
while(fscanf(f,"%s %s %s %d %d %d %s ",e1.reference,e1.type,e1.etat,&e1.dt.jour,&e1.dt.mois,&e1.dt.annee,e1.prix)!=EOF)
	{
	  if (strcmp(ref,e1.reference)!=0)
	{
	  fprintf(g,"%s %s %s %d %d %d %s \n",e1.reference,e1.type,e1.etat,e1.dt.jour,e1.dt.mois,e1.dt.annee,e1.prix);
	}
	}
	fclose(f);
	fclose(g);
remove("equipements.txt");
rename("equipements1.txt","equipements.txt");
}
}

void Recherche (equipement e,char type[20])
{


        FILE *f;
	FILE *f1;
        f=fopen("equipements.txt","r");
        f1=fopen("equipements0.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %d %d %d %s  \n",e.reference,e.type,e.etat,&e.dt.jour,&e.dt.mois,&e.dt.annee,e.prix)!=EOF)
        {
                 if(strcmp(e.type,type)==0)

			{ fprintf(f1,"%s %s %s %d %d %d %s  \n",e.reference,e.type,e.etat,e.dt.jour,e.dt.mois,e.dt.annee,e.prix);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
void afficherrecherche(GtkWidget *liste)
{    FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
equipement e;
char datedachat[0];

store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("reference", renderer, "text",REFERENCE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type", renderer, "text", TYPE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("etat", renderer, "text", ETAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date d'achat", renderer, "text", DATEDACHAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prix", renderer, "text", PRIX, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("equipements0.txt","r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen("equipements0.txt","a+");
	while (fscanf(f,"%s %s %s %d %d %d %s \n",e.reference,e.type,e.etat,&e.dt.jour,&e.dt.mois,&e.dt.annee,e.prix)!=EOF)
	
{ 
 sprintf(datedachat,"%d/%d/%d",e.dt.jour,e.dt.mois,e.dt.annee);
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,REFERENCE, e.reference, TYPE, e.type, ETAT, e.etat, DATEDACHAT,datedachat,PRIX,e.prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

//////////////////////////////////////////////////

void listedefect(equipement e)
{


        FILE *f;
	FILE *f1;
        f=fopen("equipements.txt","r");
        f1=fopen("equipementsdefec.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %d %d %d %s  \n",e.reference,e.type,e.etat,&e.dt.jour,&e.dt.mois,&e.dt.annee,e.prix)!=EOF)
        {
                 if(strcmp(e.etat,"Déféctueux")==0)

			{ fprintf(f1,"%s %s %s %d %d %d %s  \n",e.reference,e.type,e.etat,e.dt.jour,e.dt.mois,e.dt.annee,e.prix);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
void afficherdefect(GtkWidget *liste)
{FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
equipement e;
char datedachat[30];

store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("reference", renderer, "text",REFERENCE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type", renderer, "text", TYPE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("etat", renderer, "text", ETAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date d'achat", renderer, "text", DATEDACHAT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prix", renderer, "text", PRIX, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("equipementsdefec.txt","r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen("equipementsdefec.txt","a+");
	while (fscanf(f,"%s %s %s %d %d %d %s \n",e.reference,e.type,e.etat,&e.dt.jour,&e.dt.mois,&e.dt.annee,e.prix)!=EOF)
	
{ 
 sprintf(datedachat,"%d/%d/%d",e.dt.jour,e.dt.mois,e.dt.annee);
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,REFERENCE, e.reference, TYPE, e.type, ETAT, e.etat, DATEDACHAT,datedachat,PRIX,e.prix, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

int statistiques ()
{
FILE* f;
	//char msg[128] = "" ;
	int compteur_defectueux=0;
	equipement e;
	
f=fopen("equipements.txt","r");
  while (fscanf(f,"%s %s %s %d %d %d %s",e.reference,e.type,e.etat,&e.dt.jour,&e.dt.mois,&e.dt.annee,e.prix)!=EOF)
{ if (strcmp(e.etat,"Déféctueux")==0 )
{     compteur_defectueux++;
}


}
  
fclose(f);
return (compteur_defectueux);
}
