#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "gestionequipements.h"
#include<string.h>


void
on_buttonvalide_clicked                (GtkButton       *button,
                                        gpointer         user_data)

{GtkWidget *entry1, *entry2,*combobox1, *combobox2, *jour, *mois,*annee;
GtkWidget *windowajout;
equipement e;
windowajout=lookup_widget(button,"windowajout");
entry1=lookup_widget(button,"entry2");
combobox1=lookup_widget(button,"combobox2");
combobox2=lookup_widget(button,"combobox3");
jour=lookup_widget(button,"spinbuttonjour");
mois=lookup_widget(button,"spinbuttonmois");
annee=lookup_widget(button,"spinbuttonannee");
entry2=lookup_widget(button,"entry6");

strcpy(e.reference,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(e.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(e.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));

e.dt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.dt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.dt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(entry2)));
GtkWidget *dialog1;
dialog1=create_dialog1();
gtk_widget_show(dialog1);
ajouterequipement(e);
}






void
on_buttonaffiche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *WindowGestionEquipements;
   	GtkWidget *treeview3;
	equipement e;

	WindowGestionEquipements=lookup_widget(button,"WindowGestionEquipements");
	treeview3=lookup_widget(WindowGestionEquipements,"treeview3");
        afficherlisteequipements(treeview3,e);
}


void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{	GtkWidget *WindowGestionEquipements;
   	GtkWidget *treeview4;
	GtkWidget *input1;
    char type[30];
    equipement e;

        WindowGestionEquipements=lookup_widget(button,"WindowGestionEquipements");
	treeview4=lookup_widget(WindowGestionEquipements,"treeview4");
	input1=lookup_widget(button,"entryrech");
  	strcpy(type,gtk_entry_get_text(GTK_ENTRY(input1)));
        afficherrecherche(treeview4);
	Recherche(e,type);
}



void
on_okbuttonajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1=lookup_widget(GTK_WIDGET(button),("dialog1"));

gtk_widget_destroy(dialog1);

}



void
on_okbuttonsupp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog2=lookup_widget(GTK_WIDGET(button),("dialog2"));

gtk_widget_destroy(dialog2);

}






void
on_adminstatistiques_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tableaudebord;
GtkWidget *window_admin;
window_admin=lookup_widget(button,"window_admin");
gtk_widget_destroy(window_admin);
tableaudebord=create_tableaudebord();
gtk_widget_show(tableaudebord);
}



void
on_gestiondesequipements_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{ 	GtkWidget *WindowGestionEquipements;
	GtkWidget *windowgestion;
	windowgestion=create_windowgestion();
	windowgestion=lookup_widget(button,"windowgestion");
	gtk_widget_hide(windowgestion);
	WindowGestionEquipements = create_WindowGestionEquipements();
	gtk_widget_show(WindowGestionEquipements);

}

equipement e2;
void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;

gchar* ref;
gchar* t;
gchar* e;

gchar* dt;
gchar* p;

GtkTreeModel *list_store;
list_store=gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(list_store,&iter,path))

{
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,0,&ref,-1);
/*
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,1,&t,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,2,&e,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,3,&dt,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,4,&p,-1);
*/


strcpy(e2.reference,ref);
/*
strcpy(e2.type,t);
strcpy(e2.etat,e);
sscanf(dt,"%d/%d/%d",&e2.date.jour,&e2.date.mois,&e2.date.annee);
strcpy(e2.prix,p);
*/
supprimerequipement(ref);
}
}

void
on_okbuttonmodif_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{GtkWidget *dialog3=lookup_widget(GTK_WIDGET(objet),("dialog3"));

gtk_widget_destroy(dialog3);
}

/*GtkWidget *dialog3;
dialog3=create_dialog3() ;
gtk_widget_show(dialog3); 	
*/
void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WindowGestionEquipements;
	GtkWidget *windowajout;
	
	WindowGestionEquipements=lookup_widget(button,"WindowGestionEquipements");
	windowajout=lookup_widget(button,"windowajout");
	windowajout=create_windowajout();
	
	gtk_widget_show(windowajout);
	

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *WindowGestionEquipements;
GtkWidget *windowgestion;
WindowGestionEquipements=lookup_widget(button,"WindowGestionEquipements");
gtk_widget_destroy(WindowGestionEquipements);
windowgestion=create_windowgestion();
gtk_widget_show(windowgestion);

}



void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *WindowGestionEquipements;
GtkWidget *windowajout;
windowajout=lookup_widget(button,"windowajout");
gtk_widget_destroy(windowajout);
WindowGestionEquipements=create_WindowGestionEquipements();


}


void
on_retourmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WindowGestionEquipements;
GtkWidget *windowmodif;
windowmodif=lookup_widget(button,"windowmodif");
gtk_widget_destroy(windowmodif);
WindowGestionEquipements=create_WindowGestionEquipements();
//gtk_widget_show(WindowGestionEquipements);
}


void
on_supp_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *WindowGestionEquipements;
WindowGestionEquipements=lookup_widget(GTK_WIDGET(button),"WindowGestionEquipements");
supprimerequipement(e2.reference);
GtkWidget *treeview3;

treeview3=lookup_widget(WindowGestionEquipements,"treeview3");
///afficherlisteequipements(treeview3,e2);
//gtk_widget_show(treeview3);

GtkWidget *dialog2;
dialog2=create_dialog2();
gtk_widget_show(dialog2);
}


void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *WindowGestionEquipements;
	GtkWidget *windowmodif;
	GtkWidget *entry1;
        GtkWidget *entry2,*jour, *mois,*annee;
	equipement e2;
	
	WindowGestionEquipements=lookup_widget(button,"WindowGestionEquipements");
	windowmodif=lookup_widget(button,"windowmodif");
	windowmodif=create_windowmodif();
	
	gtk_widget_show(windowmodif);

entry1=lookup_widget(button,"entryrefmod");
jour=lookup_widget(button,"spinbuttonjourmod");
mois=lookup_widget(button,"spinbuttonmoismod");
annee=lookup_widget(button,"spinbuttonanneemod");
entry2=lookup_widget(button,"entryprixmod");


gtk_spin_button_set_value(jour,e2.dt.jour);
gtk_spin_button_set_value(mois,e2.dt.mois);
gtk_spin_button_set_value(annee,e2.dt.annee);


gtk_entry_set_text(GTK_ENTRY(entry1),e2.reference);
gtk_entry_set_text(GTK_ENTRY(entry2),e2.prix);
}


 


void
on_validermodif_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry1, *entry2,*combobox1, *combobox2, *jour, *mois,*annee;
GtkWidget *windowajout;
equipement e2;





entry1=lookup_widget(button,"entryrefmod");
combobox1=lookup_widget(button,"comboboxtypemod");
combobox2=lookup_widget(button,"comboboxetatmod");
jour=lookup_widget(button,"spinbuttonjourmod");
mois=lookup_widget(button,"spinbuttonmoismod");
annee=lookup_widget(button,"spinbuttonanneemod");
entry2=lookup_widget(button,"entryprixmod");

strcpy(e2.reference,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(e2.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(e2.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));

e2.dt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e2.dt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e2.dt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(e2.prix,gtk_entry_get_text(GTK_ENTRY(entry2)));


ajouterequipement(e2);

GtkWidget *dialog3=lookup_widget(GTK_WIDGET(button),("dialog3"));

dialog3=create_dialog3() ;
gtk_widget_show(dialog3); 


}


void
on_afficherstatistiquescy_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
int compteur_defectueux;
char msg[120]="";

equipement e;
GtkWidget *output;
GtkWidget *window3;
GtkWidget *treeview5;
window3=lookup_widget(button,"tableaudebord");
treeview5=lookup_widget(window3,"treeview5");
output=lookup_widget(button,"label75");

        
        compteur_defectueux=statistiques();

        sprintf (msg, "Le nombre d'équipements déféctueux vaut %d", compteur_defectueux) ;
        gtk_label_set_text(output,msg);
listedefect(e);
afficherdefect(treeview5);

}

