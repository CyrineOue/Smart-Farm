#ifndef GESTIONEQUIPEMENTS_H_INCLUDED
#define GESTIONEQUIPEMENTS_H_INCLUDED
#include<stdio.h>
#include<stdlib.h>
#include <gtk/gtk.h>
#include<string.h>

typedef struct {
int jour;
int mois;
int annee;
}Dateeq;

typedef struct {
char type[30];
char reference[30];
char prix[50];
Dateeq dt;
char etat[50];

} equipement;

void ajouterequipement(equipement e);              
void supprimerequipement(char *ref);

void afficherlisteequipements(GtkWidget *liste,equipement e);
void afficherrecherche(GtkWidget *liste);
void Recherche(equipement e,char type[]);
void listedefect(equipement e);
void afficherdefect(GtkWidget *liste);
//Partie2
int statistiques ();
#endif
