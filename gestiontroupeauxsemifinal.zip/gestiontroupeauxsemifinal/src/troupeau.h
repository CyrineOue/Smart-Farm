#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct 
{
int jour;
int mois;
int annee;
}Date;
typedef struct 
{       char identifiant[9];
	char sexe [50];
	char type[50];
	char couleur[50];
	Date date_naissance;
	char poids[50];
	char etat [50];
} troupeau ;

void ajouter_troupeaux(troupeau t);
void supprimer(char *id);
void rechercher_par_type(troupeau t,char type[]);
void afficher(GtkWidget *liste,troupeau t);
void afficher_rech(GtkWidget *liste,troupeau t);
int somme();
#endif // FONCTION_H_INCLUDED
