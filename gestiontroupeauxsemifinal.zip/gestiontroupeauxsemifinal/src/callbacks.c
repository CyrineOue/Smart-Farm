#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "troupeau.h"
#include "troupeau.c"

troupeau tr;
void on_gestion_troupeaux_clicked  (GtkWidget  *button, gpointer user_data)
{
   GtkWidget *window_gestions;
   GtkWidget *window_troupeau;
   window_gestions=create_window_gestions();
   window_gestions=lookup_widget(button,"window_gestions");
   gtk_widget_hide(window_gestions);
   window_troupeau = create_window_troupeau ();
   gtk_widget_show (window_troupeau);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

/*void on_buttonajouterveau_clicked (GtkWidget *objet, gpointer  user_data)
{
	troupeau t;
	GtkWidget *window_troupeau;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;


	GtkWidget *jourv;
	GtkWidget *moisv;
	GtkWidget *anneev;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;

	char ch1[20];
	char ch2[20];
	char ch3[20];


   input1=lookup_widget(objet,"entryidv");

   radiobutton1=lookup_widget(objet,"radiobutton1v"); 
   radiobutton2=lookup_widget(objet,"radiobutton2v"); 

   combobox1=lookup_widget(objet,"comboboxtype1");

   input2=lookup_widget(objet,"entrycouleurv");


   jourv=lookup_widget(objet,"spinbuttonjourv");
   moisv=lookup_widget(objet,"spinbuttonmoisv");
   anneev=lookup_widget(objet,"spinbuttonanneev");

   input3=lookup_widget(objet,"entrypoidsv");

   combobox2=lookup_widget(objet,"comboboxetatv");


   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));



   if( !(strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
     { 

       GtkWidget *dialog1;
       dialog1=create_dialog1() ;
       gtk_widget_show(dialog1) ;
     }

   else 
    {
       strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
       strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
       strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));

   if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
         {   strcpy(t.sexe,"Male");
         }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
         {   strcpy(t.sexe,"Femelle");
         }
       strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
       strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
       t.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourv));
       t.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisv));
       t.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneev));


       GtkWidget *dialog2;
       dialog2=create_dialog2() ;
       gtk_widget_show(dialog2) ;

       ajouter_troupeaux(t);
    }
}*/


///////////////////////////////////////////////////////////////////////////////////////////////////////


void on_buttonquitter_clicked (GtkWidget *button, gpointer user_data)
{

	GtkWidget *window_gestions;
	GtkWidget *window_troupeau;
	window_troupeau=lookup_widget(button,"window_troupeau");
	gtk_widget_destroy(window_troupeau);
	window_gestions=create_window_gestions();
	gtk_widget_show(window_gestions);  
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonrecherche_clicked (GtkWidget  *button, gpointer user_data)
{ 
	
	GtkWidget *radio1;
	GtkWidget *radio2;
	GtkWidget *window1;
	GtkWidget *treeview2;
	char type[20];
	troupeau t;

	radio1=lookup_widget(button,"radiobuttonchoix1"); 
	radio2=lookup_widget(button,"radiobuttonchoix2"); 

     window1=lookup_widget(button,"window_troupeau");
     treeview2=lookup_widget(window1,"treeview2");
	 if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio1))==TRUE)
         {   strcpy(type,"Veau");
         }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio2))==TRUE)
         {   strcpy(type,"Brebi");
         }
        afficher_rech(treeview2,t);
	rechercher_par_type(t,type);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton1_clicked (GtkWidget *button, gpointer user_data)
{
	GtkWidget *dialog1=lookup_widget(GTK_WIDGET(button),("dialog1"));
	gtk_widget_destroy(dialog1);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton2_clicked (GtkWidget *button,gpointer user_data)
{
	GtkWidget *dialog2=lookup_widget(GTK_WIDGET(button),("dialog2"));
	gtk_widget_destroy(dialog2);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton3_clicked (GtkWidget *button,gpointer  user_data)
{
	GtkWidget *dialog3=lookup_widget(GTK_WIDGET(button),("dialog3"));
	gtk_widget_destroy(dialog3);
}

////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////

/*void on_buttonvalide_clicked  (GtkWidget *objet, gpointer  user_data)
{
	troupeau tr;
	GtkWidget *window_troupeau;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;

	char ch1[20];
	char ch2[20];
	char ch3[20];
	char ch4[20];

   input4=lookup_widget(objet,"entry1");
   input1=lookup_widget(objet,"entryidmod");

   radiobutton1=lookup_widget(objet,"radiobutton1mod"); 
   radiobutton2=lookup_widget(objet,"radiobutton2mod"); 

   combobox1=lookup_widget(objet,"combobox1mod");

   input2=lookup_widget(objet,"entrycouleurmod");


   jour=lookup_widget(objet,"spinbuttonjourmod");
   mois=lookup_widget(objet,"spinbuttonmoismod");
   annee=lookup_widget(objet,"spinbuttonanneemod");

   input3=lookup_widget(objet,"entrypoidsmod");

   combobox2=lookup_widget(objet,"combobox2mod");


   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));
   strcpy(ch4,gtk_entry_get_text(GTK_ENTRY(input4)));

    if( !(strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
       { 

 	  GtkWidget *dialog1;
	  dialog1=create_dialog1() ;
	  gtk_widget_show(dialog1) ;
       }

   else 
       {
	  strcpy(tr.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
	  strcpy(tr.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
	  strcpy(tr.poids,gtk_entry_get_text(GTK_ENTRY(input3)));

   if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(tr.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(tr.sexe,"Femelle");}
	  strcpy(tr.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	  strcpy(tr.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	  tr.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
          tr.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
          tr.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

         GtkWidget *dialog4;
	 dialog4=create_dialog4() ;
	 gtk_widget_show(dialog4) ;
	 supprimer(ch4);
         ajouter_troupeaux(tr);
     }
}*/


////////////////////////////////////////////////////////////////////////////////////////////

void on_okbutton1_clicked (GtkWidget *button, gpointer user_data)
{
	GtkWidget *dialog4=lookup_widget(GTK_WIDGET(button),("dialog4"));
	gtk_widget_destroy(dialog4);
}
////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonnombre_clicked   (GtkButton *button,gpointer  user_data)
{
/*troupeau t;
int nbr;
char ch1[20];
char text[20]="";
GtkLabel * output;
GtkWidget *window3;
GtkWidget *input1;


window3=lookup_widget(button,"window_tableau_de_bord");
input1=lookup_widget(button,"entrychoix");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
if (!strcmp(ch1, "")) {
    sprintf (text, "Champs vides") ;
}
else {
nbr=Somme();
sprintf (text, "la somme vaut %d",nbr) ;
output=lookup_widget(button,"labelbombre");
}
gtk_label_set_text(output),text);

 */
}
////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonstat_clicked  (GtkButton *button,gpointer   user_data)
{
   GtkWidget *window_admin;
   GtkWidget *window_tableau_de_bord;
   window_admin=create_window_admin();
   window_admin=lookup_widget(button,"window_admin");
   gtk_widget_hide(window_admin);
   window_tableau_de_bord = create_window_tableau_de_bord ();
   gtk_widget_show (window_tableau_de_bord);
}

////////////////////////////////////////////////////////////////////////////////////////////


void
on_buttonretouraccueiladmin_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_admin;
	GtkWidget *window_tableau_de_bord;
	window_tableau_de_bord=lookup_widget(button,"window_tableau_de_bord");
	gtk_widget_destroy(window_tableau_de_bord);
	window_admin=create_window_admin();
	gtk_widget_show(window_admin);  
}


////////////////////////////////////////

void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
//supprimer((char *)tr.identifiant);
supprimer(tr.identifiant);
GtkWidget *window_ajout=lookup_widget(GTK_WIDGET(objet),"window_ajout");

GtkWidget *window_troupeau;
window_troupeau=lookup_widget(GTK_WIDGET(objet),("window_troupeau"));

gtk_widget_destroy(window_troupeau);

window_ajout=create_window_ajout();
gtk_widget_show(window_ajout);

GtkWidget *identifiant=lookup_widget(window_ajout,"entryidv");
GtkWidget *couleur=lookup_widget(window_ajout,"entrycouleurv");
GtkWidget *poids=lookup_widget(window_ajout,"entrypoidsv");

GtkWidget *radiobutton1=lookup_widget(objet,"radiobutton1v"); 
GtkWidget *radiobutton2=lookup_widget(objet,"radiobutton2v"); 

GtkWidget *combobox1=lookup_widget(objet,"comboboxtype1");
GtkSpinButton *jour=lookup_widget(window_ajout,"spinbuttonjourv");
GtkSpinButton *mois=lookup_widget(window_ajout,"spinbuttonmoisv");
GtkSpinButton *annee=lookup_widget(window_ajout,"spinbuttonanneev");


GtkWidget *combobox2=lookup_widget(objet,"comboboxetatv");

gtk_entry_set_text(GTK_LABEL(identifiant),tr.identifiant);
gtk_entry_set_text(GTK_LABEL(couleur),tr.couleur);
gtk_entry_set_text(GTK_LABEL(poids),tr.poids);

gtk_spin_button_set_value(jour,tr.date_naissance.jour);
gtk_spin_button_set_value(mois,tr.date_naissance.mois);
gtk_spin_button_set_value(annee,tr.date_naissance.annee);

gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1));
gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2));

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(tr.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(tr.sexe,"Femelle");}

 
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

gchar *data0;
gchar *data1;
gchar *data2;
gchar *data3;
gchar *data4;
gchar *data5;
gchar *data6;


GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;

  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &data0, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,1, &data1, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,2, &data2, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &data3, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,4, &data4, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,5, &data5, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,6, &data6, -1);


strcpy (tr.identifiant, data0);
strcpy (tr.sexe, data1);
strcpy (tr.type, data2);
strcpy (tr.couleur, data3);
sscanf (data4,"%d/%d/%d",&tr.date_naissance.jour,&tr.date_naissance.mois,&tr.date_naissance.annee);
strcpy (tr.poids, data5);
strcpy (tr.etat, data6);
//supprimer(tr.identifiant);

}

}


void
on_buttonsupp_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
//supprimer((char *)tr.identifiant);
supprimer(tr.identifiant);

GtkWidget *window_troupeau=lookup_widget(GTK_WIDGET(objet),"window_troupeau");
GtkWidget *treeview1;

treeview1=lookup_widget(window_troupeau,"treeview1");
afficher(treeview1,tr);
gtk_widget_show(treeview1);
}


/*void
on_buttonajout_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

        GtkWidget *window_ajout;
	GtkWidget *window_troupeau;
	window_troupeau=lookup_widget(objet,"window_troupeau");
	gtk_widget_destroy(window_troupeau);
	window_ajout=create_window_ajout();
	gtk_widget_show(window_ajout); 
 
        troupeau t;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;

	char ch1[20];
	char ch2[20];
	char ch3[20];
	

   input1=lookup_widget(objet,"entryidv");
   input2=lookup_widget(objet,"entrycouleurv");
   input3=lookup_widget(objet,"entrypoidsv");

   radiobutton1=lookup_widget(objet,"radiobutton1v"); 
   radiobutton2=lookup_widget(objet,"radiobutton2v"); 

   combobox1=lookup_widget(objet,"comboboxtype1");

   


   jour=lookup_widget(objet,"spinbuttonjourv");
   mois=lookup_widget(objet,"spinbuttonmoisv");
   annee=lookup_widget(objet,"spinbuttonanneev");

   

   combobox2=lookup_widget(objet,"comboboxetatv");


   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));
   

    if( !(strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
       { 

 	  GtkWidget *dialog1;
	  dialog1=create_dialog1() ;
	  gtk_widget_show(dialog1) ;
       }

   else 
       {
	  strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
	  strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
	  strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));

   if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(t.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(t.sexe,"Femelle");}
	  strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	  strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	  tr.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
          tr.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
          tr.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

         GtkWidget *dialog4;
	 dialog4=create_dialog4() ;
	 gtk_widget_show(dialog4) ;
	 ajouter_troupeaux(t);
     }
}*/
///////////////////////////////////////////////////////////////////////

void
on_buttonavalidajouter_clicked         (GtkWidget      *objet,
                                        gpointer         user_data)
{       troupeau t;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;

	char ch1[20];
	char ch2[20];
	char ch3[20];
	

   input1=lookup_widget(objet,"entryidv");
   input2=lookup_widget(objet,"entrycouleurv");
   input3=lookup_widget(objet,"entrypoidsv");

   radiobutton1=lookup_widget(objet,"radiobutton1v"); 
   radiobutton2=lookup_widget(objet,"radiobutton2v"); 

   combobox1=lookup_widget(objet,"comboboxtype1");

   


   jour=lookup_widget(objet,"spinbuttonjourv");
   mois=lookup_widget(objet,"spinbuttonmoisv");
   annee=lookup_widget(objet,"spinbuttonanneev");

   

   combobox2=lookup_widget(objet,"comboboxetatv");


   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));
   

    if( !(strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
       { 

 	  GtkWidget *dialog1;
	  dialog1=create_dialog1() ;
	  gtk_widget_show(dialog1) ;
       }

   else 
       {
	  strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
	  strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
	  strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));

   if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(t.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(t.sexe,"Femelle");}
	  strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	  strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	  t.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
          t.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
          t.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

         GtkWidget *dialog2;
	 dialog2=create_dialog2() ;
	 gtk_widget_show(dialog2) ;
	 ajouter_troupeaux(t);
     }
}






void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

        GtkWidget *window_ajout;
	GtkWidget *window_troupeau;
	window_troupeau=lookup_widget(button,"window_troupeau");
	gtk_widget_destroy(window_troupeau);
	window_ajout=create_window_ajout();
	gtk_widget_show(window_ajout); 
 }
        /*troupeau t;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;

	char ch1[20];
	char ch2[20];
	char ch3[20];
	

   input1=lookup_widget(button,"entryidv");
   input2=lookup_widget(button,"entrycouleurv");
   input3=lookup_widget(button,"entrypoidsv");

   radiobutton1=lookup_widget(button,"radiobutton1v"); 
   radiobutton2=lookup_widget(button,"radiobutton2v"); 

   combobox1=lookup_widget(button,"comboboxtype1");

   


   jour=lookup_widget(button,"spinbuttonjourv");
   mois=lookup_widget(button,"spinbuttonmoisv");
   annee=lookup_widget(button,"spinbuttonanneev");

   

   combobox2=lookup_widget(button,"comboboxetatv");


   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));
   

    if( !(strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
       { 

 	  GtkWidget *dialog1;
	  dialog1=create_dialog1() ;
	  gtk_widget_show(dialog1) ;
       }

   else 
       {
	  strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
	  strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
	  strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));

   if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(t.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(t.sexe,"Femelle");}
	  strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	  strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	  tr.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
          tr.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
          tr.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

         GtkWidget *dialog4;
	 dialog4=create_dialog4() ;
	 gtk_widget_show(dialog4) ;
	 ajouter_troupeaux(t);
     }
}*/


/*void
on_buttonretourtroupeau_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window_ajout;
	GtkWidget *window_troupeau;
	window_ajout=lookup_widget(button,"window_ajout");
	gtk_widget_destroy(window_ajout);
	window_troupeau=create_window_troupeau();
	gtk_widget_show(window_troupeau); 
}*/




void
on_buttonafficheliste_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{ /*GtkWidget *window_troupeau;
      GtkWidget *treeview1;
        troupeau t;
      window_troupeau=lookup_widget(button,"window_troupeau"); 
      treeview1=lookup_widget(window_troupeau,"treeview1");
        afficher(treeview1,t); */  
}


void
on_buttonretourtroupeau_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
       GtkWidget *window_ajout;
   GtkWidget *window_troupeau;
   GtkWidget *treeview1;
   window_ajout=create_window_ajout();
   window_ajout=lookup_widget(button,"window_ajout");
   gtk_widget_hide(window_ajout);
   window_troupeau = create_window_troupeau ();
   gtk_widget_show(window_troupeau);
        troupeau t;
   
      treeview1=lookup_widget(window_troupeau,"treeview1");
        afficher(treeview1,t);   
}

