#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct 
{
int jour;
int mois;
int annee;
}Date;
typedef struct 
{       char identifiant[20];
	char sexe [60];
	char type[60];
	char couleur[60];
	Date date_naissance;
	char poids[60];
	char etat [60];
} troupeau ;

void ajouter_troupeaux(troupeau t);
void supprimer(char *id);
void rechercher_par_type(troupeau t,char type[]);
void afficher(GtkWidget *liste,troupeau t);
void afficher_rech(GtkWidget *liste,troupeau t);
void modifiertroupeaux(char id[],troupeau t);
int Somme(char type[]);
int pourcentage (char type[]);
#endif // FONCTION_H_INCLUDED
