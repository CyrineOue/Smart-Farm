#include "authentification.h"
#include "string.h"
#include <stdio.h>


int verif(auth a)
{
FILE *f;
int role,ad=1,e=1,r=-1 ; 
char user[50] ; 
char password[50] ; 
char id[20]; 

f=fopen("src/users.txt","r"); 
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %d",id,user, password,&role)!=EOF)
{
ad=strcmp(a.user,user);
   e=strcmp(a.pwd,password);
if (ad==0 && e==0)
     r =role;
}
}
fclose(f);
return r;
}

