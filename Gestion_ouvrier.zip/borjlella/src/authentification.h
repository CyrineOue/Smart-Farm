#ifndef VERIFIER_H_INCLUDED
#define VERIFIER_H_INCLUDED

typedef struct 
{
char user[50];
char pwd[50];
}auth; 
 

int verif(auth a);

#endif // VERIFIER_H_INCLUDED

