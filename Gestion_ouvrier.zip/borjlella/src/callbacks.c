#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "authentification.h"
#include "gestionouvriers.h"




void
on_button2_connect_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f;
int r;
int n ; 
auth a ; 

GtkWidget *Login ,*Employee , *Admin; 

GtkWidget *user,*pass; 

user=lookup_widget(objet_graphique,"entry3_identifiant");
pass=lookup_widget(objet_graphique,"entry4_mp");
Login=lookup_widget(objet_graphique,"authentification");

strcpy(a.user,gtk_entry_get_text(GTK_ENTRY(user)));
strcpy(a.pwd,gtk_entry_get_text(GTK_ENTRY(pass)));

n=verif(a);

if (n==2)
{
Employee=create_espacedesgestions();
gtk_widget_show(Employee);
gtk_widget_hide(Login);
}

else 
{
Admin=create_acceuil();
gtk_widget_show(Admin);
gtk_widget_hide(Login);
}

}


void
on_button_Gouvriers_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{



GtkWidget *Gouvrier ,*Gestion , *treeview ; 



Gestion=lookup_widget(objet_graphique,"espacedesgestions");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Gestion);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}


void
on_button_Gequipements_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_Gclients_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_Gcalendrier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_Gtroupeax_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_Gcapteur_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_treeview1_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

int x=0 ;  
char id1[20]; 
char date1[20]; 

Ouvrier o ; 
GtkWidget *treeview ,*Gouv,*treeview1 ,*Gouv1  ; 

gchar *id; 
gchar *nom; 
gchar *prenom;
gchar *sexe;
gchar *cin;
gchar *date;
gchar *tel;
gchar *tache;

Gouv=lookup_widget(objet_graphique,"Gestiondesouvriers");
treeview=lookup_widget(Gouv,"treeview1");

GtkTreeModel *model = gtk_tree_view_get_model(treeview); 

if(gtk_tree_model_get_iter(model,&iter,path)) {

gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0 ,&id,1,&nom,2,&prenom,3,&sexe,4,&cin,5,&date,6,&tel,7,&tache,-1) ; 

strcpy(id1,id); 
strcpy(o.nom,nom);
strcpy(o.prenom,prenom);
strcpy(o.sexe,sexe);
strcpy(o.cin,cin);
strcpy(date1,date);
strcpy(o.tel,tel);
strcpy(o.tache,tache);

supprimer_ouv(id) ; 

afficher_ouv(treeview) ; 
}


}


void
on_b1_ajouter_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Ajout ; 

Gouvrier=lookup_widget(objet_graphique,"Gestiondesouvriers");
Ajout=create_Ajouterouvrier();
gtk_widget_show(Ajout);
gtk_widget_hide(Gouvrier);
}


void
on_b1_supprimer_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char id[200];
GtkWidget *recherche ,*Gouvrier ,*ok ,*insertcin;

insertcin=lookup_widget(objet_graphique,"insertcin");
recherche=lookup_widget(objet_graphique,"rechercheouvrier");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(recherche)));

if (strcmp(id,"")==0) 
{
gtk_label_set_text(GTK_LABEL(insertcin)," Enter ID ! ");
}

else {
supprimer_ouv(id);

Gouvrier=lookup_widget(objet_graphique,"Gestiondesouvriers");
ok=create_Succes();
gtk_widget_show(ok);
gtk_widget_hide(Gouvrier);}

}

char id1[50];
void
on_b1_modifier_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Mod ; 
GtkWidget *recherche ,*insertcin ;

recherche=lookup_widget(objet_graphique,"rechercheouvrier");
insertcin=lookup_widget(objet_graphique,"insertcin");

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(recherche)));

if (strcmp(id1,"")==0) 
{
gtk_label_set_text(GTK_LABEL(insertcin)," Enter ID ! ");
}
else 
{
Gouvrier=lookup_widget(objet_graphique,"Gestiondesouvriers");
Mod=create_Modifierouvrier();
gtk_widget_show(Mod);
gtk_widget_hide(Gouvrier);
}
}

void
on_b1_retour_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Gestion ; 

Gouvrier=lookup_widget(objet_graphique,"Gestiondesouvriers");
Gestion=create_espacedesgestions();
gtk_widget_show(Gestion);
gtk_widget_hide(Gouvrier);
}


void
on_b2_sauvegarde_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Nom , *Pre , *Gen , *CIN , *jj , *mm , *an , *tele , *tach ; 

Ouvrier ouv ;

GtkWidget *ok ,*Ajout ;


gboolean togm ,togf ;  

int jour , mois , anne ; 

Nom=lookup_widget(objet_graphique,"entry_nomouv"); 
Pre=lookup_widget(objet_graphique,"entry6"); 
CIN=lookup_widget(objet_graphique,"entry7");
jj=lookup_widget(objet_graphique,"sb_journ");
mm=lookup_widget(objet_graphique,"sb_moisn");
an= lookup_widget(objet_graphique,"sb_annee");
tele=lookup_widget(objet_graphique,"entry10");
tach= lookup_widget(objet_graphique,"comboboxtache");

strcpy(ouv.nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(ouv.prenom,gtk_entry_get_text(GTK_ENTRY(Pre)));
strcpy(ouv.cin,gtk_entry_get_text(GTK_ENTRY(CIN)));
strcpy(ouv.tel,gtk_entry_get_text(GTK_ENTRY(tele)));

strcpy(ouv.tache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tach)));


ouv.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
ouv.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
ouv.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

 



togm=on_rb_homme_toggled(objet_graphique,user_data);
togf=on_rb_femme_toggled(objet_graphique,user_data);


if (togm) 
  {
   strcpy(ouv.sexe,"male") ; 
  }

if (togf) 
  {
   strcpy(ouv.sexe,"female") ; 
  }

ajouter_ouv(ouv); 

Ajout=lookup_widget(objet_graphique,"Ajouterouvrier");
ok=create_Succes();
gtk_widget_show(ok);
gtk_widget_hide(Ajout);







}


void
on_b2_retour_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Ajout ,*treeview  ; 

Ajout=lookup_widget(objet_graphique,"Ajouterouvrier");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Ajout);


treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}


void
on_calendar1_day_selected              (GtkCalendar     *calendar,
                                        gpointer         user_data)
{

}


void
on_b3_sauvegarder_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *CIN , *jj , *mm , *an ; 
GtkWidget *button; 

button=lookup_widget(objet_graphique,"save");

Point p ; 
char id[20]; 

GtkWidget *ok ,*Ajout  ;



gboolean togA ,togP ;  

int jour , mois , anne ; 


CIN=lookup_widget(objet_graphique,"entry12");
jj=lookup_widget(objet_graphique,"spinday");
mm=lookup_widget(objet_graphique,"spinmonth");
an= lookup_widget(objet_graphique,"spinyear");



strcpy(id,gtk_entry_get_text(GTK_ENTRY(CIN)));


p.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
p.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
p.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

 



togP=on_checkbuttonA_toggled(objet_graphique,user_data);
togA=on_checkbuttonP_toggled(objet_graphique,user_data);


if (togA) 
  {
   strcpy(p.etat,"Absent") ; 
  }

if (togP) 
  {
   strcpy(p.etat,"Present") ; 
  }

pointage(p,id) ; 
gtk_widget_show(button);


/*GtkWidget *Gouvrier ,*Point ,*treeview  ; 

Point=lookup_widget(objet_graphique,"Presence");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Point);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;*/

}


void
on_button1_inscrire_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


gboolean
on_rb_femme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"rb_femme");
	togglebutton2=lookup_widget(objet_graphique,"rb_homme");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton1));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton2),FALSE);
	}
	return etat;
}


gboolean
on_rb_homme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"rb_femme");
	togglebutton2=lookup_widget(objet_graphique,"rb_homme");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton2));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton1),FALSE);
	}
	return etat;
}


void
on_buttonOk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*ok ,*treeview  ; 

ok =lookup_widget(objet_graphique,"Succes");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(ok);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}


void
on_searchouv_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *search , *Gouvrier , *trait, *Gouvrier1 , *trait1 , *treeview  ;

char id2[50]; 
int x=0 ; 

search=lookup_widget(objet_graphique,"rechercheouvrier");
strcpy(id2,gtk_entry_get_text(GTK_ENTRY(search)));

Gouvrier=lookup_widget(objet_graphique,"Gestiondesouvriers");
gtk_widget_hide(Gouvrier);

x++ ; 

if (x==1) 
{
Gouvrier1=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier1);
treeview=lookup_widget(Gouvrier1,"treeview1");
rechercher_ouv(treeview,id2) ;
x=0 ; 
}
else 
treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}

 
void
on_savechange_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char ntel[20] ; 
char ntache[50]; 

GtkWidget *tele ,*tach  ; 


GtkWidget *ok ,*Mod ;


tele=lookup_widget(objet_graphique,"entry16");
tach= lookup_widget(objet_graphique,"combobox2");


strcpy(ntel,gtk_entry_get_text(GTK_ENTRY(tele)));

strcpy(ntache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tach)));

modifier_ouv(id1,ntel,ntache); 

Mod=lookup_widget(objet_graphique,"Modifierouvrier");
ok=create_Succes();
gtk_widget_show(ok);
gtk_widget_hide(Mod);

}


void
on_b_retour_change_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Mod , *treeview ; 

Mod=lookup_widget(objet_graphique,"Modifierouvrier");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Mod);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}


void
on_b_Pointage_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Point ; 
GtkWidget *button; 

button=lookup_widget(objet_graphique,"save");

Gouvrier=lookup_widget(objet_graphique,"Gestiondesouvriers");
Point=create_Presence();
gtk_widget_show(Point);
gtk_widget_hide(Gouvrier);
gtk_widget_hide(button);


}


void
on_b2_retour_2_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Point ,*treeview  ; 

Point=lookup_widget(objet_graphique,"Presence");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Point);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}




gboolean
on_checkbuttonA_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"checkbuttonA");
	togglebutton2=lookup_widget(objet_graphique,"checkbuttonP");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton2));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton1),FALSE);
	}
	return etat;
}


gboolean
on_checkbuttonP_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"checkbuttonA");
	togglebutton2=lookup_widget(objet_graphique,"checkbuttonP");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton1));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton2),FALSE);
	}
	return etat;
}



void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_statbutton_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

int somme ; 
char somme1[2000];
int x ; 

GtkWidget *acc ,*stat,*treeview; 


acc=lookup_widget(objet_graphique,"acceuil");
stat=create_Taux();
gtk_widget_show(stat);
gtk_widget_hide(acc);  
x=idtop() ; 
Top(x); 

treeview=lookup_widget(stat,"treeviewtaux");
afficherbest(treeview) ;





}


void
on_save_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{



GtkWidget  *CIN  ; 


Point p ; 
char id[20]; 

GtkWidget *ok ,*Ajout ;


gboolean togA ,togP ;  

int jour , mois , anne ; 


CIN=lookup_widget(objet_graphique,"entry12");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(CIN)));


togP=on_checkbuttonA_toggled(objet_graphique,user_data);
togA=on_checkbuttonP_toggled(objet_graphique,user_data);


if (togA) 
  {
   strcpy(p.etat,"Absent") ; 
  }

if (togP) 
  {
   strcpy(p.etat,"Present") ; 
  }

 
absence(p,id);

GtkWidget *Gouvrier ,*Point ,*treeview  ; 

Point=lookup_widget(objet_graphique,"Presence");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Point);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;

}


void
on_buttontaux_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
float s;
int somme ; 
char somme1[200];
float total ; 

GtkWidget *sum ; 

sum=lookup_widget(objet_graphique,"tsum");

somme = TauxTotal();
s=((somme*100)/30);
sprintf(somme1,"%.2f",s);
gtk_label_set_text(GTK_LABEL(sum),(somme1));
}


void
on_meilleur_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *taux ,*taux1 ,*trait ,*treeview  ;
int x=0 ;  

taux=lookup_widget(objet_graphique,"Taux");


gtk_widget_hide(taux);



x++ ; 

if (x==1) 
{
taux1=create_Taux();
gtk_widget_show(taux1);
treeview=lookup_widget(taux1,"treeviewtaux");
affichertop(treeview) ;
x=0 ; 
}

}




void
on_buttonliste_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int x=0 ; 

GtkWidget *acc ,*taux,*treeview, *taux1; 

taux=lookup_widget(objet_graphique,"Taux");
gtk_widget_hide(taux);
x++ ; 

if (x==1) 
{
taux1=create_Taux();
gtk_widget_show(taux1);
treeview=lookup_widget(taux1,"treeviewtaux");
afficherbest(treeview) ;
x=0 ; 
}
}


void
on_buttonretourstat_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int somme ; 
char somme1[2000];
int x ; 

GtkWidget *acc ,*stat,*treeview; 


stat=lookup_widget(objet_graphique,"Taux");
acc=create_acceuil();
gtk_widget_show(acc);
gtk_widget_hide(stat);  


}


void
on_bt_deconnect_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *acc1 ,*esp,*treeview; 


esp=lookup_widget(objet_graphique,"espacedesgestions");
acc1=create_authentification();
gtk_widget_show(acc1);
gtk_widget_hide(esp); 
}


void
on_bt2_deconnect_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *authh, *acadmin; 

acadmin=lookup_widget(objet_graphique,"acceuil");
authh=create_authentification();
gtk_widget_show(authh);
gtk_widget_hide(acadmin);
}

