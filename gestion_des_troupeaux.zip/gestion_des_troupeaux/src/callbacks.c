#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "troupeau.h"


troupeau tr;
troupeau t;

void on_gestion_troupeaux_clicked  (GtkWidget  *button, gpointer user_data)
{
   GtkWidget *window_gestions;
   GtkWidget *window_troupeau;
   window_gestions=create_window_gestions();
   window_gestions=lookup_widget(button,"window_gestions");
   gtk_widget_hide(window_gestions);
   window_troupeau = create_window_troupeau ();
   gtk_widget_show (window_troupeau);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonajouter_clicked  (GtkButton *button, gpointer user_data)
{

        GtkWidget *window_ajout;
	window_ajout=create_window_ajout();
	gtk_widget_show(window_ajout); 
 }

/////////////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonvalideajouter_clicked (GtkWidget *objet, gpointer  user_data)
{
     troupeau t1;
        troupeau t;
        FILE *f;
        f=fopen("troupeaux.txt","r");
  
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *comboboxtype;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *comboboxetat;

        GtkWidget *dialog1;
	GtkWidget *dialog2;
        GtkWidget *dialogerreurid;
        GtkWidget *dialogcomboboxvide;
	int fail=0;


   input1=lookup_widget(objet,"entryidv");
   input2=lookup_widget(objet,"entrycouleurv");
   input3=lookup_widget(objet,"entrypoidsv");

   radiobutton1=lookup_widget(objet,"radiobutton1v"); 
   radiobutton2=lookup_widget(objet,"radiobutton2v"); 

   comboboxtype=lookup_widget(objet,"comboboxtype1");


   jour=lookup_widget(objet,"spinbuttonjourv");
   mois=lookup_widget(objet,"spinbuttonmoisv");
   annee=lookup_widget(objet,"spinbuttonanneev");

   
   comboboxetat=lookup_widget(objet,"comboboxetatv");

     

 	 strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
    		 {
        	      strcpy(t.sexe,"Male");
     		 }

             else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
                 {
         	      strcpy(t.sexe,"Femelle");
                 }

	// strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtype)));
	  strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
	  
	  t.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	  t.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	  t.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

            
          strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));
    //strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxetat)));
   

if (( gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtype))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxetat))==NULL))
{
          dialogcomboboxvide=create_dialogcomboboxvide() ;//combobox vide
	  gtk_widget_show(dialogcomboboxvide) ; 
	  fail=1;
	
}

if( (!strcmp(t.identifiant,"")) || (!strcmp(t.couleur,"")) || (!strcmp(t.poids,""))  )
       { 
	  dialog1=create_dialog1() ;//champs vides
	  gtk_widget_show(dialog1) ;
	  fail=1;
       }


  
f=fopen("troupeaux.txt","r");
 if (f==NULL)
{return;}
else 
                  {
                      while (fscanf(f,"%s %s %s %s %d %d %d %s %s  \n",t1.identifiant,t1.sexe,t1.type,t1.couleur,&t1.date_naissance.jour,&t1.date_naissance.mois,&t1.date_naissance.annee,t1.poids,t1.etat)!=EOF) 
                           {
                                 if (strcmp(t.identifiant,t1.identifiant)==0)
                                       { 
          	                           dialogerreurid=create_dialogerreurid() ;//id existe
	                                   gtk_widget_show(dialogerreurid) ;
					   fail=1;
	                                   break;
          
                                       }
                         }
fclose(f);

                 }

             

          
               
if(fail==0)

     {      
		
         
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtype)));
strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxetat)));


                      dialog2=create_dialog2() ;//ajout avec succés
	              gtk_widget_show(dialog2) ;
                      SupEspace(t.identifiant);
		      SupEspace2(t.poids);
                      SupEspace1(t.couleur);
	              ajouter_troupeaux(t);

    }

}


///////////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonretourtrp_clicked  (GtkButton *button, gpointer user_data)
{
   GtkWidget *window_ajout;
   GtkWidget *window_troupeau;
   //GtkWidget *treeview1;
  

  // window_ajout=create_window_ajout();
   window_ajout=lookup_widget(button,"window_ajout");
   gtk_widget_destroy(window_ajout);
   //gtk_widget_hide(window_ajout);
   //window_troupeau = create_window_troupeau ();
   //gtk_widget_show(window_troupeau);
}

///////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonsupp_clicked (GtkWidget  *objet, gpointer user_data)

{ 
         GtkWidget *dialog5;

	 dialog5=create_dialog5() ;
	 gtk_widget_show(dialog5) ;
}


//////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonoui_clicked (GtkButton *button, gpointer  user_data)
{

    	supprimer(t.identifiant);

	GtkWidget *window_troupeau; 
	GtkWidget *treeview1;
        GtkWidget *dialog5;

        window_troupeau=lookup_widget(GTK_WIDGET(button),"window_troupeau");
	treeview1=lookup_widget(button,"treeview1");
	gtk_widget_show(treeview1);
        afficher(treeview1,tr);
        dialog5=lookup_widget(GTK_WIDGET(button),("dialog5"));
	gtk_widget_destroy(dialog5);
}
////////////////////////////////////////////////////////////////////////////////////////////
void on_buttonnon_clicked (GtkButton *button,gpointer user_data)
{
        GtkWidget *dialog5;

        dialog5=lookup_widget(GTK_WIDGET(button),("dialog5"));
	gtk_widget_destroy(dialog5);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonaffiche_clicked (GtkButton  *button, gpointer  user_data)
{
      GtkWidget *window_troupeau;
      GtkWidget *treeview1;

      troupeau t;
      window_troupeau=lookup_widget(button,"window_troupeau"); 
      treeview1=lookup_widget(window_troupeau,"treeview1");
      afficher(treeview1,t);
}
//////////////////////////////////////////////////////////////////////////////////////////
void on_buttonrecherche_clicked (GtkWidget  *button, gpointer user_data)
{ 
	
	GtkWidget *radio1;
	GtkWidget *radio2;
	GtkWidget *window1;
	GtkWidget *treeview1;
	char type[40];
	troupeau t;

	radio1=lookup_widget(button,"radiobuttonchoix1"); 
	radio2=lookup_widget(button,"radiobuttonchoix2"); 

        window1=lookup_widget(button,"window_troupeau");
        treeview1=lookup_widget(window1,"treeview1");

	    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio1))==TRUE)
                {  
                  strcpy(type,"Veau");
                }
            else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio2))==TRUE)
                {   
                 strcpy(type,"Brebi");
                }

        afficher_rech(treeview1,type);
	//rechercher_par_type(t,type);
}


/////////////////////////////////////////////////////////////////////////////////

void on_buttonmodifier_clicked (GtkWidget  *objet, gpointer  user_data)
{

	 GtkWidget *window1;
	 window1=create_window_modif();
	 gtk_widget_show(window1); 
	
	GtkWidget *identifiant;
	GtkWidget *window_modif;
	GtkWidget *couleur;
	GtkWidget *poids;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox1;
	GtkSpinButton *jour;
	GtkSpinButton *mois;
	GtkSpinButton *annee;
	GtkWidget *combobox2;

identifiant=lookup_widget(window1,"entryidmod");
gtk_entry_set_text(GTK_ENTRY(identifiant),t.identifiant);

couleur=lookup_widget(window1,"entrycouleurmod");
gtk_entry_set_text(GTK_ENTRY(couleur),t.couleur);

poids=lookup_widget(window1,"entrypoidsmod");
gtk_entry_set_text(GTK_ENTRY(poids),t.poids);

radiobutton1=lookup_widget(objet,"radiobutton1mod"); 
radiobutton2=lookup_widget(objet,"radiobutton2mod"); 

combobox1=lookup_widget(objet,"comboboxtypemod");
//gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1));

jour=lookup_widget(window1,"spinbuttonjourmod");
gtk_spin_button_set_value(jour,t.date_naissance.jour);

mois=lookup_widget(window1,"spinbuttonmoismod");
gtk_spin_button_set_value(mois,t.date_naissance.mois);

annee=lookup_widget(window1,"spinbuttonanneemod");
gtk_spin_button_set_value(annee,t.date_naissance.annee);


combobox2=lookup_widget(objet,"comboboxetatmod");
//gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2));

if (strcmp(t.type, "Brebi") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1), 0);
  }
  else if (strcmp(t.type,"Veau") == 0)
  {
      gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1), 1);
  }


if ((strcmp(t.sexe, "Femelle") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton1), 0);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton2), 1);
  }
  else if ((strcmp(t.sexe, "Male") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton1), 1);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton2), 0);
  }
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(t.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(t.sexe,"Femelle");
      }
 
}


///////////////////////////////////////////////////////////////////////////////////////////////////////


void on_buttonquitter_clicked (GtkWidget *button, gpointer user_data)
{

	GtkWidget *window_gestions;
	GtkWidget *window_troupeau;

	window_troupeau=lookup_widget(button,"window_troupeau");
	gtk_widget_destroy(window_troupeau);
	window_gestions=create_window_gestions();
	gtk_widget_show(window_gestions);  
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_treeview1_row_activated (GtkTreeView   *treeview, GtkTreePath  *path, GtkTreeViewColumn *column,  gpointer  user_data)
{

	gchar *data0;
	gchar *data1;
	gchar *data2;
	gchar *data3;
	gchar *data4;
	gchar *data5;
	gchar *data6;


	GtkListStore *list_store;
	list_store=gtk_tree_view_get_model(treeview);
	GtkTreeIter   iter;

          if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
 	    {
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &data0, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,1, &data1, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,2, &data2, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &data3, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,4, &data4, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,5, &data5, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,6, &data6, -1);


	strcpy (t.identifiant, data0);
	strcpy (t.sexe, data1);
	strcpy (t.type, data2);
	strcpy (t.couleur, data3);
	sscanf (data4,"%d/%d/%d",&t.date_naissance.jour,&t.date_naissance.mois,&t.date_naissance.annee);
	strcpy (t.poids, data5);
	strcpy (t.etat, data6);
	//supprimer(data0);


	   }

}

///////////////////////////////////////////////////////////////////////////////////////////

void on_buttonnombre_clicked   (GtkButton *button,gpointer  user_data)
{

	int nbr;
	char msg[120]="";
	char type[20];


	GtkWidget *output;
	GtkWidget *combobox1;
        GtkWidget *window3;
        GtkWidget *dialogchoix;
	

	window3=lookup_widget(button,"window_tableau_de_bord");
	combobox1=lookup_widget(button,"comboboxchoix");
        output=lookup_widget(button,"labelnombre");

     if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL)
       { 
	  dialogchoix=create_dialogchoix() ;
	  gtk_widget_show(dialogchoix) ;
       }
       else 
       {

        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
        nbr=Somme(type);

        sprintf(msg,"%d",nbr);
        gtk_label_set_text(output,msg);
        }
 
}
////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton1_clicked (GtkWidget *button, gpointer user_data)
{
	GtkWidget *dialog1;

        dialog1=lookup_widget(GTK_WIDGET(button),("dialog1"));
	gtk_widget_destroy(dialog1);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton2_clicked (GtkWidget *button,gpointer user_data)
{
	GtkWidget *dialog2;

        dialog2=lookup_widget(GTK_WIDGET(button),("dialog2"));
	gtk_widget_destroy(dialog2);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonstat_clicked  (GtkButton *button,gpointer   user_data)
{
   GtkWidget *window_admin;
   GtkWidget *window_tableau_de_bord;

   window_admin=create_window_admin();
   window_admin=lookup_widget(button,"window_admin");
   gtk_widget_hide(window_admin);
   window_tableau_de_bord = create_window_tableau_de_bord ();
   gtk_widget_show (window_tableau_de_bord);
}

///////////////////////////////////////////////////////////////////////////////////
void
on_buttonretouraccueiladmin_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_admin;
	GtkWidget *window_tableau_de_bord;

	window_tableau_de_bord=lookup_widget(button,"window_tableau_de_bord");
	gtk_widget_destroy(window_tableau_de_bord);
	window_admin=create_window_admin();
	gtk_widget_show(window_admin);  
}


void
on_buttonpourcentage_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
        float pr;
	char msg[120]="";
	char type[20];

	GtkWidget *output;
        GtkWidget *window3;
	GtkWidget *combobox1;
        GtkWidget *dialogchoix;
        
        

        combobox1=lookup_widget(button,"comboboxmaladie");
	window3=lookup_widget(button,"window_tableau_de_bord");
        output=lookup_widget(button,"labelpourcentage");


   

      if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL)
       { 
	  dialogchoix=create_dialogchoix() ;
	  gtk_widget_show(dialogchoix) ;
       }
       else 
       {

        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
        pr=pourcentage(type);
        sprintf(msg," %.2f%%",pr );
        gtk_label_set_text(output,msg);
	}

if(pr>=60)
{
         GtkWidget *dialogalerte;
	 dialogalerte=create_dialogalerte() ;
	 gtk_widget_show(dialogalerte) ;
}
}


void
on_closebuttonalerte_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1;

        dialog1=lookup_widget(GTK_WIDGET(button),("dialogalerte"));
	gtk_widget_destroy(dialog1);
}


void
on_retourmod_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

        GtkWidget *window1;
	
	window1=lookup_widget(button,"window_modif");
	gtk_widget_destroy(window1);
}


void
on_validemodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{       
       
	
       troupeau t1;
	
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;
	
	GtkWidget *dialog6;
	GtkWidget *dialog1;

	GtkWidget *dialogcomboboxvide;
	char ch1[20];
	char ch2[20];
	char ch3[30];
	char id[30];
	

  
   input1=lookup_widget(objet,"entryidmod");
   input2=lookup_widget(objet,"entrycouleurmod");
   input3=lookup_widget(objet,"entrypoidsmod");

   radiobutton1=lookup_widget(objet,"radiobutton1mod"); 
   radiobutton2=lookup_widget(objet,"radiobutton2mod"); 

   combobox1=lookup_widget(objet,"comboboxtypemod");

   jour=lookup_widget(objet,"spinbuttonjourmod");
   mois=lookup_widget(objet,"spinbuttonmoismod");
   annee=lookup_widget(objet,"spinbuttonanneemod");

   t.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
   t.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
   t.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
   

   combobox2=lookup_widget(objet,"comboboxetatmod");

   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));

   

  
if( (!strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
       { 
	  dialog1=create_dialog1() ;//champs vides
	  gtk_widget_show(dialog1) ;
       }
  

 else if (( gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))==NULL))
{
         dialogcomboboxvide=create_dialogcomboboxvide() ;//comboboxvide
	  gtk_widget_show(dialogcomboboxvide) ; 
}
else {
   strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));
      
  strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
  strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
 if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(t.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(t.sexe,"Femelle");
       }
		      
		      modifiertroupeaux(t.identifiant,t);
		      SupEspace(t.identifiant);
		      SupEspace2(t.poids);
                      SupEspace1(t.couleur);
                      dialog6=create_dialog6() ;
	              gtk_widget_show(dialog6) ;
                     


    
}
}

////////////////////////////////////////////////////////////////////////////
void
on_buttonmodifok_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog6=lookup_widget(GTK_WIDGET(button),("dialog6"));

gtk_widget_destroy(dialog6);
}



//////////////////////////////////////////////////////////////////////////
void
on_closebuttonerreurchoixstat_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogchoix=lookup_widget(GTK_WIDGET(button),("dialogchoix"));

gtk_widget_destroy(dialogchoix);
}

//////////////////////////////////////////////////////////////////////////////
void
on_closebuttonerreurid_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *dialogerreurid=lookup_widget(GTK_WIDGET(button),("dialogerreurid"));

gtk_widget_destroy(dialogerreurid);
}

//////////////////////////////////////////////////////////////////////////////////
void
on_closebuttoncombovide_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogcomboboxvide=lookup_widget(GTK_WIDGET(button),("dialogcomboboxvide"));

gtk_widget_destroy(dialogcomboboxvide);
}

