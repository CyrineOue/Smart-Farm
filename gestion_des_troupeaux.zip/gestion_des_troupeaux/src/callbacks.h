#include <gtk/gtk.h>


void
on_gestion_troupeaux_clicked           (GtkWidget       *button,
                                        gpointer         user_data);


void
on_buttonquitter_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkWidget       *button,
                                        gpointer         user_data);


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_closebutton2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);



void
on_buttonnombre_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonstat_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonretouraccueiladmin_clicked    (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonoui_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonnon_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffiche_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonvalideajouter_clicked         (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonretourtrp_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonpourcentage_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonalerte_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourmod_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_validemodif_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonmodifok_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonpourcentage_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonerreurchoixstat_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonerreurid_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttoncombovide_clicked        (GtkButton       *button,
                                        gpointer         user_data);
