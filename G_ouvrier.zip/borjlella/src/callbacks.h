#include <gtk/gtk.h>


void
on_button2_connect_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Gouvriers_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Gequipements_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Gclients_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Gcalendrier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Gtroupeax_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Gcapteur_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_b1_ajouter_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b1_supprimer_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b1_modifier_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b1_retour_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b2_sauvegarde_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b2_retour_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_calendar1_day_selected              (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_b3_sauvegarder_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_inscrire_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_rb_femme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_rb_homme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonOk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_searchouv_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_savechange_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b_retour_change_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b_Pointage_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b2_retour_2_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbuttonP_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbuttonA_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_checkbuttonA_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_checkbuttonP_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_statbutton_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttontaux_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_meilleur_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonliste_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourstat_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_bt_deconnect_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_bt2_deconnect_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
