#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <string.h>
#include <gtk/gtk.h>
#include "plante.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *id;
gchar *type;
gchar *stock,*recoltee;

char recolte[50],plantation[20];
char ref[20];
PLANTE p;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &id,1,&type,2,&recoltee,3,&stock,4,-1);
strcpy(p.id,id);
strcpy(p.type,type);
strcpy(p.stock,stock);
strcpy(p.recoltee,recoltee);
sprintf(plantation,"%d/%d/%d",p.plantation.jour,p.plantation.mois,p.plantation.annee);
sprintf(recolte,"%d/%d/%d",p.recolte.jour,p.recolte.mois,p.recolte.annee);
suppression(ref);
affichage(treeview);
}
}
void
on_Supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
/*	GtkWidget *input;
	GtkWidget *dialog2;

	PLANTE p;
	char ref[20];


    input=lookup_widget(button,"entry10");
    strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input)));
    suppression(ref);
      if(strcmp(ref,p.id)==0)
         { 
	     
	     dialog2=create_dialog2() ;
	     gtk_widget_show(dialog2) ;
         }
 */     
}

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_afficher=lookup_widget(button,"window_calendrier");
treeview1=lookup_widget(fenetre_afficher,"treeview1"); 
    gtk_widget_show (fenetre_afficher);
affichage(treeview1);
}


void
on_rechercher_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
char RF[30];
GtkWidget *window_GC;
GtkWidget *entry;
GtkWidget *treeview;
FILE *f;
FILE* f2;


window_GC=lookup_widget(button,"window_calendrier");
entry=lookup_widget(button,"entry10");
strcpy(RF,gtk_entry_get_text(GTK_ENTRY(entry)));
f=fopen("plantations.txt","r");

 if(f!=NULL)
 {
  while(fscanf(f,"%s %s %d %d/%d/%d %d/%d/%d\n",p.id,p.type,&p.stock,&p.plantation.jour,&p.plantation.mois,&p.plantation.annee,&p.recolte.jour,&p.recolte.mois,&p.recolte.annee)!=EOF)
     {
       f2=fopen("tmp.txt","a+");
       if  (f2!=NULL)
   {  
     
     if ((strcmp(p.id,RF)==0))
     { 
      fprintf(f2,"%s %s %d %d/%d/%d %d/%d/%d\n",p.id,p.type,p.stock,p.plantation.jour,p.plantation.mois,p.plantation.annee,p.recolte.jour,p.recolte.mois,p.recolte.annee);
     }
   
     treeview=lookup_widget(window_GC,"treeview1");
     recherche(treeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("tmp.txt");
}
                /*xxx=lookup_widget(button,"dialog4");
                  gtk_widget_show(dialog);*/

void
on_Ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
PLANTE p;

GtkWidget *dialog;
GtkWidget *input1,*input2;
GtkWidget *ajout;
GtkWidget *choix1,*choix2,*choix3,*choix4;
GtkWidget *jour1,*mois1,*annee1;
GtkWidget *jour2,*mois2,*annee2;
GtkWidget *stock;
choix1=lookup_widget(button,"choix1");
choix2=lookup_widget(button,"choix2");
choix3=lookup_widget(button,"choix3");
choix4=lookup_widget(button,"choix4");
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix1))==TRUE)
  {strcpy(p.type,"tomate");}
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix2))==TRUE)
  {strcpy(p.type,"pomme");}
else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix3))==TRUE)
  {strcpy(p.type,"fraise");}
else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix4))==TRUE)
  {strcpy(p.type,"avocat");}
ajout=lookup_widget(button,"plantation");
input2=lookup_widget(button,"entry11");
input1=lookup_widget(button,"entryid");
stock=lookup_widget(button,"spinbutton1");

jour1=lookup_widget(button,"jour1");
mois1=lookup_widget(button,"mois1");
annee1=lookup_widget(button,"annee1");

jour2=lookup_widget(button,"jour2");
mois2=lookup_widget(button,"mois2");
annee2=lookup_widget(button,"annee2");

strcpy(p.recoltee,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
p.stock=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(stock));

p.plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
p.plantation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
p.plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));

p.recolte.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour2));
p.recolte.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois2));
p.recolte.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee2));

ajouter(p);
dialog=create_dialog1();
gtk_widget_show(dialog);

}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutedate, *calendrier;

ajoutedate=lookup_widget(button,"window_calendrier");
gtk_widget_destroy(ajoutedate);

calendrier=create_window_calendrier();
gtk_widget_show(calendrier);
}

//////////




void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

