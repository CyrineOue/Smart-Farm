#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "plante.h"
#include <gtk/gtk.h>
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
EID,
ETYPE,
ESTOCK,
ERECOLTEE,
EPLANTATION,
ERECOLTE,
COLUMNS
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ajouter(PLANTE p)

{
FILE *f;
f=fopen("plantations.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %d %s %d/%d/%d %d/%d/%d\n",p.id,p.type,p.stock,p.recoltee,p.plantation.jour,p.plantation.mois,p.plantation.annee,p.recolte.jour,p.recolte.mois,p.recolte.annee);
fclose(f);
}
}
///////////////////////////////////////
void recherche(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

PLANTE p;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Plante id ",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("     Type     ",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Stock (kg)",renderer,"text",ESTOCK,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Recolte (kg)",renderer,"text",ERECOLTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date de plantation",renderer,"text",EPLANTATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date de recolte",renderer,"text",ERECOLTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("plantations.txt","r");
if (f==NULL)
{
return;
}
else 
{
while(fscanf(f,"%s %s %s %s/%s/%s %s/%s/%s\n",p.id,p.type,&p.stock,&p.plantation.jour,&p.plantation.mois,&p.plantation.annee,&p.recolte.jour,&p.recolte.mois,&p.recolte.annee)!=EOF) 

{
gtk_list_store_append (store, &iter);
gtk_list_store_set(store, &iter,EID,p.id, ETYPE, p.type, ESTOCK,p.stock, EPLANTATION,p.plantation, ERECOLTE,p.recolte, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

//////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////
void affichage(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char date1[20],date2[20],stock1[20];


PLANTE p;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Plante id ",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("     Type     ",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Stock (kg)",renderer,"text",ESTOCK,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Recolte (kg)",renderer,"text",ERECOLTEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date de plantation",renderer,"text",EPLANTATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Date de recolte",renderer,"text",ERECOLTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("plantations.txt","r");
if (f==NULL)
{
return;
}
else 
{ f=fopen("plantations.txt","a+");
while(fscanf(f,"%s %s %d %s %d/%d/%d %d/%d/%d\n",p.id,p.type,&p.stock,p.recoltee,&p.plantation.jour,&p.plantation.mois,&p.plantation.annee,&p.recolte.jour,&p.recolte.mois,&p.recolte.annee)!=EOF) 

{sprintf(date1,"%d/%d/%d",p.plantation.jour,p.plantation.mois,p.plantation.annee);
sprintf(date2,"%d/%d/%d",p.recolte.jour,p.recolte.mois,p.recolte.annee);
sprintf(stock1,"%d",p.stock);
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, EID,p.id, ETYPE, p.type, ESTOCK,stock1,ERECOLTEE,p.recoltee, EPLANTATION,date1, ERECOLTE,date2, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void suppression(char ref[20])
{

PLANTE p;
FILE *f ,*F;

f=fopen("plantations.txt","r"); 
F=fopen("tmp.txt","w"); 

if ((f==NULL) || (F==NULL))
{
return ; 
}
else 
{
while(fscanf(f,"%s %s %d %s %d/%d/%d %d/%d/%d\n",p.id,p.type,&p.stock,p.recoltee,&p.plantation.jour,&p.plantation.mois,&p.plantation.annee,&p.recolte.jour,&p.recolte.mois,&p.recolte.annee)!=EOF)
	{
	  if (strcmp(ref,p.id)!=0)
	{
	   fprintf(F,"%s %s %d %s %d/%d/%d %d/%d/%d\n",p.id,p.type,p.stock,p.recoltee,p.plantation.jour,p.plantation.mois,p.plantation.annee,p.recolte.jour,p.recolte.mois,p.recolte.annee);
	}
	}
	fclose(f);
	fclose(F);
remove("plantations.txt");
rename("tmp.txt","plantations.txt");
}
}
/*///////////////////////////////////////////////////////////////////////////////////////////////////////////
void modification(char ref[20],PLANTE p)
{
PLANTE z;
char id[20];
suppression(z);
ajouter(z);
}*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/


