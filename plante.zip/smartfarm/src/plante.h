#include <gtk/gtk.h>
typedef struct
{
int jour,mois,annee;
}DATEE;


typedef struct
{
char type[20];
char id[20];
char recoltee[20];
int stock;
DATEE plantation;
DATEE recolte;
}PLANTE;

void ajouter(PLANTE p);
void recherche(GtkWidget *liste);
void suppression(char ref[20]);
void affichage(GtkWidget *liste);
void modification(char ref[20], PLANTE p);





