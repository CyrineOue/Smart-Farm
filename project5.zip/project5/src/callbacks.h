#include <gtk/gtk.h>


void
on_YBbutton_LC_R_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_RE_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_M_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_S_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_A_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_A_A_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_A_AFF_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_A_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_M_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_AFF_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBtreeview_LC_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_YBbutton_LC_AFF_clicked             (GtkButton       *button,
                                        gpointer         user_data);
