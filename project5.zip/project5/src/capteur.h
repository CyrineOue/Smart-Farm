#include <gtk/gtk.h>
typedef struct
{
char Ref_Cap[30];
char Type_Cap[30];
int Valeur;
int Val_Inf;
int Val_Sup;
}CAPTEUR;

void ajout(CAPTEUR c);
void recherche(GtkWidget *YBtreeview_LC);
void suppression(char RF[30]);
void affichage(GtkWidget *YBtreeview_LC);
void modification(char rf[30],CAPTEUR c);

