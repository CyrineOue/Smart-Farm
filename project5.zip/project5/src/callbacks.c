#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include <stdlib.h>

void
on_YBbutton_LC_R_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR c;char RF[30];
GtkWidget *window_GC;
GtkWidget *YBentry_LC_R;
GtkWidget *YBtreeview_LC;
FILE*f;
FILE*f2;


window_GC=lookup_widget(button,"window_GC");
YBentry_LC_R=lookup_widget(button,"YBentry_LC_R");
strcpy(RF,gtk_entry_get_text(GTK_ENTRY(YBentry_LC_R)));
f=fopen("capteurs.txt","r");

 if(f!=NULL)
 {
  while(fscanf(f,"%s %s %d %d %d",c.Ref_Cap,c.Type_Cap,&c.Valeur,&c.Val_Inf,&c.Val_Sup)!=EOF)
     {
       f2=fopen("recherche.txt","ab+");
       if  (f2!=NULL)
   {  
     
     if ((strcmp(c.Ref_Cap,RF)==0))
     { 
     fprintf(f2,"%s %s %d %d %d",c.Ref_Cap,c.Type_Cap,c.Valeur,c.Val_Inf,c.Val_Sup);
     }
   
     YBtreeview_LC=lookup_widget(window_GC,"YBtreeview_LC");
     recherche(YBtreeview_LC);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("recherche.txt");
}


void
on_YBbutton_LC_RE_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBbutton_LC_M_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBbutton_LC_S_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
char RF[30];
GtkWidget *input;

    input=lookup_widget(button,"YBentry_LC_S");
    strcpy(RF,gtk_entry_get_text(GTK_ENTRY(input)));
    suppression(RF);

}          



void
on_YBbutton_LC_A_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBbutton_A_A_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR c;
GtkWidget *YBentry_A_RC;
GtkWidget *YBentry_A_TC;
GtkWidget *YBspinbutton_A_V;
GtkWidget *YBspinbutton_A_VI;
GtkWidget *YBspinbutton_A_VS;

YBspinbutton_A_V=lookup_widget(button, "YBspinbutton_A_V");
YBspinbutton_A_VI=lookup_widget(button, "YBspinbutton_A_VI");
YBspinbutton_A_VS=lookup_widget(button, "YBspinbutton_A_VS");
YBentry_A_RC=lookup_widget(button,"YBentry_A_RC");
YBentry_A_TC=lookup_widget(button,"YBentry_A_TC");

strcpy(c.Ref_Cap,gtk_entry_get_text(GTK_ENTRY(YBentry_A_RC)));
strcpy(c.Type_Cap,gtk_entry_get_text(GTK_ENTRY(YBentry_A_TC)));
c.Valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YBspinbutton_A_V));
c.Val_Inf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YBspinbutton_A_VI));
c.Val_Sup=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YBspinbutton_A_VS));


ajout(c);
}


void
on_YBbutton_A_AFF_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBbutton_A_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBbutton_M_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBbutton_M_M_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR c;char rf[30];
GtkWidget *YBentry_M_RC;
GtkWidget *YBentry_M_TC;
GtkWidget *YBspinbutton_M_V;
GtkWidget *YBspinbutton_M_VI;
GtkWidget *YBspinbutton_M_VS;

YBspinbutton_M_V=lookup_widget(button, "YBspinbutton_M_V");
YBspinbutton_M_VI=lookup_widget(button, "YBspinbutton_M_VI");
YBspinbutton_M_VS=lookup_widget(button, "YBspinbutton_M_VS");
YBentry_M_RC=lookup_widget(button,"YBentry_M_RC");
YBentry_M_TC=lookup_widget(button,"YBentry_M_TC");

strcpy(c.Ref_Cap,gtk_entry_get_text(GTK_ENTRY(YBentry_M_RC)));
strcpy(c.Type_Cap,gtk_entry_get_text(GTK_ENTRY(YBentry_M_TC)));
c.Valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YBspinbutton_M_V));
c.Val_Inf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YBspinbutton_M_VI));
c.Val_Sup=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YBspinbutton_M_VS));
modification(rf,c);
}


void
on_YBbutton_M_AFF_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_YBtreeview_LC_row_activated         (GtkTreeView     *YBtreeview_LC,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *Ref_Cap,*Type_Cap;
        CAPTEUR c;char RF[30];char Valeur[30];char Val_Inf[30];char Val_Sup[30];
	GtkTreeModel *Model = gtk_tree_view_get_model(YBtreeview_LC);

		if (gtk_tree_model_get_iter(Model,&iter,path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,0,&Ref_Cap,1,&Type_Cap,2,&Valeur,3,&Val_Inf,4,&Val_Sup ,-1);
                                strcpy(c.Ref_Cap,Ref_Cap);
                                strcpy(c.Type_Cap,Type_Cap);
				sprintf(Valeur,"%d",c.Valeur);
				sprintf(Val_Inf,"%d",c.Val_Inf);
				sprintf(Val_Sup,"%d",c.Val_Sup);
			

 suppression(RF);
 affichage(YBtreeview_LC);
}
}

void
on_YBbutton_LC_AFF_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *YBtreeview_LC;

fenetre_afficher=lookup_widget(button,"window_GC");
YBtreeview_LC=lookup_widget(fenetre_afficher,"YBtreeview_LC"); 
    gtk_widget_show (fenetre_afficher);
affichage(YBtreeview_LC);

}

