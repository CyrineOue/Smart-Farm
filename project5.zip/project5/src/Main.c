#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "capteur.h"
int main ()
{
while(1)
{
int Options;
{
printf("\n\t1-Ajouter une réference");
printf("\n\t2-Rechercher une réference");
printf("\n\t3-Supprimer une réference");
printf("\n\t4-Afficher les Capteurs");
printf("\n\t5-Modifier une réference");
scanf("%d",&Options);
}
switch(Options)
{
case(1):
ajout();
break;
case(2):
rechercher();
break;
case(3):
supprission();
break;
case(4):
Affichage();
break;
case(5):
modification();
break;
case(6):
default:
printf("Options non valide, veuillez réessayer");
break;}
}
return(0);}
