#include <stdlib.h>
#include <stdio.h>
#include<string.h>

#include "capteur.h"


enum{REF_CAP,TYPE_CAP,VALEUR,VAL_INF,VAL_SUP,COLUMNS};
//------------------------------------------------------********---------------------------------------------------
void affichage(GtkWidget* YBtreeview_LC)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
CAPTEUR c;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(YBtreeview_LC);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Ref_Cap", renderer, "text",REF_CAP, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (YBtreeview_LC), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type_Cap", renderer, "text",TYPE_CAP, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (YBtreeview_LC), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Valeur", renderer, "text",VALEUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (YBtreeview_LC), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Val_Inf", renderer, "text",VAL_INF, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (YBtreeview_LC), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Val_Sup", renderer, "text",VAL_SUP, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (YBtreeview_LC), column);}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("capteurs.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("capteurs.bin","ab+");
while(fread(&c,sizeof(CAPTEUR),1,f))
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,REF_CAP,c.Ref_Cap,TYPE_CAP,c.Type_Cap,VALEUR,c.Valeur,VAL_INF,c.Val_Inf,VAL_SUP,c.Val_Sup,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(YBtreeview_LC),GTK_TREE_MODEL (store));
g_object_unref(store);}}


//-------------------------------------------------------*******-----------------------------------------------------------

void ajout (CAPTEUR c){
FILE*f; 
char val_inf[30];char valeur[30];char val_sup[30];
sprintf(val_inf,"%d",c.Val_Inf);
sprintf(valeur,"%d",c.Valeur);
sprintf(val_sup,"%d",c.Val_Sup);
f=fopen("capteurs.txt","a+");
if(f==NULL)
return;
else{
fprintf(f,"%s %s %s %s %s\n",c.Ref_Cap,c.Type_Cap,valeur,val_inf,val_sup); 
fclose(f);
}
}
//------------------------------------------------------------------------------------------------------------------------

void suppression(char RF[30],CAPTEUR c){
FILE*f;
FILE*g;
f=fopen("capteurs.bin","rb+");
g=fopen("tmp.bin","wb+");
if(g!=NULL){
while(fread(&c,sizeof(CAPTEUR),1,f))
{
if (strcmp(c.Ref_Cap,RF)!=0){
fwrite(&c,sizeof(CAPTEUR),1,g);

}
}
}fclose(f);
fclose(g);
remove("capteurs.bin");
rename("tmp.bin","capteurs.bin");
}

//------------------------------------------------------------------------------------------------------------------------

void modification(char RF[30],CAPTEUR c)
{

	suppression(RF,c);
	ajout(c);

}
//------------------------------------------------------------------------------------------------------------------------
void recherche(GtkWidget* YBtreeview_LC)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;CAPTEUR c;
 FILE *f2; 
 store=gtk_tree_view_get_model(YBtreeview_LC);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Ref_Cap",renderer, "text",REF_CAP,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type_Cap",renderer, "text",TYPE_CAP,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEUR,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Val_Inf",renderer, "text",VAL_INF,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Val_Sup",renderer, "text",VAL_SUP,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);}
  
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("recherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("recherche.bin", "ab+");
    while(fread(&c,sizeof(CAPTEUR),1,f2))
     {
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,REF_CAP,c.Ref_Cap,TYPE_CAP,c.Type_Cap,VALEUR,c.Valeur,VAL_INF,c.Val_Inf,VAL_SUP,c.Val_Sup,-1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (YBtreeview_LC), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
