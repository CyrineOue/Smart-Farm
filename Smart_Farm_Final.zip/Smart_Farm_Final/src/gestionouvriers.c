#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "gestionouvriers.h"

int idp ;
void ajouter_ouv(Ouvrier ouv)
{


	FILE *f;
		f=fopen("ouvriers.txt","a+");
	if (f!= NULL)
	{	
		idp++;
		fprintf(f,"%d %s %s %s %s %d/%d/%d %s %s \n",idp, ouv.nom , ouv.prenom , ouv.sexe, ouv.cin, ouv.jour,ouv.mois,ouv.anne, ouv.tel, ouv.tache);
		fclose(f);
                 
	}

}




enum 
{
ID,
NOM ,
PRENOM,
SEXE,
CIN, 
DATEDENAISSANCE,
TELEPHONE,
TACHE, 
COLUMNS0
}; 


void afficher_ouv(GtkWidget *liste)
{
GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;

char id[20] ; 
char nom[30] ;
char prenom[30] ;
char sexe[30];
char cin[30];  
char date[30];
char tel[30]; 
char tache[30];  
store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Id",render,"text",ID,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Nom",render,"text",NOM,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Prenom",render,"text",PRENOM,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Sexe",render,"text",SEXE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Cin",render,"text",CIN,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Datedenaissance",render,"text",DATEDENAISSANCE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Telephone",render,"text",TELEPHONE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Tache",render,"text",TACHE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


store=gtk_list_store_new(COLUMNS0,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING) ; 

f=fopen("ouvriers.txt","r") ; 
if (f==NULL) 
{
return ; 
}
else 
{
f=fopen("ouvriers.txt","a+") ;
 while(fscanf(f,"%s %s %s %s %s %s %s %s \n" ,id,nom,prenom,sexe,cin,date,tel,tache)!=EOF) 
{
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,ID,id,NOM,nom,PRENOM,prenom,SEXE,sexe,CIN,cin,DATEDENAISSANCE,date,TELEPHONE,tel,TACHE,tache,-1) ; 
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 

}
}


void supprimer_ouv(char id[])
{
FILE *f;
FILE *f1;
Ouvrier o ; 
char idscan[20]; 
char date[20]; 
int r=0;
f=fopen("ouvriers.txt","r");
f1=fopen("ouvriers1.txt","w");
if (f!=NULL){
    if(f1!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,o.tel,o.tache)!=EOF ) {
    if(strcmp(id,idscan)!=0){
        fprintf(f1,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,o.tel,o.tache);
        r=1;
    }
}
    }
    fclose(f1);
}

fclose(f);
if (r){
	remove ("ouvriers.txt");
	rename ("ouvriers1.txt","ouvriers.txt");
	}

}

void modifier_ouv(char id1[], char ntel[], char ntache[]) 
{
Ouvrier o ; 




FILE *f;
FILE *f1;

char date[50]; 
char idscan[20];
 

f=fopen("ouvriers.txt","r");
f1=fopen("ouvriers1.txt","w");
if (f!=NULL)
{
    if(f1!=NULL)
     {
while(fscanf(f,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,o.tel,o.tache)!=EOF ) 
{
    if(strcmp(id1,idscan)==0)
            {
              if (strcmp(ntel,"")==0)
            {fprintf(f1,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,o.tel,ntache);}
        else fprintf(f1,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,ntel,ntache);
            }
     else 
          {fprintf(f1,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,o.tel,o.tache);} 
}
}
}
fclose(f1);
fclose(f);

	remove ("ouvriers.txt");
	rename ("ouvriers1.txt","ouvriers.txt");
	
}



void rechercher_ouv(GtkWidget *liste,char id2[])
{
GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;

char id[20] ; 
char nom[30] ;
char prenom[30] ;
char sexe[30];
char cin[30];  
char date[30];
char tel[30]; 
char tache[30];  
store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Id",render,"text",ID,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Nom",render,"text",NOM,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Prenom",render,"text",PRENOM,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Sexe",render,"text",SEXE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Cin",render,"text",CIN,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Datedenaissance",render,"text",DATEDENAISSANCE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Telephone",render,"text",TELEPHONE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Tache",render,"text",TACHE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


store=gtk_list_store_new(COLUMNS0,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING) ; 

f=fopen("ouvriers.txt","r") ; 
if (f==NULL) 
{
return ; 
}
else 
{
f=fopen("ouvriers.txt","a+") ;
 while(fscanf(f,"%s %s %s %s %s %s %s %s \n" ,id,nom,prenom,sexe,cin,date,tel,tache)!=EOF) 
{
   if (strcmp(id,id2)==0) {
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,ID,id,NOM,nom,PRENOM,prenom,SEXE,sexe,CIN,cin,DATEDENAISSANCE,date,TELEPHONE,tel,TACHE,tache,-1) ; 
}
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 

}
}



void pointage(Point p ,char id[])
{
Ouvrier o ; 


FILE *f;
FILE *f1;
FILE *f2;


char date[20]; 
int n=1 ; 
char idscan[20]; 
 

f=fopen("ouvriers.txt","r");
f1=fopen("pointages.txt","a");
f2=fopen("test.txt","a+");

if (f!=NULL)
{
    if(f1!=NULL)
     {
       if (f2!=NULL) 
          {
while(fscanf(f,"%s %s %s %s %s %s %s %s \n" ,idscan,o.nom,o.prenom,o.sexe,o.cin,date,o.tel,o.tache)!=EOF ) 
                                     {
    if(strcmp(id,idscan)==0)
            					{
            strcpy(p.nom,o.nom); 
            strcpy(p.prenom,o.prenom);
        fprintf(f1,"%s %s %s %d/%d/%d %s %s \n" ,idscan,p.nom,p.prenom,p.j,p.m,p.a,o.cin,p.etat);

             if  (strcmp(p.etat,"Absent")==0) 
		{
                     fprintf(f2,"%s %s %s %s %d \n" ,idscan,p.nom,p.prenom,o.cin,n);
         
		}
						}
                                      }
       }                  
           
    }
}
fclose(f2);
fclose(f1);
fclose(f);


	
}

void absence(Point p,char id1[])
{



FILE *f;
FILE *f1;

char date[20]; 
int n=1 ; 
int t=0  ; 
int x=0 ; 
char idtest[20] ; 

char cin[20]; 

char nom[20] ; 
char prenom[20]; 
char cinn[20]; 


f=fopen("test.txt","r");
f1=fopen("absences.txt","w"); 
if (f!=NULL)
{
    if(f1!=NULL)
     {
         while(fscanf(f,"%s %s %s %s %d \n" ,idtest,p.nom,p.prenom,cin,&t)!=EOF ) 
               		 {    
                  if (strcmp(id1,idtest)==0) {x++ ; strcpy(nom,p.nom);strcpy(prenom,p.prenom);strcpy(cinn,cin);}
                         else  fprintf(f1,"%s %s %s %s %d \n" ,idtest,p.nom,p.prenom,cin,t);
                	 }
		 fprintf(f1,"%s %s %s %s %d \n" ,id1,nom,prenom,cinn,x);
    }
}
fclose(f1);
fclose(f);



	//remove ("src/absences.txt");
	//rename ("src/absences1.txt","src/absences.txt");
}


                          
enum 
{
ID1,
NOM1 ,
PRENOM1,
CIN1, 
TAUX1,
COLUMNS1
}; 



void afficherbest(GtkWidget *liste)
{

GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;

char id[20] ; 
char nom[30] ;
char prenom[30] ;
char cin[30];
int j ; 
float taux ;  
store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Id",render,"text",ID1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Nom",render,"text",NOM1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Prenom",render,"text",PRENOM1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Cin",render,"text",CIN1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Absence",render,"text",TAUX1,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT) ; 

f=fopen("absences.txt","r") ;
if (f==NULL) 
{
return ; 
}
else 
{
f=fopen("absences.txt","a+") ;
 while(fscanf(f,"%s %s %s %s %d \n" ,id,nom,prenom,cin,&j)!=EOF)  
{
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,ID1,id,NOM1,nom,PRENOM1,prenom,CIN1,cin,TAUX1,j,-1) ; 
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 

}

}


int TauxTotal(){
FILE *f;

Ouvrier o ;

char id[20];
char nom[20];
char prenom[20];
char cin[20];
 
int n ; 
int j  ; 
int x=0 ; 
char idtest[20] ; 
f=fopen("absences.txt","r") ;
if (f!=NULL)
{
         while(fscanf(f,"%s %s %s %s %d \n" ,id,nom,prenom,cin,&j)!=EOF ) 
               		 {    
                             x+=j;
                	 }		    
}
fclose(f);

return x ;
}

int idtop(){
FILE *f;


Ouvrier o ;

int id;
char nom[20];
char prenom[20];
char cin[20];
int id1;
 
int n=100 ; 
int j  ; 
int x=0 ; 
char idtest[20] ; 
f=fopen("absences.txt","r") ;

if (f!=NULL)
{
         while(fscanf(f,"%d %s %s %s %d \n" ,&id,nom,prenom,cin,&j)!=EOF ) 
               		 {    
                           if (n>j) n=j ;  
                	 }
	

}


fclose(f);
x=n;
return x ; 
}




void Top(int x)
{
FILE *f;
FILE *f1;

Ouvrier o ;

int id;
char nom[20];
char prenom[20];
char cin[20];

 
 
int j  ; 
 

f=fopen("absences.txt","r") ;
f1=fopen("meilleur.txt","w") ;

if (f!=NULL)
{
	if (f1!=NULL)
		{
         while(fscanf(f,"%d %s %s %s %d \n" ,&id,nom,prenom,cin,&j)!=EOF ) 
               		 {    
                            if (x==j) fprintf(f1,"%s %s \n" ,nom,prenom);
                	 }


		}
}

fclose(f1);
fclose(f);
}



enum 
{
NOM3,
PRENOM3,
COLUMNS3
};


void affichertop(GtkWidget *liste)
{

GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;


char nom[30] ;
char prenom[30] ;

store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Nom",render,"text",NOM3,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("Prenom",render,"text",PRENOM3,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 




store=gtk_list_store_new(COLUMNS3,G_TYPE_STRING,G_TYPE_STRING) ; 

f=fopen("meilleur.txt","r") ;
if (f==NULL) 
{
return ; 
}
else 
{
f=fopen("meilleur.txt","a+") ;
 while(fscanf(f,"%s %s \n" ,nom,prenom)!=EOF)  
{
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,NOM3,nom,PRENOM3,prenom,-1) ; 
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 

}

}



