
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "gestionemployes.h"


void ajouteremploye(employe e)
{
FILE *f;
int role =2;
f=fopen("employes.txt","a+");
if(f!=NULL)
{
 fprintf(f,"%s %s %s %s %s %s %d %d %d %d \n",e.cin,e.matricule,e.password,e.nom,e.prenom,e.numtel,e.date.jour,e.date.mois,e.date.annee,role);
}

fclose(f);
}

//////////////////////////////////////////////////
enum
{	CIN,
	MATRICULE, 
	PASSWORD,
	NOM,
	PRENOM,
	NUMTEL,
	DATE,
	COLUMNS,
};


void afficherlisteemployes(GtkWidget *liste,employe e)
{
FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	int role;
	
	char daterecru[60];


store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",CIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("matricule", renderer, "text",MATRICULE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("password", renderer, "text", PASSWORD, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text", NOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",PRENOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("num tel", renderer, "text", NUMTEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date de recrutement", renderer, "text", DATE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);

f=fopen("employes.txt","r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen("employes.txt","a+");
	while (fscanf(f,"%s %s %s %s %s %s %d %d %d %d \n",e.cin,e.matricule,e.password,e.nom,e.prenom,e.numtel,&e.date.jour,&e.date.mois,&e.date.annee,&role)!=EOF)

{
 sprintf(daterecru,"%d/%d/%d",e.date.jour,e.date.mois,e.date.annee);
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,CIN, e.cin, MATRICULE,e.matricule,PASSWORD,e.password,NOM, e.nom, PRENOM, e.prenom, NUMTEL,e.numtel,DATE,daterecru, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//////////////////////////////////////////////////
void supprimeremploye(char *cin)
{
	employe e2;
	FILE *f ,*F;
	int role =2;


	f=fopen("employes.txt","r"); 
	F=fopen("employes2.txt","w"); 

	if ((f==NULL) || (F==NULL))
	{
		return ; 
	}
	else 
	{
		while (fscanf(f,"%s %s %s %s %s %s %d %d %d %d \n",e2.cin,e2.matricule,e2.password,e2.nom,e2.prenom,e2.numtel,&e2.date.jour,&e2.date.mois,&e2.date.annee,&role)!=EOF)
			{
			  if (strcmp(cin,e2.cin)!=0)
			  {
				  fprintf(F,"%s %s %s %s %s %s %d %d %d %d \n",e2.cin,e2.matricule,e2.password,e2.nom,e2.prenom,e2.numtel,&e2.date.jour,&e2.date.mois,&e2.date.annee,role);
			  }
			}
			fclose(f);
			fclose(F);
		remove("employes.txt");
		rename("employes2.txt","employes.txt");
	}
}
///////////////////////////////////////////////////

void rechercheemploye (employe e,char matri[20])
{


        FILE *f;
	FILE *f1;
	int role =2;
        f=fopen("employes.txt","r");
        f1=fopen("employesrech.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %d %d %d %d \n",e.cin,e.matricule,e.password,e.nom,e.prenom,e.numtel,&e.date.jour,&e.date.mois,&e.date.annee,&role)!=EOF)
        {
                 if(strcmp(e.matricule,matri)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %d %d %d \n",e.cin,e.matricule,e.password,e.nom,e.prenom,e.numtel,e.date.jour,e.date.mois,e.date.annee,role);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
//////////////////////////////////////////////////

void afficherrecherchecin(GtkWidget *liste,employe e)
{FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char daterecru[60];


store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",CIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("matricule", renderer, "text",MATRICULE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("password", renderer, "text", PASSWORD, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text", NOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",PRENOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("num tel", renderer, "text", NUMTEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date de recrutement", renderer, "text", DATE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);

f=fopen("employesrech.txt","r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen("employesrech.txt","a+");
	while (fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",e.cin,e.matricule,e.password,e.nom,e.prenom,e.numtel,&e.date.jour,&e.date.mois,&e.date.annee)!=EOF)

{
 sprintf(daterecru,"%d/%d/%d",e.date.jour,e.date.mois,e.date.annee);
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,CIN, e.cin, MATRICULE,e.matricule,PASSWORD,e.password,NOM, e.nom, PRENOM, e.prenom, NUMTEL,e.numtel,DATE,daterecru, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
} 
////////////////////////////////////////////////////////////////////////////////////
int verifier (char login[50], char password[50])
{
   int res=-1;
 employe e;
    int role=2;
    FILE *f;
   f=fopen("employes.txt","r");

   do
   {
     fscanf(f,"%s %s %s %s %s %s %d %d %d %d \n",e.cin,e.matricule,e.password,e.nom,e.prenom,e.numtel,&e.date.jour,&e.date.mois,&e.date.annee,&role);
     if (strcmp(e.matricule,login)==0)
         {
             if(strcmp(e.password,password)==0)
             {
                 res=role;
             }
         }

     } while(!feof(f)&&(res==-1));
     return res ;
}


