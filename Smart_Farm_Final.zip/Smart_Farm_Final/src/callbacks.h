#include <gtk/gtk.h>


void
on_gestion_troupeaux_clicked           (GtkWidget       *button,
                                        gpointer         user_data);


void
on_buttonquitter_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkWidget       *button,
                                        gpointer         user_data);


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_closebutton2_clicked                (GtkWidget       *button,
                                        gpointer         user_data);



void
on_buttonnombre_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonstat_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonretouraccueiladmin_clicked    (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonoui_clicked                   (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonaffiche_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonvalideajouter_clicked         (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_buttonretourtrp_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonpourcentage_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonalerte_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourmod_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_validemodif_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);
/////////////////////////////////////////////////////////////////////
void
on_treeview1cy_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_listeemployess_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherchecy_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajoutcy_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifcy_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuppcy_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_gestion_employes_clicked            (GtkButton       *button,
                                        gpointer         user_data);


void
on_validecymod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_oksupp_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourcymod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_validerajout_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonmodif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretouradmin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttondeconnexion_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfermermodif_clicked           (GtkButton       *button,
                                        gpointer         user_data);



void
on_ajoutereq_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifiereq_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_treevieweq_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_buttonafficheeq_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvalide_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonsupp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonajouteq_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbuttonmodifeq_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);



void
on_retourmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestion_equipements_clicked         (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonmodifeq_clicked               (GtkButton       *button,
                                        gpointer         user_data);





void
on_buttonaccueiladmin_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonnom_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherstatistiquescy_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitterequipement_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonerreurempl_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonerreurchoixstat_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonerreurid_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttoncombovide_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonerreurmatricule_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttoncomboeq_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonchampseqvide_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonexiste_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Gouvriers_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_b_Pointage_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewouv_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_b1_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_searchouv_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitterouvrier_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_b1_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_b1_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_b2_retour_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_b2_sauvegarde_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_closebuttonajoutouv_clicked         (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_rb_femme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_rb_homme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_checkbuttonA_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_checkbuttonP_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_b3_sauvegarder_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_b2_retour_2_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_savechange_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_b_retour_change_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontaux_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_meilleur_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonliste_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonmodifouv_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLtreeview_row_activated            (GtkTreeView     *KLtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_KLbutton_rechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_ajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonkhmodif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_enregistrer_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_retour1_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Gestion_des_clients_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLretouracceuil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_afficher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonajoutclient_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_valider_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_retour2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonmodifclient_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonsuppouv_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBtreeview_LC_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_YBbutton_LC_A_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_M_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_S_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonacceuilcapteur_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_R_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_LC_AFF_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoncapteur_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_A_A_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_A_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_M_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonajoutcap_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonmodifcap_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonsuppcap_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBbutton_M_M_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_authentification_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonauth_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttondeconnexionadmin_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_acceuilplante_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifider_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewchi_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retourajoutplante_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_valideajoutplante_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongestioncalen_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonajoutplante_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_aps_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_sauvegarderplante_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebuttonmodifaplante_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourplantemod_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonouiplante_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonnonplante_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_modifer_clicked            (GtkButton       *button,
                                        gpointer         user_data);


void
on_KLbutton_fid_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBcheckbutton_A_MPD_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_YBcheckbutton_VA_MPD_clicked        (GtkButton       *button,
                                        gpointer         user_data);
