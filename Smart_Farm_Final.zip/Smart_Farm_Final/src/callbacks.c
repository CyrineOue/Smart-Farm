#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "troupeau.h"
#include "gestionemployes.h"
#include "gestionequipements.h"
#include "gestionouvriers.h"
#include "client.h"
#include "capteur.h"
#include "plante.h"


char vgiden[20], vgsex[20],vgtyp[20],vgcoul[20],vgpoids[20],vgdt[20],vgetat[20];

char gid[50];
char gtypep[50], gstock[50], grecolte[50], gdtpl[50], gdtrec[50];
/////////////////////////////////////////////////////////////////
employe e2;
equipement eq2;
troupeau tr;
troupeau t;
///////////////////////////////////////////////////////////////////
void
on_authentification_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *log;
GtkWidget *output;
GtkWidget *output1;
const char *format;
char *markup;
char msg[50];
char msg1[50];
char login[20];
employe e;

char password[30];
input1=lookup_widget(button,"entrylogin");
input2=lookup_widget(button,"entrypassword");
log=lookup_widget(button,"window_auth");
output=lookup_widget(button,"labelerreur");
output1=lookup_widget(button,"labelincorrect");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

/*if ((login,"")||(password,""))
{
    gtk_label_set_text(GTK_LABEL(output), "");
    format = "<span foreground=\"black\"><b>\%s</b></span>";
    sprintf(msg, "champs vide !!");
    markup= g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(output), markup);



}*/
if ((strcmp(e.matricule,login )!=0)||(!strcmp(e.password,password)!=0))
{

    gtk_label_set_text(GTK_LABEL(output1), "");
    format = "<span foreground=\"black\"><b>\%s</b></span>";
    sprintf(msg1, " coordonnées invalides");
    markup= g_markup_printf_escaped(format, msg1);
    gtk_label_set_markup(GTK_LABEL(output1), markup);


}

if(verifier(login,password)==2) 
      {
         gtk_widget_hide(log);
	 GtkWidget *window_gestions;
	 window_gestions=create_window_gestions ();
	  gtk_widget_show(window_gestions);
      }

if (strcmp(login,"admin")==0 && strcmp(password,"admin")==0) 
{
gtk_widget_hide(log);
GtkWidget *admin;
admin=create_window_admin();
gtk_widget_show(admin);
}


}

void on_gestion_troupeaux_clicked  (GtkWidget  *button, gpointer user_data)
{
   GtkWidget *window_gestions;
   GtkWidget *window_troupeau;
   window_gestions=create_window_gestions();
   window_gestions=lookup_widget(button,"window_gestions");
 gtk_window_set_position(GTK_WINDOW(window_gestions),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_hide(window_gestions);
   window_troupeau = create_window_troupeau ();
 gtk_window_set_position(GTK_WINDOW(window_troupeau),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_show (window_troupeau);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonajouter_clicked  (GtkButton *button, gpointer user_data)
{

        GtkWidget *window_ajout;
	//GtkWidget *window_troupeau;
	//window_troupeau=lookup_widget(button,"window_troupeau");
	//gtk_widget_destroy(window_troupeau);
	window_ajout=create_window_ajout();
	gtk_widget_show(window_ajout); 
 }

/////////////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonvalideajouter_clicked (GtkWidget *objet, gpointer  user_data)
{
         troupeau t1;
        troupeau t;
        FILE *f;
        f=fopen("troupeaux.txt","r");
  
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *comboboxtype;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *comboboxetat;

        GtkWidget *dialog1;
	GtkWidget *dialog2;
        GtkWidget *dialogerreurid;
        GtkWidget *dialogcomboboxvide;
	int fail=0;
	const char *format;
	char *markup, msg[50];
	GtkWidget *output;
	
	output=lookup_widget(objet,"labelidexiste");
   input1=lookup_widget(objet,"entryidv");
   input2=lookup_widget(objet,"entrycouleurv");
   input3=lookup_widget(objet,"entrypoidsv");

   radiobutton1=lookup_widget(objet,"radiobutton1v"); 
   radiobutton2=lookup_widget(objet,"radiobutton2v"); 

   comboboxtype=lookup_widget(objet,"comboboxtype1");


   jour=lookup_widget(objet,"spinbuttonjourv");
   mois=lookup_widget(objet,"spinbuttonmoisv");
   annee=lookup_widget(objet,"spinbuttonanneev");

   
   comboboxetat=lookup_widget(objet,"comboboxetatv");

     

 	 strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
    		 {
        	      strcpy(t.sexe,"Male");
     		 }

             else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
                 {
         	      strcpy(t.sexe,"Femelle");
                 }

	// strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtype)));
	  strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
	  
	  t.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	  t.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	  t.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

            
          strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));
    //strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxetat)));
   

if (( gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtype))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxetat))==NULL))
{
          dialogcomboboxvide=create_dialogcomboboxvide() ;//combobox vide
	  gtk_widget_show(dialogcomboboxvide) ; 
	  fail=1;
	
}

if( (!strcmp(t.identifiant,"")) || (!strcmp(t.couleur,"")) || (!strcmp(t.poids,""))  )
       { 
	  dialog1=create_dialog1() ;//champs vides
	  gtk_widget_show(dialog1) ;
	  fail=1;
       }


  
f=fopen("troupeaux.txt","r");
 if (f==NULL)
{return;}
else 
                  {
                      while (fscanf(f,"%s %s %s %s %d %d %d %s %s  \n",t1.identifiant,t1.sexe,t1.type,t1.couleur,&t1.date_naissance.jour,&t1.date_naissance.mois,&t1.date_naissance.annee,t1.poids,t1.etat)!=EOF) 
                           {
                                 if (strcmp(t.identifiant,t1.identifiant)==0)
                                       { 
          	                          gtk_label_set_text(GTK_LABEL(output), "");
   					 format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
                                         sprintf(msg, "Identifiant existe déjà !");
                                         markup= g_markup_printf_escaped(format, msg);
                                          gtk_label_set_markup(GTK_LABEL(output), markup);
					   fail=1;
	                                   break;
          
                                       }
                         }
fclose(f);

                 }

             

          
               
if(fail==0)

     {      
		
         
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxtype)));
strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxetat)));
//strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));

                      dialog2=create_dialog2() ;//ajout avec succés
	              gtk_widget_show(dialog2) ;
		      SupEspace(t.identifiant);
		      SupEspace2(t.poids);
                      SupEspace1(t.couleur);
	              ajouter_troupeaux(t);

    }
}
////////////////////////////////////////////////////////////////////////////
void
on_closebuttonerreurchoixstat_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogchoix=lookup_widget(GTK_WIDGET(button),("dialogchoix"));

gtk_widget_destroy(dialogchoix);
}

/////////////////////////////////////////////////////////////////////////////
void
on_closebuttonerreurid_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogerreurid=lookup_widget(GTK_WIDGET(button),("dialogerreurid"));

gtk_widget_destroy(dialogerreurid);
}
///////////////////////////////////////////////////////////////////////////////

void
on_closebuttoncombovide_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogcomboboxvide=lookup_widget(GTK_WIDGET(button),("dialogcomboboxvide"));

gtk_widget_destroy(dialogcomboboxvide);
}



///////////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonretourtrp_clicked  (GtkButton *button, gpointer user_data)
{
   GtkWidget *window_ajout;
   
  
      window_ajout=lookup_widget(button,"window_ajout");
      gtk_widget_destroy(window_ajout);
}

///////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonsupp_clicked (GtkWidget  *objet, gpointer user_data)

{ 
         GtkWidget *dialog5;

	 dialog5=create_dialog5() ;
	 gtk_widget_show(dialog5) ;
}


//////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonoui_clicked (GtkButton *button, gpointer  user_data)
{

    	supprimer(vgiden);

	GtkWidget *window_troupeau; 
	GtkWidget *treeview1;
        GtkWidget *dialog5;

        window_troupeau=lookup_widget(GTK_WIDGET(button),"window_troupeau");
	treeview1=lookup_widget(button,"treeview1");
	gtk_widget_show(treeview1);
        afficher(treeview1,tr);
        dialog5=lookup_widget(GTK_WIDGET(button),("dialog5"));
	gtk_widget_destroy(dialog5);
}
////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonnom_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *dialog5;
        dialog5=lookup_widget(GTK_WIDGET(button),("dialog5"));
	gtk_widget_destroy(dialog5);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonaffiche_clicked (GtkButton  *button, gpointer  user_data)
{
      GtkWidget *window_troupeau;
      GtkWidget *treeview1;

      troupeau t;
      window_troupeau=lookup_widget(button,"window_troupeau"); 
      treeview1=lookup_widget(window_troupeau,"treeview1");
      afficher(treeview1,t);
}
//////////////////////////////////////////////////////////////////////////////////////////
void on_buttonrecherche_clicked (GtkWidget  *button, gpointer user_data)
{ 
	
	GtkWidget *radio1;
	GtkWidget *radio2;
	GtkWidget *window1;
	GtkWidget *treeview1;
	char type[40];
	troupeau t;

	radio1=lookup_widget(button,"radiobuttonchoix1"); 
	radio2=lookup_widget(button,"radiobuttonchoix2"); 

        window1=lookup_widget(button,"window_troupeau");
        treeview1=lookup_widget(window1,"treeview1");

	    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio1))==TRUE)
                {  
                  strcpy(type,"Veau");
                }
            else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio2))==TRUE)
                {   
                 strcpy(type,"Brebi");
                }

        afficher_rech(treeview1,type);
}


/////////////////////////////////////////////////////////////////////////////////

void on_buttonmodifier_clicked (GtkWidget  *objet, gpointer  user_data)
{


	 GtkWidget *window1;
	 window1=create_window_modif();
	 gtk_widget_show(window1); 
	
	GtkWidget *identifiant;
	GtkWidget *window_modif;
	GtkWidget *couleur;
	GtkWidget *poids;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox1;
	GtkSpinButton *jour;
	GtkSpinButton *mois;
	GtkSpinButton *annee;
	GtkWidget *combobox2;


identifiant=lookup_widget(window1,"entryidmod");
gtk_entry_set_text(GTK_ENTRY(identifiant),vgiden);

couleur=lookup_widget(window1,"entrycouleurmod");
gtk_entry_set_text(GTK_ENTRY(couleur),vgcoul);

poids=lookup_widget(window1,"entrypoidsmod");
gtk_entry_set_text(GTK_ENTRY(poids),vgpoids);

radiobutton1=lookup_widget(objet,"radiobutton1mod"); 
radiobutton2=lookup_widget(objet,"radiobutton2mod"); 

combobox1=lookup_widget(objet,"comboboxtypemod");


jour=lookup_widget(window1,"spinbuttonjourmod");
gtk_spin_button_set_value(jour,t.date_naissance.jour);

mois=lookup_widget(window1,"spinbuttonmoismod");
gtk_spin_button_set_value(mois,t.date_naissance.mois);

annee=lookup_widget(window1,"spinbuttonanneemod");
gtk_spin_button_set_value(annee,t.date_naissance.annee);


combobox2=lookup_widget(objet,"comboboxetatmod");


if (strcmp(vgtyp, "Brebi") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1), 0);
  }
  else if (strcmp(vgtyp,"Veau") == 0)
  {
      gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1), 1);
  }

if (strcmp(vgetat, "Malade") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2), 0);
  }
  else if (strcmp(vgetat,"Sain") == 0)
  {
      gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2), 1);
  }



if ((strcmp(vgsex, "Femelle") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton1), 0);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton2), 1);
  }
  else if ((strcmp(vgsex, "Male") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton1), 1);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(radiobutton2), 0);
  }

 
}


///////////////////////////////////////////////////////////////////////////////////////////////////////


void on_buttonquitter_clicked (GtkWidget *button, gpointer user_data)
{

	GtkWidget *window_gestions;
	GtkWidget *window_troupeau;

	window_troupeau=lookup_widget(button,"window_troupeau");
	gtk_widget_destroy(window_troupeau);
	window_gestions=create_window_gestions();
	gtk_widget_show(window_gestions);  
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_treeview1_row_activated (GtkTreeView   *treeview, GtkTreePath  *path, GtkTreeViewColumn *column,  gpointer  user_data)
{

	GtkTreeIter iter;
  
        gchar *id;
  	gchar *sex;
	gchar *typ;
	gchar *coul;
	gchar *poids;
	gchar *dt;
	gchar *etat;
        GtkTreeModel *model = gtk_tree_view_get_model(treeview);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id, 1, &sex, 2, &typ, 3, &coul, 4, &dt, 5, &poids, 6, &etat, -1);
    strcpy (vgiden,id);
	strcpy (vgsex,sex);
	strcpy (vgtyp,typ);
	strcpy (vgcoul,coul);
	sscanf (vgdt,"%d/%d/%d",&t.date_naissance.jour,&t.date_naissance.mois,&t.date_naissance.annee);
	strcpy (vgpoids,poids);
	strcpy (vgetat,etat);
  }
}

///////////////////////////////////////////////////////////////////////////////////////////

void on_buttonnombre_clicked   (GtkButton *button,gpointer  user_data)
{

	int nbr;
	char msg[120]="";
	char type[20];

	GtkWidget *output;
	GtkWidget *combobox;
        GtkWidget *window3;
	GtkWidget *dialogchoix;

	window3=lookup_widget(button,"window_tableau_de_bord");
	combobox=lookup_widget(button,"comboboxchoix");
        output=lookup_widget(button,"labelnombre");

     if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox))==NULL)
       { 
	  dialogchoix=create_dialogchoix() ;
	  gtk_widget_show(dialogchoix) ;
       }
       else 
       {

        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
        nbr=Somme(type);

        sprintf(msg," %d",nbr);
        gtk_label_set_text(output,msg);
        }
 
 
}
////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton1_clicked (GtkWidget *button, gpointer user_data)
{
	GtkWidget *dialog1;

        dialog1=lookup_widget(GTK_WIDGET(button),("dialog1"));
	gtk_widget_destroy(dialog1);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_closebutton2_clicked (GtkWidget *button,gpointer user_data)
{
	GtkWidget *dialog2;

        dialog2=lookup_widget(GTK_WIDGET(button),("dialog2"));
	gtk_widget_destroy(dialog2);
}

////////////////////////////////////////////////////////////////////////////////////////////

void on_buttonstat_clicked  (GtkButton *button,gpointer   user_data)
{
   GtkWidget *window_admin;
   GtkWidget *window_tableau_de_bord;

   window_admin=create_window_admin();
   window_admin=lookup_widget(button,"window_admin");
   gtk_widget_hide(window_admin);
   window_tableau_de_bord = create_window_tableau_de_bord ();
   gtk_widget_show (window_tableau_de_bord);
}

///////////////////////////////////////////////////////////////////////////////////
void
on_buttonretouraccueiladmin_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_admin;
	GtkWidget *window_tableau_de_bord;

	window_tableau_de_bord=lookup_widget(button,"window_tableau_de_bord");
	gtk_widget_destroy(window_tableau_de_bord);
	window_admin=create_window_admin();
	gtk_widget_show(window_admin);  
}

///////////////////////////////////////////////////////////////////////
void
on_buttonpourcentage_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
        float pr;
	char msg[120]="";
	char type[20];

	GtkWidget *output;
        GtkWidget *window3;
	GtkWidget *combobox1;
        GtkWidget *dialogchoix;
        
        

        combobox1=lookup_widget(button,"comboboxpourcentage");
	window3=lookup_widget(button,"window_tableau_de_bord");
        output=lookup_widget(button,"labelpourcentage");


   

      if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL)
       { 
	  dialogchoix=create_dialogchoix() ;
	  gtk_widget_show(dialogchoix) ;
       }
       else 
       {

        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
        pr=pourcentage(type);
        sprintf(msg," %.2f%%",pr );
        gtk_label_set_text(output,msg);
	}

if(pr>=60)
{
         GtkWidget *dialogalerte;
	 dialogalerte=create_dialogalerte() ;
	 gtk_widget_show(dialogalerte) ;
}
}

/////////////////////////////////////////////////////////////////////////////////////
void
on_closebuttonalerte_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1;

        dialog1=lookup_widget(GTK_WIDGET(button),("dialogalerte"));
	gtk_widget_destroy(dialog1);
}

//////////////////////////////////////////////////////////////////////////////////
void
on_retourmod_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

        GtkWidget *window1;
	
	window1=lookup_widget(button,"window_modif");
	gtk_widget_destroy(window1);
}
///////////////////////////////////////////////////////////////////////////////

void
on_validemodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
        

       troupeau t1;
	
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;

	GtkWidget *combobox1;
	GtkWidget *radiobutton1;
	GtkWidget *radiobutton2;
	GtkWidget *combobox2;
	
	GtkWidget *dialog6;
	GtkWidget *dialog1;

	GtkWidget *dialogcomboboxvide;
	char ch1[20];
	char ch2[20];
	char ch3[30];
	char id[30];
	

  
   input1=lookup_widget(objet,"entryidmod");
   input2=lookup_widget(objet,"entrycouleurmod");
   input3=lookup_widget(objet,"entrypoidsmod");

   radiobutton1=lookup_widget(objet,"radiobutton1mod"); 
   radiobutton2=lookup_widget(objet,"radiobutton2mod"); 

   combobox1=lookup_widget(objet,"comboboxtypemod");

   jour=lookup_widget(objet,"spinbuttonjourmod");
   mois=lookup_widget(objet,"spinbuttonmoismod");
   annee=lookup_widget(objet,"spinbuttonanneemod");

   t.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
   t.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
   t.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
   

   combobox2=lookup_widget(objet,"comboboxetatmod");

   strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(input3)));

   

  
if( (!strcmp(ch1,"")) || (!strcmp(ch2,"")) || (!strcmp(ch3,""))  )
       { 
	  dialog1=create_dialog1() ;//champs vides
	  gtk_widget_show(dialog1) ;
       }
  

 else if (( gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))==NULL))
{
         dialogcomboboxvide=create_dialogcomboboxvide() ;//comboboxvide
	  gtk_widget_show(dialogcomboboxvide) ; 
}
else {
   strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
   strcpy(t.couleur,gtk_entry_get_text(GTK_ENTRY(input2)));
   strcpy(t.poids,gtk_entry_get_text(GTK_ENTRY(input3)));
      
  strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
  strcpy(t.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
 if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton1))==TRUE)
      {
          strcpy(t.sexe,"Male");
      }
   else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton2))==TRUE)
      {
          strcpy(t.sexe,"Femelle");
       }
		      
		       modifiertroupeaux(t.identifiant,t);
                      dialog6=create_dialog6() ;
	              gtk_widget_show(dialog6) ;
                     


    
}
}

////////////////////////////////////gestion_employes///////////////////////////////


void
on_treeview1cy_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{       
gchar *cin;
gchar *matri;
gchar *pass;
gchar *nom;
gchar *prenom;
gchar *numtel;
gchar* dt;


        GtkListStore *list_store;
	list_store=gtk_tree_view_get_model(treeview);
	GtkTreeIter   iter;

          if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
 	    {
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &cin, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,1, &matri, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,2, &pass, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &nom, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,4, &prenom, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,5, &numtel, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,6, &dt, -1);
		

	strcpy (e2.cin, cin);
	strcpy (e2.matricule, matri);
	strcpy (e2.password, pass);
	strcpy (e2.nom, nom);
	strcpy (e2.prenom,prenom);
        strcpy (e2.numtel, numtel);
	sscanf (dt,"%d/%d/%d",&e2.date.jour,&e2.date.mois,&e2.date.annee);
	supprimeremploye(cin);
}

}


void
on_listeemployess_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowemp;
windowemp=lookup_widget(button,"window_employes");
GtkWidget *treeview1;
employe e;

treeview1=lookup_widget(windowemp,"treeview1cy");
afficherlisteemployes(treeview1,e);

}


void
on_recherchecy_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *windowemp;
   	GtkWidget *treeview2cy;
	GtkWidget *input1;
        char matricule[30];
	GtkWidget *output;
        employe e;

        windowemp=lookup_widget(button,"window_employes");
	treeview2cy=lookup_widget(windowemp,"treeview2cy");
        output=lookup_widget(button,"labelmat"); 
	input1=lookup_widget(button,"entrycinrechcy");
        strcpy(matricule,gtk_entry_get_text(GTK_ENTRY(input1)));
 if( (!strcmp(matricule,"")))
{gtk_label_set_text(GTK_LABEL(output),"champs vide !!");
}
else {
  	
        afficherrecherchecin(treeview2cy,e);
	rechercheemploye(e,matricule);
}
}


void
on_buttonajoutcy_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowemp;
GtkWidget *windowajout;
windowajout=lookup_widget(button,"window_ajout_cy");
windowemp=lookup_widget(button,"window_employes");
windowajout=create_window_ajout_cy();
gtk_widget_show(windowajout);
}

/////////////////////////////////////////////////////////////////////////////////////

void
on_closebuttonerreurempl_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog7=lookup_widget(GTK_WIDGET(button),("dialog7"));

gtk_widget_destroy(dialog7);
}


//////////////////////////////////////////////////////////////////////////////////////
void
on_buttonmodifcy_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodif;
windowmodif=create_window_modif_cy();
gtk_widget_show(windowmodif);

GtkWidget *cin;
GtkWidget *matricule;
GtkWidget *password;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *numtel;


GtkSpinButton *jour;
GtkSpinButton *mois;
GtkSpinButton *annee;

cin=lookup_widget(windowmodif,"entrycinmod");
gtk_entry_set_text(GTK_ENTRY(cin),e2.cin);

matricule=lookup_widget(windowmodif,"entrymatriculemod");
gtk_entry_set_text(GTK_ENTRY(matricule),e2.matricule);

password=lookup_widget(windowmodif,"entrypassmod");
gtk_entry_set_text(GTK_ENTRY(password),e2.password);

nom=lookup_widget(windowmodif,"entrynommod");
gtk_entry_set_text(GTK_ENTRY(nom),e2.nom);

prenom=lookup_widget(windowmodif,"entryprenommod");
gtk_entry_set_text(GTK_ENTRY(prenom),e2.prenom);

numtel=lookup_widget(windowmodif,"entrynumtelmod");
gtk_entry_set_text(GTK_ENTRY(numtel),e2.numtel);




jour=lookup_widget(windowmodif,"spinbuttoncy1mod");
gtk_spin_button_set_value(jour,e2.date.jour);

mois=lookup_widget(windowmodif,"spinbuttoncy2mod");
gtk_spin_button_set_value(mois,e2.date.mois);

annee=lookup_widget(windowmodif,"spinbuttoncy3mod");
gtk_spin_button_set_value(annee,e2.date.annee);

}

/////////////////////////////////////////////////////////////////////////////

void
on_buttonsuppcy_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
employe e;
GtkWidget *windowemp;
windowemp=lookup_widget(GTK_WIDGET(button),"window_employes");
supprimeremploye(e.cin);

GtkWidget *dialog2;
dialog2=create_dialog2cy();
gtk_widget_show(dialog2);
}


/////////////////////////////////////////////////////////////////////////////

void
on_gestion_employes_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowemp;
GtkWidget *windowacc;
windowacc=lookup_widget(button,"window_admin");
gtk_widget_destroy(windowacc);
windowemp=create_window_employes();
gtk_widget_show(windowemp);
}

///////////////////////////////////////////////////////////////////////////
void
on_retourcymod_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowemp;
GtkWidget *windowmodif;
windowmodif=lookup_widget(button,"window_modif_cy");
windowemp=lookup_widget(button,"window_employes");
gtk_widget_destroy(windowmodif);
//windowemp=create_window_employes();

}

///////////////////////////////////////////////////////////////////////////////////////
void
on_validecymod_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry1, *entry2,*entry3, *entry4, *entry5,*entry6, *jour, *mois,*annee,*output;
GtkWidget *windowajout;
employe e2;
int fail=0;
const char *format;
char msg[50], *markup;
GtkWidget *dialog7=lookup_widget(GTK_WIDGET(button),("dialog7"));
output=lookup_widget(button,"labeltel");
entry1=lookup_widget(button,"entrycinmod");
entry6=lookup_widget(button,"entrymatriculemod");
entry2=lookup_widget(button,"entrypassmod");
entry3=lookup_widget(button,"entrynommod");
entry4=lookup_widget(button,"entryprenommod");
entry5=lookup_widget(button,"entrynumtelmod");

jour=lookup_widget(button,"spinbuttoncy1mod");
mois=lookup_widget(button,"spinbuttoncy2mod");
annee=lookup_widget(button,"spinbuttoncy3mod");

e2.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e2.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e2.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

strcpy(e2.cin,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(e2.matricule,gtk_entry_get_text(GTK_ENTRY(entry6)));
strcpy(e2.password,gtk_entry_get_text(GTK_ENTRY(entry2)));
strcpy(e2.nom,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(e2.prenom,gtk_entry_get_text(GTK_ENTRY(entry4)));
strcpy(e2.numtel,gtk_entry_get_text(GTK_ENTRY(entry5)));


e2.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e2.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e2.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

 if( (!strcmp(e2.cin,"")) || (!strcmp(e2.matricule,"")) || (!strcmp(e2.password,"")) || (!strcmp(e2.numtel,"")) || (!strcmp(e2.nom,"")) ||(!strcmp(e2.prenom,"")) )
       { 

 	
	  dialog7=create_dialog7() ;
	  gtk_widget_show(dialog7) ;
	 fail=1;

 
       }
if (strlen(e2.numtel)!=8)
{
gtk_label_set_text(GTK_LABEL(output), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(output), markup);
fail =1;
}

if (fail==0)
{



ajouteremploye(e2);

GtkWidget *dialog3=lookup_widget(GTK_WIDGET(button),("dialog3"));

dialog3=create_dialog3() ;
gtk_widget_show(dialog3); 
}

}

//////////////////////////////////////////////////////////////

void
on_okbuttonajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1=lookup_widget(GTK_WIDGET(button),("dialog1cy"));

gtk_widget_destroy(dialog1);
}


///////////////////////////////////////////////////////////////////////
void
on_oksupp_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog2=lookup_widget(GTK_WIDGET(button),("dialog2cy"));

gtk_widget_destroy(dialog2);
}



/////////////////////////////////////////////////////////////////////////////////////

void
on_retourajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowemp;
GtkWidget *windowajout;
windowajout=lookup_widget(button,"window_ajout_cy");
windowemp=lookup_widget(button,"window_employes");
gtk_widget_destroy(windowajout);
//windowemp=create_window_employes();
//gtk_widget_show(windowemp);
}
/////////////////////////////////////////////////////////////////////////////////////

void
on_validerajout_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry1, *entry2,*entry3,*entry4,*entry5,*entry6, *jour, *mois,*annee;
GtkWidget *window_employes;
GtkWidget *dialogerreurmat;
GtkWidget *output1,*output2, *output3, *output4,*output5,*output6,*output7;
GtkWidget *dialog7=lookup_widget(GTK_WIDGET(button),("dialog7"));
employe e;
int fail=0;
FILE *f;
f=fopen("employes.txt","r");

char ch1[30];
char ch2[30];
char ch3[30];
char ch4[30];
char ch5[30];

char msg[50], msg2[50], *markup,msg3[30],msg4[30],msg5[50],msg6[50],msg7[50];
const char *format;

output1=lookup_widget(button,"labelcin");
output2=lookup_widget(button,"labeltel");
output3=lookup_widget(button,"labelmatri");
output4=lookup_widget(button,"labelchampemp");
output5=lookup_widget(button,"labelcinexiste");
output6=lookup_widget(button,"labelespacenomemp");
output7=lookup_widget(button,"labelespaceprenom");


window_employes=lookup_widget(button,"window_ajout_cy");
entry1=lookup_widget(button,"entrycincy");
entry6=lookup_widget(button,"entrymatricule");
entry2=lookup_widget(button,"entrypasswordcy");
entry3=lookup_widget(button,"entrynomcy");
entry4=lookup_widget(button,"entryprenomcy");
jour=lookup_widget(button,"spinbuttonjourcy");
mois=lookup_widget(button,"spinbuttonmoiscy");
annee=lookup_widget(button,"spinbuttonanneecy");
entry5=lookup_widget(button,"entrynumtelcy");

   
e.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

strcpy(e.numtel,gtk_entry_get_text(GTK_ENTRY(entry5)));
strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(e.matricule,gtk_entry_get_text(GTK_ENTRY(entry6)));
strcpy(e.password,gtk_entry_get_text(GTK_ENTRY(entry2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(entry4)));

   
if( (!strcmp(e.cin,""))|| (!strcmp(e.matricule,"")) || (!strcmp(e.password,"")) || (!strcmp(e.numtel,"")) || (!strcmp(e.nom,"")) ||(!strcmp(e.prenom,"")) )
       { 

 	gtk_label_set_text(GTK_LABEL(output4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg4, "Les chapms sont vide");
    markup= g_markup_printf_escaped(format, msg4);
    gtk_label_set_markup(GTK_LABEL(output4), markup);
	  fail=1;
       }

if (strlen(e.cin)!=8 ) 
{
	
gtk_label_set_text(GTK_LABEL(output1), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(output1), markup);
fail=1;
}

if (strlen(e.numtel)!=8)
{
    gtk_label_set_text(GTK_LABEL(output2), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg2, "inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg2);
    gtk_label_set_markup(GTK_LABEL(output2), markup);
fail =1;
}
for(int i=0;e.nom[i]!='\0';i++)
{
if(e.nom[i]==' ')
{ gtk_label_set_text(GTK_LABEL(output6), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg6, "Evitez l'espace !");
    markup= g_markup_printf_escaped(format, msg6);
    gtk_label_set_markup(GTK_LABEL(output6), markup);
fail =1;
}
}
for(int i=0;e.prenom[i]!='\0';i++)
{
if(e.prenom[i]==' ')
{ gtk_label_set_text(GTK_LABEL(output7), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg7, "Evitez l'espace !");
    markup= g_markup_printf_escaped(format, msg7);
    gtk_label_set_markup(GTK_LABEL(output7), markup);
fail =1;
}
}


             


f=fopen("employes.txt","r");
 if (f==NULL)
{return;}
else 
                  {while(fscanf(f,"%s %s %s %s %s %d %d %d %s \n",e2.cin,e2.matricule,e2.password,e2.nom,e2.prenom,&e2.date.jour,&e2.date.mois,&e2.date.annee,e2.numtel)!=EOF)
{ 
                                 if (strcmp(e.matricule,e2.matricule)==0)
                                       { 
          	                            gtk_label_set_text(GTK_LABEL(output3), "");
   					 format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
                                         sprintf(msg3, "Matricule exsite déjà !");
                                         markup= g_markup_printf_escaped(format, msg3);
                                          gtk_label_set_markup(GTK_LABEL(output3), markup);
					   fail=1;
	                                   break;
          
                                       }
                         }
fclose(f);

                 }

             

          
               
if(fail==0)

{
	GtkWidget *dialog1;
	dialog1=create_dialog1cy();
	gtk_widget_show(dialog1);
	ajouteremploye(e);
}


}
////////////////////////////////////////////////////////
void
on_closebuttonerreurmatricule_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogerreurmat=lookup_widget(GTK_WIDGET(button),("dialogerreurmat"));

gtk_widget_destroy(dialogerreurmat);
}

//////////////////////////////////////////////////////////////////////////////
void
on_okbuttonmodif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog3=lookup_widget(GTK_WIDGET(button),("dialog3"));

gtk_widget_destroy(dialog3);

}
//////////////////////////////////////////////////////////////////////////////

void
on_buttonretouradmin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowemp;
GtkWidget *windowacc;
windowemp=lookup_widget(button,"window_employes");
gtk_widget_destroy(windowemp);
windowacc=create_window_admin();
gtk_widget_show(windowacc);
}

//////////////////////////////////////////////////////////////////////////////
void
on_buttondeconnexion_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkWidget *window_gestions;
   GtkWidget *window_auth;
   //window_gestions=create_window_gestions();
   window_gestions=lookup_widget(button,"window_gestions");
   gtk_window_set_position(GTK_WINDOW(window_gestions),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_hide(window_gestions);
   window_auth = create_window_auth();
   gtk_window_set_position(GTK_WINDOW(window_auth),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_show (window_auth);
}
//////////////////////////////////////////////////////////////////////////////

void
on_buttonfermermodif_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog6=lookup_widget(GTK_WIDGET(button),("dialog6"));

gtk_widget_destroy(dialog6);
}


//////////////////gestion equipements/////////////////


void
on_ajoutereq_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_equipements;
	GtkWidget *window_ajout_eq;
	
	window_equipements=lookup_widget(button,"window_equipements");
	window_ajout_eq=lookup_widget(button,"window_ajout_eq");
	window_ajout_eq=create_window_ajout_eq();
	
	gtk_widget_show(window_ajout_eq);
}
//////////////////////////////////////////////////////////////////////////////

void
on_buttonmodifiereq_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
     
	GtkWidget *window_modif_eq;
	GtkWidget *entry1;
        GtkWidget *entry2,*jour, *mois,*annee,*combobox1,*combobox2;
	equipement eq2;
	GtkWidget *dialogchampsvide;
        GtkWidget *dialogcomboboxeqvide;	
	int fail=0;

	
window_modif_eq=lookup_widget(button,"window_modif_eq");

entry1=lookup_widget(button,"entryrefmod");
jour=lookup_widget(button,"spinbuttonjourmod");
mois=lookup_widget(button,"spinbuttonmoismod");
annee=lookup_widget(button,"spinbuttonanneemod");
entry2=lookup_widget(button,"entryprixmod");
combobox1=lookup_widget(button,"comboboxtypemod");
combobox2=lookup_widget(button,"comboboxetatmod");

eq2.dt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
eq2.dt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
eq2.dt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

strcpy(eq2.reference,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(eq2.prix,gtk_entry_get_text(GTK_ENTRY(entry2)));

if (( gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))==NULL))
{
          dialogcomboboxeqvide=create_dialogcomboboxeqvide() ;//combobox vide
	  gtk_widget_show(dialogcomboboxeqvide) ; 
	  fail=1;
	
}

if( (!strcmp(eq2.reference,"")) || (!strcmp(eq2.prix,""))   )
       { 
	  dialogchampsvide=create_dialogchampsvide() ;//champs vides
	  gtk_widget_show( dialogchampsvide) ;
	  fail=1;
       }


if (fail==0)
{
strcpy(eq2.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(eq2.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));

ajouterequipement(eq2);
GtkWidget *dialog3equi;
dialog3equi=create_dialog3equi();
gtk_widget_show(dialog3equi);
}
}

//////////////////////////////////////////////////////////////////////////////
void
on_supp_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_equipements;
window_equipements=lookup_widget(GTK_WIDGET(button),"window_equipements");
supprimerequipement(eq2.reference);
GtkWidget *treevieweq;

treevieweq=lookup_widget(window_equipements,"treevieweq");
GtkWidget *dialog2equi;
dialog2equi=create_dialog2equi();
gtk_widget_show(dialog2equi);
}

//////////////////////////////////////////////////////////////////////////////
void
on_treevieweq_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *ref;
gchar *t;
gchar *e;
gchar *date;
gchar *p;

GtkTreeModel *list_store;
list_store=gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(list_store,&iter,path))

{
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,0,&ref,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,1,&t,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,2,&e,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,3,&date,-1);
gtk_tree_model_get(GTK_LIST_STORE(list_store),&iter,5,&p,-1);

	strcpy(eq2.reference,ref);
        strcpy (eq2.type,t);
        strcpy (eq2.etat,e);
	sscanf (date,"%d/%d/%d",&eq2.dt.jour,&eq2.dt.mois,&eq2.dt.annee);
	strcpy (eq2.etat,e);
	
supprimerequipement(ref);
}
}

//////////////////////////////////////////////////////////////////////////////
void
on_buttonafficheeq_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_equipements;
   	GtkWidget *treevieweq;
	equipement eq;

	window_equipements=lookup_widget(button,"window_equipements");
	treevieweq=lookup_widget(window_equipements,"treevieweq");
        afficherlisteequipements(treevieweq,eq);
}

//////////////////////////////////////////////////////////////////////////////
void
on_buttonvalide_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry1, *entry2,*combobox1, *combobox2, *jour, *mois,*annee;
GtkWidget *window_ajout_eq;
GtkWidget *dialogcomboboxeqvide;
GtkWidget *dialogchampsvide;
GtkWidget *dialogexiste;
int fail=0;
FILE *f;
equipement eq;

window_ajout_eq=lookup_widget(button,"window_ajout_eq");
entry1=lookup_widget(button,"entry2");
combobox1=lookup_widget(button,"combobox2");
combobox2=lookup_widget(button,"combobox3");
jour=lookup_widget(button,"spinbuttonjour");
mois=lookup_widget(button,"spinbuttonmois");
annee=lookup_widget(button,"spinbuttonannee");
entry2=lookup_widget(button,"entry6");

strcpy(eq.reference,gtk_entry_get_text(GTK_ENTRY(entry1)));


eq.dt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
eq.dt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
eq.dt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(eq.prix,gtk_entry_get_text(GTK_ENTRY(entry2)));
if (( gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))==NULL))
{
          dialogcomboboxeqvide=create_dialogcomboboxeqvide() ;//combobox vide
	  gtk_widget_show(dialogcomboboxeqvide) ; 
	  fail=1;
	
}

if( (!strcmp(eq.reference,"")) || (!strcmp(eq.prix,""))   )
       { 
	  dialogchampsvide=create_dialogchampsvide() ;//champs vides
	  gtk_widget_show( dialogchampsvide) ;
	  fail=1;
       }
f=fopen("equipements.txt","r");
 if (f==NULL)
{return;
}
else 
   {

while (fscanf(f,"%s %s %s %d %d %d %s \n",eq2.reference,eq2.type,eq2.etat,&eq2.dt.jour,&eq2.dt.mois,&eq2.dt.annee,eq2.prix)!=EOF)
	{
             if( (strcmp(eq.reference,eq2.reference)==0) )
                {
                     dialogexiste=create_dialogexiste() ;//ref existe déjà
	             gtk_widget_show( dialogexiste) ;
	             fail=1;
		     break;
         
          
                }
        }
fclose(f);

  }

               
if (fail==0)
{
strcpy(eq.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(eq.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));

GtkWidget *dialog1equi;
dialog1equi=create_dialog1equi();
gtk_widget_show(dialog1equi);
ajouterequipement(eq);
}
}

//////////////////////////////////////////////////////////////////////////////
void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_equipements;
GtkWidget *window_ajout_eq;
window_ajout_eq=lookup_widget(button,"window_ajout_eq");
gtk_widget_destroy(window_ajout_eq);
window_equipements=create_window_equipements();
}

//////////////////////////////////////////////////////////////////////////////
void
on_okbuttonsupp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog2equi=lookup_widget(GTK_WIDGET(button),("dialog2equi"));

gtk_widget_destroy(dialog2equi);
}

//////////////////////////////////////////////////////////////////////////////
void
on_okbuttonajouteq_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1equi=lookup_widget(GTK_WIDGET(button),("dialog1equi"));

gtk_widget_destroy(dialog1equi);
}
//////////////////////////////////////////////////////////////////////////////

void
on_okbuttonmodifeq_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
 

GtkWidget *dialog3equi=lookup_widget(GTK_WIDGET(button),("dialog3equi"));

gtk_widget_destroy(dialog3equi);

}

//////////////////////////////////////////////////////////////////////////////
void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_equipements;
   	GtkWidget *treeview4rech;
	GtkWidget *input1;
        char type[30];
        equipement eq;
	GtkWidget *output;
	const char *format;
	char *markup, msg [30];

        window_equipements=lookup_widget(button,"window_equipements");
	treeview4rech=lookup_widget(window_equipements,"treeview4rech");
	input1=lookup_widget(button,"entryrech");
	 output=lookup_widget(button,"labeltyperech"); 
  	strcpy(type,gtk_entry_get_text(GTK_ENTRY(input1)));
if( (!strcmp(type,"")))
{
gtk_label_set_text(GTK_LABEL(output), "");
    format = "<span foreground=\"black\"><b>\%s</b></span>";
    sprintf(msg, "Champs vide!");
    markup= g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(output), markup);

}
else 
{
        afficherrecherche(treeview4rech);
	Recherche(eq,type);
}
}


//////////////////////////////////////////////////////////////////////////////

void
on_retourmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_equipements;
GtkWidget *window_modif_eq;
window_modif_eq=lookup_widget(button,"window_modif_eq");
gtk_widget_destroy(window_modif_eq);
//window_equipements=create_window_equipements();
}

//////////////////////////////////////////////////////////////////////////////
void
on_gestion_equipements_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_equipements;
	GtkWidget *window_gestions;
	window_gestions=create_window_gestions();
	window_gestions=lookup_widget(button,"window_gestions");
	gtk_widget_hide(window_gestions);
	window_equipements = create_window_equipements();
	gtk_widget_show(window_equipements);
}




void
on_buttonmodifeq_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *window_equipements;
	GtkWidget *window1;

window_equipements=lookup_widget(button,"window_equipements");
	window1=lookup_widget(button,"window_modif_eq");
	window1=create_window_modif_eq();
	gtk_widget_show(window1);
GtkWidget *reference,*jour,*mois,*annee,*prix;


reference=lookup_widget(window1,"entryrefmod");
gtk_entry_set_text(GTK_ENTRY(reference),eq2.reference);

jour=lookup_widget(window1,"spinbuttonjourmod");
gtk_spin_button_set_value(jour,eq2.dt.jour);

mois=lookup_widget(window1,"spinbuttonmoismod");
gtk_spin_button_set_value(mois,eq2.dt.mois);

annee=lookup_widget(window1,"spinbuttonanneemod");
gtk_spin_button_set_value(annee,eq2.dt.annee);

prix=lookup_widget(window1,"entryprixmod");
gtk_entry_set_text(GTK_ENTRY(prix),eq2.prix);
}




///////////////////////////////////////////////////////////////////////

void
on_buttonaccueiladmin_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_admin;
	GtkWidget *window_tableau_de_bord;

	window_tableau_de_bord=lookup_widget(button,"window_tableau_de_bord");
	gtk_widget_destroy(window_tableau_de_bord);
	window_admin=create_window_admin();
	gtk_widget_show(window_admin);
}






void
on_afficherstatistiquescy_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
int compteur_defectueux;
char msg[120]="";

equipement e;
GtkWidget *output;
GtkWidget *window3;
GtkWidget *treeview5;
window3=lookup_widget(button,"window_tableau_de_bord");
treeview5=lookup_widget(window3,"treeviewstatcy");
output=lookup_widget(button,"labelstatcy");

        
        compteur_defectueux=statistiques();

        sprintf (msg,"%d", compteur_defectueux) ;
        gtk_label_set_text(output,msg);
listedefect(e);
afficherdefect(treeview5);

}

////////////////////////////////////////////////////////////////////////////
void
on_buttonquitterequipement_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestions;
	GtkWidget *window_equipements;

	window_equipements=lookup_widget(button,"window_equipements");
	gtk_widget_destroy(window_equipements);
	window_gestions=create_window_gestions();
	gtk_widget_show(window_gestions);  
}

/////////////////////////////////////////////////////////////////////////


void
on_closebuttoncomboeq_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *dialogcomboboxeqvide=lookup_widget(GTK_WIDGET(button),("dialogcomboboxeqvide"));

gtk_widget_destroy(dialogcomboboxeqvide);

}

//////////////////////////////////////////////////////////////////////////
void
on_closebuttonchampseqvide_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogchampsvide=lookup_widget(GTK_WIDGET(button),("dialogchampsvide"));

gtk_widget_destroy(dialogchampsvide);
}

////////////////////////////////////////////////////////////////////////////////
void
on_closebuttonexiste_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogexiste=lookup_widget(GTK_WIDGET(button),("dialogexiste"));

gtk_widget_destroy(dialogexiste);
 
}

////////////////////////gestion ouvriers/////////////////////
void
on_button_Gouvriers_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *Gouvrier, *treeview;
GtkWidget *window_gestions;

  
   window_gestions=lookup_widget(button,"window_gestions");
   window_gestions=create_window_gestions();
   gtk_widget_hide(window_gestions);
   Gouvrier=create_Gestiondesouvriers();
   gtk_widget_show(Gouvrier);

treeview=lookup_widget(Gouvrier,"treeviewouv");
afficher_ouv(treeview) ;
}


void
on_b_Pointage_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Point ; 
GtkWidget *button1; 

button1=lookup_widget(button,"save");

Gouvrier=lookup_widget(button,"Gestiondesouvriers");
Point=create_Presence();
gtk_widget_show(Point);
gtk_widget_hide(Gouvrier);
gtk_widget_hide(button1);
}


void
on_treeviewouv_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;

Ouvrier ouv ; 


gchar *ident; 
gchar *nom; 
gchar *prenom;
gchar *sexe;
gchar *cin;
gchar *date;
gchar *tel;
gchar *tache;

 if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
 	    {
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &ident, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,1, &nom, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,2, &prenom, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &sexe, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,4, &cin, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,5, &date, -1);
		gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,6, &tel, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,7, &tache, -1);


strcpy(ouv.id, ident); 
strcpy(ouv.nom, nom);
strcpy(ouv.prenom, prenom);
strcpy(ouv.sexe, sexe);
strcpy(ouv.cin, cin);
sscanf(date, "%d/%d/%d", &ouv.jour,&ouv.mois,&ouv.anne);
strcpy(ouv.tel, tel);
strcpy(ouv.tache, tache);

supprimer_ouv(ident) ; 

//afficher_ouv(treeview) ; 
}
}

void
on_b1_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Ajout ; 
Gouvrier=lookup_widget(button,"Gestiondesouvriers");
Ajout=create_Ajouterouvrier();
gtk_widget_show(Ajout);
gtk_widget_hide(Gouvrier);
}


void
on_searchouv_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *search , *Gouvrier , *trait, *Gouvrier1 , *trait1 , *treeview  ;

char id2[50]; 
int x=0 ; 

search=lookup_widget(button,"rechercheouvrier");
strcpy(id2,gtk_entry_get_text(GTK_ENTRY(search)));

Gouvrier=lookup_widget(button,"Gestiondesouvriers");
gtk_widget_hide(Gouvrier);

x++ ; 

if (x==1) 
{
Gouvrier1=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier1);
treeview=lookup_widget(Gouvrier1,"treeviewouv");
rechercher_ouv(treeview,id2) ;
x=0 ; 
}
else 
treeview=lookup_widget(Gouvrier,"treeviewouv");
afficher_ouv(treeview) ;
}


void
on_buttonquitterouvrier_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestions;
	GtkWidget *Gestiondesouvriers;

	Gestiondesouvriers=lookup_widget(button,"Gestiondesouvriers");
	gtk_widget_destroy(Gestiondesouvriers);
	window_gestions=create_window_gestions();
	//gtk_widget_show(window_gestions);  
}


void
on_b1_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

char id1[50];
GtkWidget *Gouvrier ,*Mod ; 
GtkWidget *recherche ,*insertcin ;
const char *format;
char msg[30], *markup;

recherche=lookup_widget(button,"rechercheouvrier");
insertcin=lookup_widget(button,"insertcin");

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(recherche)));

if (strcmp(id1,"")==0) 
{
gtk_label_set_text(GTK_LABEL(insertcin)," Enter ID ! ");
}
else 
{
Gouvrier=lookup_widget(button,"Gestiondesouvriers");
Mod=create_Modifierouvrier();
gtk_widget_show(Mod);
gtk_widget_hide(Gouvrier);
}
}


void
on_b1_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char id[200];
GtkWidget *recherche ,*Gouvrier ,*dialogsuppouv ,*insertcin;

insertcin=lookup_widget(button,"insertcin");
recherche=lookup_widget(button,"rechercheouvrier");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(recherche)));

if (strcmp(id,"")==0) 
{
gtk_label_set_text(GTK_LABEL(insertcin)," Enter ID ! ");
}

else {
supprimer_ouv(id);

Gouvrier=lookup_widget(button,"Gestiondesouvriers");
dialogsuppouv=create_dialogsuppouv();
gtk_widget_show(dialogsuppouv);
gtk_widget_hide(Gouvrier);}
}
///////////////////////////////////////////////////////////
void
on_closebuttonsuppouv_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*dialogsuppouv ,*treeview  ; 

dialogsuppouv =lookup_widget(button,"dialogsuppouv");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(dialogsuppouv);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}
///////////////////////////////////////////////////////////////

void
on_b2_retour_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Ajout ,*treeview  ; 

Ajout=lookup_widget(button,"Ajouterouvrier");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_destroy(Ajout);


treeview=lookup_widget(Gouvrier,"treeviewouv");
afficher_ouv(treeview) ;
}


void
on_b2_sauvegarde_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Nom , *Pre , *Gen , *CIN , *jj , *mm , *an , *tele , *tach ; 

Ouvrier ouv ;

GtkWidget *dialog8,*Ajout ;
GtkWidget *output1,*output2,*output3,*output4;

int fail=0;
const char *format;
char msg[50],msg2[50],msg3[50],msg4[50], *markup;

gboolean togm ,togf ;  

int jour , mois , anne ; 
Ajout=lookup_widget(objet_graphique,"Ajouterouvrier");
Nom=lookup_widget(objet_graphique,"entry_nomouv"); 
Pre=lookup_widget(objet_graphique,"entry6"); 
CIN=lookup_widget(objet_graphique,"entry7");
jj=lookup_widget(objet_graphique,"sb_journ");
mm=lookup_widget(objet_graphique,"sb_moisn");
an= lookup_widget(objet_graphique,"sb_annee");
tele=lookup_widget(objet_graphique,"entry10");
tach= lookup_widget(objet_graphique,"comboboxtache");

output1=lookup_widget(objet_graphique,"labelcinouv");
output2=lookup_widget(objet_graphique,"labelnumouv");
output3=lookup_widget(objet_graphique,"labelchampsvide");
output4=lookup_widget(objet_graphique,"labelcombovide");

strcpy(ouv.nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(ouv.prenom,gtk_entry_get_text(GTK_ENTRY(Pre)));
strcpy(ouv.cin,gtk_entry_get_text(GTK_ENTRY(CIN)));
strcpy(ouv.tel,gtk_entry_get_text(GTK_ENTRY(tele)));




ouv.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
ouv.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
ouv.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

 



togm=on_rb_homme_toggled(objet_graphique,user_data);
togf=on_rb_femme_toggled(objet_graphique,user_data);


if (togm) 
  {
   strcpy(ouv.sexe,"male") ; 
  }

if (togf) 
  {
   strcpy(ouv.sexe,"female") ; 
  }

if (strlen(ouv.cin)!=8)  
{

    gtk_label_set_text(GTK_LABEL(output1), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(output1), markup);
	
	fail=1;
	
}
if (strlen(ouv.tel)!=8)
{
gtk_label_set_text(GTK_LABEL(output2), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg2, "inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg2);
    gtk_label_set_markup(GTK_LABEL(output2), markup);

fail=1;
}
  if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(tach))==NULL)
{
      
    gtk_label_set_text(GTK_LABEL(output4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg4, "Combobox est vide");
    markup= g_markup_printf_escaped(format, msg4);
    gtk_label_set_markup(GTK_LABEL(output4), markup);

	fail=1;
}
 if( (!strcmp(ouv.nom,""))|| (!strcmp(ouv.prenom,"")) || (!strcmp(ouv.cin,"")) || (!strcmp(ouv.tel,""))  )
{     
     gtk_label_set_text(GTK_LABEL(output3), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg3, "Vous devez remplir tous les champs");
    markup= g_markup_printf_escaped(format, msg3);
    gtk_label_set_markup(GTK_LABEL(output3), markup);
	fail=1;
}

if (fail==0)

{
strcpy(ouv.tache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tach)));
ajouter_ouv(ouv); 


dialog8=create_dialog8();
gtk_widget_show(dialog8);
//gtk_widget_hide(Ajout);
}

}
void
on_closebuttonajoutouv_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog8=lookup_widget(GTK_WIDGET(button),("dialog8"));

gtk_widget_destroy(dialog8);
}





gboolean
on_rb_femme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"rb_femme");
	togglebutton2=lookup_widget(objet_graphique,"rb_homme");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton1));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton2),FALSE);
	}
	return etat;
}


gboolean
on_rb_homme_toggled                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"rb_femme");
	togglebutton2=lookup_widget(objet_graphique,"rb_homme");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton2));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton1),FALSE);
	}
	return etat;
}






void
on_b3_sauvegarder_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *CIN , *jj , *mm , *an ; 
GtkWidget *button; 

button=lookup_widget(objet_graphique,"save");

Point p ; 
char id[20]; 

GtkWidget *ok ,*Ajout  ;



gboolean togA ,togP ;  

int jour , mois , anne ; 


CIN=lookup_widget(objet_graphique,"entry12");
jj=lookup_widget(objet_graphique,"spinday");
mm=lookup_widget(objet_graphique,"spinmonth");
an= lookup_widget(objet_graphique,"spinyear");



strcpy(id,gtk_entry_get_text(GTK_ENTRY(CIN)));


p.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
p.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
p.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

 



togP=on_checkbuttonA_toggled(objet_graphique,user_data);
togA=on_checkbuttonP_toggled(objet_graphique,user_data);


if (togA) 
  {
   strcpy(p.etat,"Absent") ; 
  }

if (togP) 
  {
   strcpy(p.etat,"Present") ; 
  }

pointage(p,id) ; 
gtk_widget_show(button);



}


void
on_b2_retour_2_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Point ,*treeview  ; 

Point=lookup_widget(button,"Presence");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Point);

treeview=lookup_widget(Gouvrier,"treeviewouv");
afficher_ouv(treeview) ;
}

gboolean
on_checkbuttonA_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"checkbuttonA");
	togglebutton2=lookup_widget(objet_graphique,"checkbuttonP");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton2));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton1),FALSE);
	}
	return etat;
}


gboolean
on_checkbuttonP_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget	*togglebutton1,*togglebutton2;
	gboolean etat;
	togglebutton1=lookup_widget(objet_graphique,"checkbuttonA");
	togglebutton2=lookup_widget(objet_graphique,"checkbuttonP");
	etat=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton1));
	if(etat){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton2),FALSE);
	}
	return etat;
}

char id1[30];
void
on_savechange_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
char ntel[20] ; 
char ntache[50]; 

const char *format;
char msg[50],msg2[50], *markup;
Ouvrier ouv ;


GtkWidget *tele ,*tach  ; 


GtkWidget *dialog9 ,*Mod ;
GtkWidget *output1,*output2;

Mod=lookup_widget(button,"Modifierouvrier");

int fail=0;

tele=lookup_widget(button,"entry16");
tach= lookup_widget(button,"combobox2");


output1=lookup_widget(button,"labelcombomodvide");
output2=lookup_widget(button,"labelnummodvide");


strcpy(ntel,gtk_entry_get_text(GTK_ENTRY(tele)));


 
 if( (!strcmp(ouv.tel,""))||(strlen(ouv.tel))!=8 ) 
{      

    gtk_label_set_text(GTK_LABEL(output2), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Vous devez remplir ce champs \n ou bien inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(output2), markup);
	fail=1;
}
 
 if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(tach))==NULL)
{
        
gtk_label_set_text(GTK_LABEL(output1), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg2, "Combobox est vide");
    markup= g_markup_printf_escaped(format, msg2);
    gtk_label_set_markup(GTK_LABEL(output1), markup);
	fail=1;
}

if (fail==0)
{
strcpy(ntache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tach)));
modifier_ouv(id1,ntel,ntache); 

dialog9=create_dialog9();
gtk_widget_show(dialog9);
gtk_widget_hide(Mod);
}
}


void
on_b_retour_change_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*Mod , *treeview ; 

Mod=lookup_widget(button,"Modifierouvrier");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Mod);

treeview=lookup_widget(Gouvrier,"treeviewouv");
afficher_ouv(treeview) ;
}


void
on_buttontaux_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
float s;
int somme ; 
char somme1[200];
float total ; 

GtkWidget *sum ; 

sum=lookup_widget(objet_graphique,"tsum");

somme = TauxTotal();
s=((somme*100)/30);
sprintf(somme1,"%.2f",s);
gtk_label_set_text(GTK_LABEL(sum),(somme1));
}

void
on_meilleur_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *taux ,*taux1 ,*trait ,*treeview  ;
int x=0 ;  

taux=lookup_widget(objet_graphique,"window_tableau_de_bord");


gtk_widget_hide(taux);



x++ ; 

if (x==1) 
{
taux1=create_window_tableau_de_bord();
gtk_widget_show(taux1);
treeview=lookup_widget(taux1,"treeviewtaux");
affichertop(treeview) ;
x=0 ; 
}

}

void
on_buttonliste_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
int x=0 ; 

GtkWidget *acc ,*taux,*treeview, *taux1; 

taux=lookup_widget(button,"window_tableau_de_bord");
gtk_widget_hide(taux);
x++ ; 

if (x==1) 
{
taux1=create_window_tableau_de_bord();
gtk_widget_show(taux1);
treeview=lookup_widget(taux1,"treeviewtaux");
afficherbest(treeview) ;
x=0 ; 
}
}


void
on_closebuttonmodifouv_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gouvrier ,*dialog9 ,*treeview  ; 

dialog9 =lookup_widget(button,"dialog9");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(dialog9);

treeview=lookup_widget(Gouvrier,"treeview1");
afficher_ouv(treeview) ;
}


void
on_save_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *CIN  ; 


Point p ; 
char id[20]; 

GtkWidget *ok ,*Ajout ;


gboolean togA ,togP ;  

int jour , mois , anne ; 


CIN=lookup_widget(button,"entry12");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(CIN)));


togP=on_checkbuttonA_toggled(button,user_data);
togA=on_checkbuttonP_toggled(button,user_data);


if (togA) 
  {
   strcpy(p.etat,"Absent") ; 
  }

if (togP) 
  {
   strcpy(p.etat,"Present") ; 
  }

 
absence(p,id);

GtkWidget *Gouvrier ,*Point ,*treeview  ; 

Point=lookup_widget(button,"Presence");
Gouvrier=create_Gestiondesouvriers();
gtk_widget_show(Gouvrier);
gtk_widget_hide(Point);

treeview=lookup_widget(Gouvrier,"treeviewouv");
afficher_ouv(treeview) ;
}

////////////////////gestion des clients////////////////////////////////
char id[30];char a[70];char b[70];char y[70];char d[70];char e[70];char f[70];char g[70];char h[70];char m[70];char n[70];
void on_KLtreeview_row_activated(GtkTreeView *KLtreeview,
                                 GtkTreePath *path,
                                 GtkTreeViewColumn *column,
                                 gpointer user_data)

{
  CLIENT c;
  GtkTreeIter iter;
  gchar *nom;
  gchar *prenom;
  gchar *cin;
  gint *adresse;
  gint *email;
  gint *numero;
  gchar *identifiant;
  gchar *dt;
  gchar *sexe;
  gchar *achat;
  
GtkWidget * window_liste_clients;

  window_liste_clients = lookup_widget(KLtreeview, "window_liste_clients");
  GtkTreeModel *model = gtk_tree_view_get_model(KLtreeview);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &nom, 1, &prenom, 2, &cin, 3, &adresse, 4, &email, 5, &numero, 6, &identifiant, 7, &dt, 8, &sexe,  9, &achat, -1);
    strcpy(g, identifiant);
    strcpy(h, dt);
    strcpy(m, sexe);
    strcpy(a, nom);
    strcpy(b, prenom);
    strcpy(d, adresse);
    strcpy(e, email);
    strcpy(f, numero);
    strcpy(y, cin);
    strcpy(n, achat);   
    }
 
}


void
on_KLbutton_rechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

  GtkWidget *treeview, *recherche_client;
  char ref[10];

  treeview = lookup_widget(button, "KLtreeview");
  recherche_client = lookup_widget(button, "KLentry_recherche");
  strcpy(ref, gtk_entry_get_text(GTK_ENTRY(recherche_client)));
    RechercheKL(ref, treeview);
}
  



void
on_KLbutton_ajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_liste_clients");
  //gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(button, "window_ajouter");
  fenetre_afficher = create_window_ajouter();
 //gtk_window_set_position(GTK_WINDOW(window_modifier),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(fenetre_afficher);
}


void
on_KLbutton_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* p ,*afficher,*w1,*pQuestion;
afficher = lookup_widget(button, "window_liste_clients");
GtkWidget  *KLtreeview = lookup_widget(afficher, "KLtreeview");

        pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
        GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer ce client ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

        suppression(g);
	gtk_widget_destroy(pQuestion);
        affichage(KLtreeview);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}
}

void
on_KLbutton_modifer_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 CLIENT c;
  GtkTreeIter iter;
  gchar *nom;
  gchar *prenom;
  gchar *cin;
  gint *adresse;
  gint *email;
  gint *numero;
  gchar *identifiant;
  gchar *dt;
  gchar *sexe;
  gchar *achat;
  GtkWidget *window_liste_clients;
  GtkWidget *window_modifier;
  GtkWidget *NOM;
  GtkWidget *PRENOM;
  GtkWidget *CIN;
  GtkWidget *ADRESSE;
  GtkWidget *EMAIL;
  GtkWidget *NUMTEL;
  GtkWidget *IDENTIF;
  GtkWidget *JOUR;
  GtkWidget *MOIS;
  GtkWidget *ANNEE;
  GtkWidget *HOMME;
  GtkWidget *FEMME;
  GtkWidget *ACHAT;



    window_modifier = create_window_modifier();
    gtk_widget_hide(window_liste_clients);
    gtk_window_set_position(GTK_WINDOW(window_modifier),GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(window_modifier);
     
    sscanf(h, "%d/%d/%d", &c.d.jour, &c.d.mois, &c.d.annee);
    
    NOM = lookup_widget(window_modifier, "KLentry_modifnom");
    PRENOM = lookup_widget(window_modifier, "KLentry_modifprenom");
    CIN = lookup_widget(window_modifier, "KLentry_modifcin");
    ADRESSE = lookup_widget(window_modifier, "KLentry_modifadresse");
    EMAIL = lookup_widget(window_modifier, "KLentry_modifemail");
    NUMTEL = lookup_widget(window_modifier, "KLentry_modifnumero");
    IDENTIF = lookup_widget(window_modifier, "KLentry_modifidentifiant");
    ACHAT = lookup_widget(window_modifier, "KLentry_modifachat");
    JOUR = lookup_widget(window_modifier, "KLspinbutton_modifajoutjour");
    MOIS = lookup_widget(window_modifier, "KLspinbutton_modifajoutmois");
    ANNEE = lookup_widget(window_modifier, "KLspinbutton_modifajoutannee");
    HOMME = lookup_widget(window_modifier, "choix22");
    FEMME = lookup_widget(window_modifier, "choix11");
    gtk_entry_set_text(GTK_ENTRY(NOM), a);
    gtk_entry_set_text(GTK_ENTRY(PRENOM), b);
    gtk_entry_set_text(GTK_ENTRY(CIN), y);
    gtk_entry_set_text(GTK_ENTRY(ADRESSE), d);
    gtk_entry_set_text(GTK_ENTRY(EMAIL), e);
    gtk_entry_set_text(GTK_ENTRY(NUMTEL), f);
    gtk_entry_set_text(GTK_ENTRY(IDENTIF), g);
    gtk_entry_set_text(GTK_ENTRY(ACHAT), n);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(JOUR), c.d.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(MOIS), c.d.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(ANNEE), c.d.annee);
 
       
    if ((strcmp(c.sexe, "Homme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
    }
    else if ((strcmp(c.sexe, "Femme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
}
}




void
on_KLbutton_enregistrer_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
CLIENT c;
  int condn,condp,condci,conda,conde,condnu,condi;
  int cond1; 
  GtkWidget *KLentry_n;
  GtkWidget *KLentry_p;
  GtkWidget *KLentry_ci;
  GtkWidget *KLentry_a;
  GtkWidget *KLentry_e;
  GtkWidget *KLentry_nu;
  GtkWidget *KLentry_i;
  GtkWidget *KLentry_ac ;
  GtkWidget *jour;
  GtkWidget *mois;
  GtkWidget *annee;
  GtkWidget *choix1;
  GtkWidget *choix2;
 GtkWidget *cond;
  
 
  GtkWidget *dialogajoutclient; 
  GtkWidget *output3;
  GtkWidget *output1;
  GtkWidget *output2;
 GtkWidget *output4;
GtkWidget *outputvide;
GtkWidget *outputespace;
  
const char *format;
char msg[50],*markup;
char iden[20];

int fail=0;
char msg1[40],msg2[40],msg3[50],msg4[50],msgespace[50];
  choix1 = lookup_widget(button, "choix1");
  choix2 = lookup_widget(button, "choix2");
  jour = lookup_widget(button, "KLspinbutton_ajoutjour");
  mois = lookup_widget(button, "KLspinbutton_ajoutmois");
  annee = lookup_widget(button, "KLspinbutton_ajoutannee");
 // output1 = lookup_widget(button, "labelvide");
 output2 = lookup_widget(button, "labelnumclient");
 output3 = lookup_widget(button, "labelcinclient");
 output4 = lookup_widget(button, "labelidclient");
 outputvide= lookup_widget(button, "labelvideclient");
 outputespace= lookup_widget(button, "labelespace");
 
  
  KLentry_n = lookup_widget(button, "KLentry_nom");
  KLentry_p = lookup_widget(button, "KLentry_prenom");
  KLentry_ci = lookup_widget(button, "KLentry_cin");
  KLentry_a = lookup_widget(button, "KLentry_adresse");
  KLentry_e = lookup_widget(button, "KLentry_email");
  KLentry_nu = lookup_widget(button, "KLentry_numero");
  KLentry_i = lookup_widget(button, "KLentry_identifiant");
  KLentry_ac = lookup_widget(button, "KLentry_achat");

strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(KLentry_n)));
  strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(KLentry_p)));
  strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(KLentry_ci)));
  strcpy(c.adresse, gtk_entry_get_text(GTK_ENTRY(KLentry_a)));
  strcpy(c.email, gtk_entry_get_text(GTK_ENTRY(KLentry_e)));
  strcpy(c.numero, gtk_entry_get_text(GTK_ENTRY(KLentry_nu)));
 strcpy(c.achat, gtk_entry_get_text(GTK_ENTRY(KLentry_ac)));
  strcpy(c.identifiant, gtk_entry_get_text(GTK_ENTRY(KLentry_i)));
  c.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
  c.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
  c.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix1)))
  {
    strcpy(c.sexe, "Femme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix2)))
  {
    strcpy(c.sexe, "Homme");
  }

cond = verifid(c.identifiant);
  
if((vide(KLentry_n) ==0) || (vide(KLentry_p) ==0) || (vide(KLentry_ci) ==0) || (vide(KLentry_a) ==0) || (vide(KLentry_nu) ==0) || (vide(KLentry_i) ==0) || (vide(KLentry_ac) ==0) )
       { 
   
gtk_label_set_text(GTK_LABEL(outputvide), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg1, "Champs vide(s)");
    markup= g_markup_printf_escaped(format, msg1);
    gtk_label_set_markup(GTK_LABEL(outputvide), markup);
fail =1;
       }
if (strlen(c.numero)!=8)
{
gtk_label_set_text(GTK_LABEL(output2), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg1, "Inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg1);
    gtk_label_set_markup(GTK_LABEL(output2), markup);
fail =1;
}
if (strlen(c.cin)!=8)
{
gtk_label_set_text(GTK_LABEL(output3), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg2, "Inserez 8 chiffres");
    markup= g_markup_printf_escaped(format, msg2);
    gtk_label_set_markup(GTK_LABEL(output3), markup);
fail =1;
}
if( cond==0)
{
 gtk_label_set_text(GTK_LABEL(output4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg3, "Identifiant existe déjà !");
    markup= g_markup_printf_escaped(format, msg3);
    gtk_label_set_markup(GTK_LABEL(output4), markup);
fail=1;
}
for(int i=0;c.nom[i]!='\0';i++)
{
if(c.nom[i]==' ')
{ gtk_label_set_text(GTK_LABEL(outputespace), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msgespace, "Evitez l'espace !");
    markup= g_markup_printf_escaped(format, msgespace);
    gtk_label_set_markup(GTK_LABEL(outputespace), markup);
fail =1;
}
}

if (fail==0)
{
  


  ajout(c);
  
  

  dialogajoutclient=create_dialogajoutclient();
  gtk_window_set_position(GTK_WINDOW(dialogajoutclient),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(dialogajoutclient);
  }
}


void
on_KLbutton_retour1_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  //GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  //fenetre_ajout = lookup_widget(button, "window_liste_clients");
  fenetre_afficher = lookup_widget(button, "window_ajouter");
  gtk_widget_destroy(fenetre_afficher);
  
 // fenetre_afficher = create_window_liste_clients();
  //gtk_window_set_position(GTK_WINDOW(fenetre_afficher),GTK_WIN_POS_CENTER_ALWAYS);
 // gtk_widget_show(fenetre_afficher);
}


void
on_Gestion_des_clients_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
   GtkWidget *window_liste_clients;
   window1=create_window_gestions();
   window1=lookup_widget(button,"window_gestions");
   gtk_widget_hide(window1);
  window_liste_clients = create_window_liste_clients ();
   gtk_widget_show (window_liste_clients);
}


void
on_KLretouracceuil_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

        GtkWidget *window1;
	GtkWidget *window2;

	window1=lookup_widget(button,"window_liste_clients");
	gtk_widget_destroy(window1);
	window2=create_window_gestions();
	gtk_widget_show(window2); 
}


void
on_KLbutton_afficher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
  GtkWidget *KLtreeview;

  fenetre_afficher = lookup_widget(button, "window_liste_clients");
  KLtreeview = lookup_widget(fenetre_afficher, "KLtreeview");
  //gtk_window_set_position(GTK_WINDOW(fenetre_afficher),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(fenetre_afficher);
  affichage(KLtreeview);
}


void
on_closebuttonajoutclient_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogajoutclient=lookup_widget(GTK_WIDGET(button),("dialogajoutclient"));

gtk_widget_destroy(dialogajoutclient);
}


void
on_KLbutton_valider_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 CLIENT c;

  GtkWidget *KLentry_n;
  GtkWidget *KLentry_p;
  GtkWidget *KLentry_ci;
  GtkWidget *KLentry_a;
  GtkWidget *KLentry_e;
  GtkWidget *KLentry_nu;
  GtkWidget *KLentry_i;
  GtkWidget *KLentry_ac;
  GtkWidget *jour;
  GtkWidget *mois;
  GtkWidget *annee;
  GtkWidget *cond;
  GtkWidget *choix11;
  GtkWidget *choix22;
  GtkWidget *dialog2;
  GtkWidget *KLlabel2;


  choix11 = lookup_widget(button, "choix11");
  choix22 = lookup_widget(button, "choix22");
  jour = lookup_widget(button, "KLspinbutton_modifajoutjour");
  mois = lookup_widget(button, "KLspinbutton_modifajoutmois");
  annee = lookup_widget(button, "KLspinbutton_modifajoutannee");
  KLlabel2 = lookup_widget(button, "KLlabel2");

  KLentry_n = lookup_widget(button, "KLentry_modifnom");
  KLentry_p = lookup_widget(button, "KLentry_modifprenom");
  KLentry_ci = lookup_widget(button, "KLentry_modifcin");
  KLentry_a = lookup_widget(button, "KLentry_modifadresse");
  KLentry_e = lookup_widget(button, "KLentry_modifemail");
  KLentry_nu = lookup_widget(button, "KLentry_modifnumero");
  KLentry_i = lookup_widget(button, "KLentry_modifidentifiant");
  KLentry_ac = lookup_widget(button, "KLentry_modifachat");
  strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(KLentry_n)));
  strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(KLentry_p)));
  strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(KLentry_ci)));
  strcpy(c.adresse, gtk_entry_get_text(GTK_ENTRY(KLentry_a)));
  strcpy(c.email, gtk_entry_get_text(GTK_ENTRY(KLentry_e)));
  strcpy(c.numero, gtk_entry_get_text(GTK_ENTRY(KLentry_nu)));
  strcpy(c.identifiant, gtk_entry_get_text(GTK_ENTRY(KLentry_i)));
  strcpy(c.achat, gtk_entry_get_text(GTK_ENTRY(KLentry_ac)));
  c.d.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
  c.d.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
  c.d.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix11)))
  {
    strcpy(c.sexe, "Femme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix22)))
  {
    strcpy(c.sexe, "Homme");
  }
    if((vide(KLentry_n) ==0) || (vide(KLentry_p) ==0) || (vide(KLentry_ci) ==0) || (vide(KLentry_a) ==0) || (vide(KLentry_nu) ==0) || (vide(KLentry_i) ==0) || (vide(KLentry_ac) ==0) )
   
   gtk_label_set_markup(KLlabel2,"<span foreground='red'><b>Remplir tous les champs SVP !</b></span>");
  
  else {
  dialog2=create_dialog2();
  gtk_window_set_position(GTK_WINDOW(dialog2),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_widget_show(dialog2);
  modification(c.identifiant,c);
 } 
}



void
on_KLbutton_retour2_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_liste_clients");
  fenetre_afficher = lookup_widget(button, "window_modifier");
  gtk_widget_destroy(fenetre_afficher);

  //fenetre_afficher = create_window_liste_clients();
 // gtk_window_set_position(GTK_WINDOW(fenetre_afficher),GTK_WIN_POS_CENTER_ALWAYS);
  //gtk_widget_show(fenetre_afficher);
}


void
on_closebuttonmodifclient_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogmodifclient=lookup_widget(GTK_WIDGET(button),("dialogmodifclient"));

gtk_widget_destroy(dialogmodifclient);
}



/////////////////////////////////gestion des capteurs////////////////////////////////////////////////////////

char RF[30];
char gtype[30], gmarque[30], gval[30], gvali[30], gvals[30], gdate[30], getat[30];
void
on_YBtreeview_LC_row_activated         (GtkTreeView     *YBtreeview_LC,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
 CAPTEUR c;
  GtkTreeIter iter;
  gchar *reference;
  gchar *type;
  gchar *dt;
  gchar *marque;
  gchar *val;
  gchar *vali;
  gchar *vals;
  gchar *etat;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *bonne;
  GtkWidget *panne;
  GtkWidget *humidite;
  GtkWidget *window_GC = lookup_widget(YBtreeview_LC, "window_GC");
  GtkTreeModel *model = gtk_tree_view_get_model(YBtreeview_LC);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &reference, 1, &marque, 2, &type, 3, &dt, 4, &val, 5, &vali, 6, &vals, 7, &etat, -1);
    strcpy(RF, reference);
    strcpy(gmarque, marque);
    strcpy(gtype, type);
    strcpy(gdate, dt);
    strcpy(gval, val);
    strcpy(gvali, vali);
    strcpy(gvals, vals);
    strcpy(getat, etat);
  }
}


void
on_YBbutton_LC_A_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_GC");
  //gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(button, "window_AC");
  fenetre_afficher = create_window_AC();
  gtk_widget_show(fenetre_afficher);
}


void
on_YBbutton_LC_M_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 CAPTEUR c;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *dialog2;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *humidite;
  GtkWidget *comp1;
  GtkWidget *bonne;
  GtkWidget *panne;
  GtkWidget *window_GC = lookup_widget(button, "window_GC");
  GtkWidget *window_MC = lookup_widget(button, "window_MC");
  window_MC = create_window_MC();
  //gtk_widget_hide(window_GC);
  gtk_widget_show(window_MC);

  comp1 = lookup_widget(window_MC, "YBlabel_M_SB_V");
  Reference = lookup_widget(window_MC, "YBentry_M_RC");
  combobox = lookup_widget(window_MC, "YBcombobox_M_MC");
  temperature = lookup_widget(window_MC, "YBradiobutton_M_T");
  humidite = lookup_widget(window_MC, "YBradiobutton_M_H");
  bonne = lookup_widget(window_MC, "YBradiobutton_M_B");
  panne = lookup_widget(window_MC, "YBradiobutton_M_P");
  Valeur = lookup_widget(window_MC, "YBspinbutton_M_V");
  Val_Inf = lookup_widget(window_MC, "YBspinbutton_M_VI");
  Val_Sup = lookup_widget(window_MC, "YBspinbutton_M_VS");

  Jour = lookup_widget(window_MC, "YBspinbutton_M_J");
  Mois = lookup_widget(window_MC, "YBspinbutton_M_M");
  Annee = lookup_widget(window_MC, "YBspinbutton_M_AN");

  gtk_entry_set_text(GTK_ENTRY(Reference), RF);
  if (strcmp(gmarque, "WEENAT") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 0);
  }
  else if (strcmp(gmarque, "SH10") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 1);
  }
  else if (strcmp(gmarque, "RS485") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 2);
  }
  else if (strcmp(gmarque, "STEVENS") == 0)
  {
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox), 3);
  }

  if ((strcmp(gtype, "Temperature") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(temperature), 1);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(humidite), 0);
  }
  else if ((strcmp(gtype, "Humidite") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(temperature), 0);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(humidite), 1);
  }
  if ((strcmp(getat, "Bonne") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(bonne), 1);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(panne), 0);
  }
  else if ((strcmp(getat, "Panne") == 0))
  {
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(bonne), 0);
    gtk_toggle_button_set_active(GTK_RADIO_BUTTON(panne), 1);
  }

  sscanf(gdate, "%d/%d/%d", &c.d.Jour, &c.d.Mois, &c.d.Annee);
  sscanf(gval, "%f", &c.v.Valeur);
  sscanf(gvali, "%f", &c.v.Val_Inf);
  sscanf(gvals, "%f", &c.v.Val_Sup);

  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Valeur), c.v.Valeur);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Val_Inf), c.v.Val_Inf);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Val_Sup), c.v.Val_Sup);

  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Jour), c.d.Jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Mois), c.d.Mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(Annee), c.d.Annee);
}


void
on_YBbutton_LC_S_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget* p ,*afficher,*w1,*pQuestion;
afficher = lookup_widget(button, "window_GC");
GtkWidget  *YBtreeview_LC = lookup_widget(afficher, "YBtreeview_LC");

pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cet capteur ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

  suppressioncap(RF);
	gtk_widget_destroy(pQuestion);
  affichagecap(YBtreeview_LC);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}

	}
on_buttonacceuilcapteur_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_GC;
GtkWidget *window_gestions;
window_GC=lookup_widget(button,"window_GC");
gtk_widget_destroy(window_GC);
window_gestions=create_window_gestions();
gtk_widget_show(window_gestions);
}


void
on_YBbutton_LC_R_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 CAPTEUR c;
  char RF[30];
  GtkWidget *window_GC;
  GtkWidget *YBentry_LC_R;
  GtkWidget *YBtreeview_LC;
  FILE *f;
  FILE *f2;

  window_GC = lookup_widget(button, "window_GC");
  YBentry_LC_R = lookup_widget(button, "YBentry_LC_R");
  strcpy(RF, gtk_entry_get_text(GTK_ENTRY(YBentry_LC_R)));
  f = fopen("capteurs.txt", "r");

  if (f != NULL)
  {
    while (fscanf(f, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
    {
      f2 = fopen("recherche.txt", "a+");
      if (f2 != NULL)
      {
        if ((strcmp(c.Ref_Cap, RF) == 0))
        {
          fprintf(f2, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat);
        }
        YBtreeview_LC = lookup_widget(window_GC, "YBtreeview_LC");
        recherchecap(YBtreeview_LC);
        fclose(f2);
      }
    }
    fclose(f);
  }
  remove("recherche.txt");
}


void
on_YBbutton_LC_AFF_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
  GtkWidget *YBtreeview_LC;

  fenetre_afficher = lookup_widget(button, "window_GC");
  YBtreeview_LC = lookup_widget(fenetre_afficher, "YBtreeview_LC");
  gtk_widget_show(fenetre_afficher);
  affichagecap(YBtreeview_LC);
}


void
on_buttoncapteur_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestions;
   GtkWidget *window_GC;
   window_gestions=create_window_gestions();
   window_gestions=lookup_widget(button,"window_gestions");
 gtk_window_set_position(GTK_WINDOW(window_gestions),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_hide(window_gestions);
   window_GC = create_window_GC ();
 gtk_window_set_position(GTK_WINDOW(window_GC),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_show (window_GC);
}


void
on_YBbutton_A_A_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
 CAPTEUR c;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *Dialog1;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *bonne;
  GtkWidget *panne;
  GtkWidget *humidite;
  GtkWidget *comp,*combocap,*comp4;
  GtkWidget *Ref_Cap;
  int cond, cond1;
  char msg[50], *markup,msg1[50];
  const char *format;

  comp4 = lookup_widget(button, "YBlabel_A_P");
  Ref_Cap = lookup_widget(button, "YBlabel_A_RC_CV");
  combocap= lookup_widget(button, "labelcapcomb");
  comp = lookup_widget(button, "YBlabel_A_SB_V");
  Reference = lookup_widget(button, "YBentry_A_RC");
  combobox = lookup_widget(button, "YBcombobox_A_MC");
  temperature = lookup_widget(button, "YBradiobutton_A_T");
  humidite = lookup_widget(button, "YBradiobutton_A_H");
  bonne = lookup_widget(button, "YBradiobutton_A_B");
  panne = lookup_widget(button, "YBradiobutton_A_P");
  Valeur = lookup_widget(button, "YBspinbutton_A_V");
  Val_Inf = lookup_widget(button, "YBspinbutton_A_VI");
  Val_Sup = lookup_widget(button, "YBspinbutton_A_VS");

  Jour = lookup_widget(button, "YBspinbutton_A_J");
  Mois = lookup_widget(button, "YBspinbutton_A_M");
  Annee = lookup_widget(button, "YBspinbutton_A_AN");

  strcpy(c.Ref_Cap, gtk_entry_get_text(GTK_ENTRY(Reference)));
 

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temperature)) == TRUE)
  {
    strcpy(c.Type_Cap, "Temperature");
  }
  else
  {
    strcpy(c.Type_Cap, "Humidite");
  }

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bonne)) == TRUE)
  {
    strcpy(c.Etat, "Bonne");
  }
  else
  {
    strcpy(c.Etat, "Panne");
  }

  c.d.Jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
  c.d.Mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
  c.d.Annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));

  c.v.Valeur = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Valeur));
  c.v.Val_Inf = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Inf));
  c.v.Val_Sup = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Sup));

  cond1 = verifRef_Cap1(c.Ref_Cap);
  cond = verifRef_Cap(c.Ref_Cap);
  gtk_label_set_text(GTK_LABEL(comp), "");
  gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
  gtk_label_set_text(GTK_LABEL(combocap), "");
  gtk_label_set_text(GTK_LABEL(comp4), "");
  if (c.v.Val_Inf > c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Val_Inf < Val_Sup");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp), markup);
  }
  else if (cond == 0)
  {
    gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Champs Vide !");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(Ref_Cap), markup);
  }
  else if (cond1 == 0)
  {
    gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Reference existante!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(Ref_Cap), markup);
  }
  else if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox))==NULL)
  {
    gtk_label_set_text(GTK_LABEL(combocap), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg1, "Combobox est vide !");
    markup = g_markup_printf_escaped(format, msg1);
    gtk_label_set_markup(GTK_LABEL(combocap), markup);
  }
  else if ((strcmp("Bonne",c.Etat)==0) && c.v.Valeur<c.v.Val_Inf || c.v.Valeur>c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Valeur est hors intervalle\n Capteur est en Panne");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp4), markup);
   }
  else
  { 
    ajoutcap(c);
    SupEsp(c.Ref_Cap);
    gtk_label_set_text(GTK_LABEL(Ref_Cap), "");
    Dialog1 = create_dialogajoutcap();
    gtk_widget_show(Dialog1);
  }
}


void
on_YBbutton_A_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_AC");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(button, "window_GC");
  //fenetre_afficher = create_window_GC();
 // gtk_widget_show(fenetre_afficher);
}


void
on_YBbutton_M_RE_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
  GtkWidget *fenetre_afficher;
  fenetre_ajout = lookup_widget(button, "window_MC");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher = lookup_widget(button, "window_GC");
  ///fenetre_afficher = create_window_GC();
  //gtk_widget_show(fenetre_afficher);
}


void
on_YBbutton_M_M_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR c;
  GtkWidget *Reference;
  GtkWidget *Valeur;
  GtkWidget *Val_Inf;
  GtkWidget *Val_Sup;
  GtkWidget *Jour;
  GtkWidget *Mois;
  GtkWidget *Annee;
  GtkWidget *dialog2;
  GtkWidget *combobox;
  GtkWidget *temperature;
  GtkWidget *humidite;
  GtkWidget *comp1,*comp2,*comp4;
  GtkWidget *bonne;
  GtkWidget *panne;
  int cond1;
  char msg[50], *markup;
  const char *format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";

  comp1 = lookup_widget(button, "YBlabel_M_SB_V");
  comp2 = lookup_widget(button, "YBlabel_M_RC_V");
  comp4 = lookup_widget(button, "YBlabel_M_P");
  Reference = lookup_widget(button, "YBentry_M_RC");
  combobox = lookup_widget(button, "YBcombobox_M_MC");
  temperature = lookup_widget(button, "YBradiobutton_M_T");
  humidite = lookup_widget(button, "YBradiobutton_M_H");
  bonne = lookup_widget(button, "YBradiobutton_M_B");
  panne = lookup_widget(button, "YBradiobutton_M_P");
  Valeur = lookup_widget(button, "YBspinbutton_M_V");
  Val_Inf = lookup_widget(button, "YBspinbutton_M_VI");
  Val_Sup = lookup_widget(button, "YBspinbutton_M_VS");

  Jour = lookup_widget(button, "YBspinbutton_M_J");
  Mois = lookup_widget(button, "YBspinbutton_M_M");
  Annee = lookup_widget(button, "YBspinbutton_M_AN");

  strcpy(c.Ref_Cap, gtk_entry_get_text(GTK_ENTRY(Reference)));
  strcpy(c.Marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(temperature)))
  {
    strcpy(c.Type_Cap, "Temperature");
  }
  else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(humidite)))
  {
    strcpy(c.Type_Cap, "Humidite");
  }
  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(bonne)))
  {
    strcpy(c.Etat, "Bonne");
  }
  else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(panne)))
  {
    strcpy(c.Etat, "Panne");
  }
  c.d.Jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
  c.d.Mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
  c.d.Annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));

  c.v.Valeur = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Valeur));
  c.v.Val_Inf = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Inf));
  c.v.Val_Sup = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(Val_Sup));

  cond1 = verifRef_Cap1(c.Ref_Cap);
  gtk_label_set_text(GTK_LABEL(comp2), "");
  gtk_label_set_text(GTK_LABEL(comp1), "");
  gtk_label_set_text(GTK_LABEL(comp4), "");
  if (cond1 == 1)
  {
    gtk_label_set_text(GTK_LABEL(comp2), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Reference non existante!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp2), markup);
  }
  else if (c.v.Val_Inf > c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp1), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Val_Inf < Val_Sup!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp1), markup);
  }
  else if ((strcmp("Bonne",c.Etat)==0) && c.v.Valeur<c.v.Val_Inf || c.v.Valeur>c.v.Val_Sup)
  {
    gtk_label_set_text(GTK_LABEL(comp4), "");
    format = "<span foreground=\"#b50b6b\"><b>\%s</b></span>";
    sprintf(msg, "Valeur est hors intervalle\n Capteur est en Panne");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp4), markup);
   }
  
  else
  {
    sprintf(msg, "");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(comp1), markup);
    gtk_label_set_markup(GTK_LABEL(comp2), markup);
    SupEsp(c.Ref_Cap);
    modificationcap(c.Ref_Cap, c);
    dialog2 = create_dialogmodifcap();
    gtk_widget_show(dialog2);
  }
}

//////////////////////////////////////////////////////////////////////////
void
on_closebuttonajoutcap_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *Dialog1;
  Dialog1 = lookup_widget(button, "dialogajoutcap");
  gtk_widget_destroy(Dialog1);
}

///////////////////////////////////////////////////////////////////////////
void
on_closebuttonmodifcap_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dialog2;
  Dialog2 = lookup_widget(button, "dialogmodifcap");
  gtk_widget_destroy(Dialog2);
}

///////////////////////////////////////////////////////////////////////////
void
on_closebuttonsuppcap_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *Dialog3;
  Dialog3 = lookup_widget(button, "dialogsuppcap");
  gtk_widget_destroy(Dialog3);
}




////////////////////////////////////////////////////////////////////////

void
on_closebuttonauth_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialogauth=lookup_widget(GTK_WIDGET(button),("dialogauth"));

gtk_widget_destroy(dialogauth);
 
}

//////////////////////////////////////gestion des plantes//////////////////////////
void
on_buttondeconnexionadmin_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_admin;
   GtkWidget *window_auth;
   //window_gestions=create_window_gestions();
   window_admin=lookup_widget(button,"window_admin");
   gtk_window_set_position(GTK_WINDOW(window_admin),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_hide(window_admin);
   window_auth = create_window_auth();
   gtk_window_set_position(GTK_WINDOW(window_auth),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_show (window_auth);
}


void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
  GtkWidget *treeviewchi;
  fenetre_afficher = lookup_widget(button, "window_calendrier");
  treeviewchi = lookup_widget(fenetre_afficher, "treeviewchi");
  gtk_widget_show(fenetre_afficher);
  affichageplante(treeviewchi);
}


void
on_acceuilplante_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_gestions;
	GtkWidget *window_calendrier;

	window_calendrier=lookup_widget(button,"window_calendrier");
	gtk_widget_destroy(window_calendrier);
	window_gestions=create_window_gestions();
	gtk_widget_show(window_gestions);  
}
//////////////////////////////////////////////////////////////////////
void on_Supprimer_clicked(GtkButton *button,
                          gpointer user_data)
{
GtkWidget *affic,*w1,*pQuestion1;
affic = lookup_widget(button, "window_calendrier");
GtkWidget  *treeviewchi = lookup_widget(affic, "treeviewchi");

pQuestion1 = gtk_message_dialog_new(GTK_WINDOW(affic),
GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cet plante ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion1)))
	{
	case GTK_RESPONSE_YES:

  suppressionplante(gid);
	gtk_widget_destroy(pQuestion1);
  affichageplante(treeviewchi);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion1);
	break;

	}
}
//////////////////////////////////////////////////////////////////////

void
on_modifider_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
  GtkWidget *ID;
  GtkWidget *TOMATE,*POMME,*FRAISE,*AVOCAT;
  GtkWidget *STOCK;
  GtkWidget *RECOLTE;
  GtkWidget *J1, *M1, *A1;
  GtkWidget *J2, *M2, *A2;
gchar *id;
gchar *type;
GtkTreeSelection *selection;
GtkTreeModel     *model;
GtkTreeIter iter;
gchar *stock,*recoltee,*plantation,*recolte;
  GtkWidget *window_calendrier = lookup_widget(button, "window_calendrier");
  GtkWidget *dialog4 = lookup_widget(button, "dialog4");
dialog4 = create_dialog4();
gtk_widget_show(dialog4);
GtkWidget *treeview; 
  ID = lookup_widget(dialog4, "entrymid");

treeview=lookup_widget(button,"treeviewchi");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        { 

gtk_tree_model_get ((model),&iter,0,&id,1,&type,2,&stock,3,plantation,4,recolte,-1);
strcpy(p.type,type);
  
  ID = lookup_widget(dialog4, "entrymid");
  STOCK = lookup_widget(dialog4, "mstock");
  RECOLTE = lookup_widget(dialog4, "entrymrecolte");

  J1 = lookup_widget(dialog4, "mjour1");
  M1 = lookup_widget(dialog4, "mmois1");
  A1 = lookup_widget(dialog4, "mannee1");
  J2 = lookup_widget(dialog4, "mjour2");
  M2 = lookup_widget(dialog4, "mmois2");
  A2 = lookup_widget(dialog4, "mannee2");
TOMATE= lookup_widget(dialog4,"tomate");
POMME= lookup_widget(dialog4,"pomme");
FRAISE= lookup_widget(dialog4,"fraise");
AVOCAT= lookup_widget(dialog4,"avocat");

if ((strcmp(p.type, "tomate") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 0);
    }
    else if ((strcmp(p.type, "pomme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 0);
    }
    else if ((strcmp(p.type, "fraise") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 0);
    }
    else if ((strcmp(p.type, "avocat") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 1);
    }

  sscanf(grecolte, "%d", &p.stock);
  sscanf(gdtpl, "%d/%d/%d", &p.plantation.jour, &p.plantation.mois, &p.plantation.annee);
  sscanf(gdtrec, "%d/%d/%d", &p.recolte.jour, &p.recolte.mois, &p.recolte.annee);
  gtk_entry_set_text(GTK_ENTRY(ID), gid);
  gtk_entry_set_text(GTK_ENTRY(RECOLTE), gstock);
  gtk_entry_set_text(GTK_ENTRY(STOCK),grecolte);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(STOCK), p.stock);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(J1), p.plantation.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(M1), p.plantation.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(A1), p.plantation.annee);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(J2), p.recolte.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(M2), p.recolte.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(A2), p.recolte.annee);
}
}

///////////////////////////////////////////////////
void
on_Ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *window_ajout;
	window_ajout=create_window_ajoutplante();
	gtk_widget_show(window_ajout);
}
////////////////////////////////////////////////////////////////////////////////



void
on_treeviewchi_row_activated           (GtkTreeView     *treeviewchi,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
PLANTE p;
  GtkTreeIter iter;
  gchar *ID;
  gchar *TYPE;
  gchar *RECOLTE;
  gchar *STOCK;
  gchar *DTPL;
  gchar *DTREC;

  GtkWidget *window_calendrier = lookup_widget(treeviewchi, "window_calendrier");
  GtkTreeModel *model = gtk_tree_view_get_model(treeviewchi);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &ID, 1, &TYPE, 2, &STOCK, 3, &RECOLTE, 4, &DTPL, 5, &DTREC, -1);
    strcpy(gid, ID);
    strcpy(gtypep, TYPE);
    strcpy(gstock, STOCK);
    strcpy(grecolte, RECOLTE);
    strcpy(gdtpl, DTPL);
    strcpy(gdtrec, DTREC);
  }
}


void
on_retourajoutplante_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *ajoutedate, *calendrier;
  ajoutedate = lookup_widget(button, "window_ajoutplante");
  gtk_widget_destroy( ajoutedate);

  //calendrier = create_window_calendrier();
  //gtk_widget_show(calendrier);
}


void
on_valideajoutplante_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

PLANTE p;
  int cond1;
  GtkWidget *controld1;
  GtkWidget *dialog;
  GtkWidget *inputid, *inputstock;
 // GtkWidget *ajout;
  GtkWidget *choixt, *choixp, *choixf, *choixa;
  GtkWidget *jourp, *moisp, *anneep;
  GtkWidget *jourp2, *moisp2, *anneep2;
  GtkWidget *stock;
  controld1=lookup_widget(button,"control1");
  choixt = lookup_widget(button, "choixt");
  choixp = lookup_widget(button, "choixp");
  choixf = lookup_widget(button, "choixf");
  choixa = lookup_widget(button, "choixa");
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choixt)) == TRUE)
  {
    strcpy(p.type, "tomate");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choixp)) == TRUE)
  {
    strcpy(p.type, "pomme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choixf)) == TRUE)
  {
    strcpy(p.type, "fraise");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choixa)) == TRUE)
  {
    strcpy(p.type, "avocat");
  }

  inputstock = lookup_widget(button, "entrystock");
  inputid = lookup_widget(button, "entryidchi");
  stock = lookup_widget(button, "spinreco");

  jourp= lookup_widget(button, "jour1");
  moisp = lookup_widget(button, "mois1");
  anneep = lookup_widget(button, "annee1");

  jourp2 = lookup_widget(button, "jour2");
  moisp2 = lookup_widget(button, "mois2");
  anneep2 = lookup_widget(button, "annee2");

  strcpy(p.recoltee, gtk_entry_get_text(GTK_ENTRY(inputstock)));
  strcpy(p.id, gtk_entry_get_text(GTK_ENTRY(inputid)));
  p.stock = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(stock));

  p.plantation.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourp));
  p.plantation.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisp));
  p.plantation.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneep));

  p.recolte.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourp2));
  p.recolte.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisp2));
  p.recolte.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneep2));

	cond1=verifierpl(p.id);
if((is_empty(inputstock)==0) || (is_empty(inputid)==0))
{

	gtk_label_set_markup(controld1,"<span foreground='black'><b>Remplir tous les champs !</b></span>");
}

else if((p.plantation.jour >= 32) || (p.plantation.mois >= 13) ||  (p.plantation.annee >= 2099) || (p.recolte.jour >= 32) || (p.recolte.mois >= 13) ||  (p.recolte.annee >= 2099)){

	gtk_label_set_markup(controld1,"<span foreground='black'><b>Format date invalide!!</b></span>");
}
else if (cond1==1){
	gtk_label_set_markup(controld1,"<span foreground='black'><b> Id existe déjà !</b></span>");}
else {
gtk_label_set_text(GTK_LABEL(controld1)," ");
  ajouterplante(p);
GtkWidget *ajoutedate = lookup_widget(button, "window_ajoutplante");
  gtk_widget_destroy( ajoutedate);
dialog = create_dialogajoutplante();
  gtk_widget_show(dialog);}
}


void
on_buttongestioncalen_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *window_gestions;
   GtkWidget *window_calendrier;
   window_gestions=create_window_gestions();
   window_gestions=lookup_widget(button,"window_gestions");
 gtk_window_set_position(GTK_WINDOW(window_gestions),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_hide(window_gestions);
   window_calendrier = create_window_calendrier ();
 gtk_window_set_position(GTK_WINDOW(window_calendrier),GTK_WIN_POS_CENTER_ALWAYS);
   gtk_widget_show (window_calendrier);
}

void
on_closebuttonajoutplante_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *dialogajoutplante=lookup_widget(GTK_WIDGET(button),("dialogajoutplante"));

gtk_widget_destroy(dialogajoutplante);
}


void
on_rechercher_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *recherche_plante, *fenetre_afficher;
  char ref[10];
  GtkWidget *control=lookup_widget(button,"Search");
  treeview = lookup_widget(button, "treeviewchi");
  recherche_plante = lookup_widget(button, "entryrechchi");
	if((is_empty(recherche_plante)==0)  )
	{
		
gtk_label_set_markup(control,"<span foreground='black'><b>Champ manquant!!</b></span>");

	}
	else {
gtk_label_set_text(GTK_LABEL(control)," ");
  strcpy(ref, gtk_entry_get_text(GTK_ENTRY(recherche_plante)));
    Rechercheplante(ref, treeview);}
}


void
on_aps_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
char ch1[50],ch2[50];
int year;
int rct;
year=boardplantation (p);
rct=roardplantation (p);

GtkWidget *window=lookup_widget(button,"window_tableau_de_bord");

GtkWidget *message1=lookup_widget(window,"labelapsA");
GtkWidget *message2=lookup_widget(window,"labelapsR");

sprintf(ch1,"l'annee la plus seche est = %d",year);
gtk_label_set_text(GTK_LABEL(message1),ch1);

sprintf(ch2,"avec un total de recolte = %d (kg)",rct);
gtk_label_set_text(GTK_LABEL(message2),ch2);
}


void
on_sauvegarderplante_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
  gchar *type;
  GtkWidget *ID;
  GtkWidget *STOCK,*RECOLTE;
  GtkWidget *TOMATE,*POMME,*FRAISE,*AVOCAT;
  GtkWidget *J1, *M1, *A1;
  GtkWidget *J2, *M2, *A2;
  GtkWidget *dialog4 = lookup_widget(button, "dialog4");
  GtkWidget *dialog;

  ID = lookup_widget(button, "entrymid");
  STOCK = lookup_widget(button, "mstock");
  RECOLTE = lookup_widget(button, "entrymrecolte");

  J1 = lookup_widget(button, "mjour1");
  M1 = lookup_widget(button, "mmois1");
  A1 = lookup_widget(button, "mannee1");
  J2 = lookup_widget(button, "mjour2");
  M2 = lookup_widget(button, "mmois2");
  A2 = lookup_widget(button, "mannee2");


   strcpy(p.id, gtk_entry_get_text(GTK_ENTRY(ID)));
  strcpy(p.recoltee, gtk_entry_get_text(GTK_ENTRY(RECOLTE)));
  gtk_entry_set_text(GTK_ENTRY(RECOLTE), grecolte);

TOMATE= lookup_widget(button,"tomate");
POMME= lookup_widget(button,"pomme");
FRAISE= lookup_widget(button,"fraise");
AVOCAT= lookup_widget(button,"avocat");

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(TOMATE)) == TRUE)
  {
    strcpy(p.type, "tomate");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(POMME)) == TRUE)
  {
    strcpy(p.type, "pomme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(FRAISE)) == TRUE)
  {
    strcpy(p.type, "fraise");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(AVOCAT)) == TRUE)
  {
    strcpy(p.type, "avocat");
  }

  p.stock = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(STOCK));
  p.plantation.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(J1));
  p.plantation.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(M1));
  p.plantation.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(A1));

  p.recolte.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(J2));
  p.recolte.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(M2));
  p.recolte.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(A2));
  modificationplante(p.id, p);
 // gtk_widget_hide(dialog4);
GtkWidget *dialog1=lookup_widget(button,"dialog4");
gtk_widget_destroy(dialog1);
  dialog = create_dialogmodplante();
  gtk_widget_show(dialog);
}


void
on_closebuttonmodifaplante_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog=lookup_widget(GTK_WIDGET(button),("dialogmodplante"));

gtk_widget_destroy(dialog);
}


void
on_retourplantemod_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_m;
  GtkWidget *fenetre_aj;
  fenetre_aj = lookup_widget(button, "window_calendrier");
  fenetre_m = lookup_widget(button, "dialog4");
  gtk_widget_destroy(fenetre_m);
}


void
on_buttonouiplante_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_buttonnonplante_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
 }







void
on_KLbutton_fid_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *max , *var ;
   CLIENT c;
   FILE *f;
   char id[50];
   char achat[20];
   char identifiant[20];
   char machats[20];
   int i;
   int j=0;

       f = fopen("client.txt", "r+");
       while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat) != EOF)
		      
       {       
	strcpy(machats,c.achat);
	sscanf (machats,"%d",&i);

	  if (i>j){
	            j =i;
	            strcpy(id,c.identifiant);}

       }
	fclose (f);
 	sprintf(achat,"%d DT",j);
 	max=lookup_widget (button,"KLentry_fid");
 	var=lookup_widget (button,"KLentry_fid1"); 
  	gtk_entry_set_text(GTK_ENTRY(max),achat); 
  	gtk_entry_set_text(GTK_ENTRY(var),id);
}




void
on_YBcheckbutton_VA_MPD_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *valeur_alr,*Mrq_Deff,*VA,*MPD;
char msg[50], *markup;
const char *format = "<span foreground=\"#FF0000\"><b>\%s</b></span>";
valeur_alr=lookup_widget(button, "YBlabel_VA");
Mrq_Deff=lookup_widget(button, "YBlabel_MPD");
VA=lookup_widget(button, "YBcheckbutton_A_VA");
MPD=lookup_widget(button, "YBcheckbutton_A_MPD");
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
gtk_label_set_text(GTK_LABEL(valeur_alr), "");
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(VA)))
{
int resu=alarment();
char al[200];
gtk_label_set_text(GTK_LABEL(valeur_alr), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(al, "le nombre ayant une valeur alarmante est:%d", resu);
markup = g_markup_printf_escaped(format, al);
gtk_label_set_markup(GTK_LABEL(valeur_alr), markup);
}
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON(MPD)))
{
CAPTEUR c;
FILE *f;
int n=0,m=0,p=0,z=0,res=0;

f=fopen("capteurs.txt","a+");
if(f!=NULL){
while (fscanf(f, "%s %s %s %s %s %s %s %s", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
{
	if(strcmp("WEENAT",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){n++;}
	}
        else if(strcmp("RS485",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){m++;}
	}
        else if(strcmp("SH10",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){p++;}
	}
        else if(strcmp("STEVENS",c.Marque)==0)
	{
	   if(strcmp("Panne",c.Etat)==0){z++;}
	}
	
}
}
fclose(f);
if(n>=m && n>=p && n>=z){res=n;}
else if(m>=n && m>=p && m>=z){res=m;}
else if(p>=n && p>=m && p>=z){res=p;}
else if(z>=m && z>=n && z>=p){res=z;}
if(res==n)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'WEENAT'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
else if(res==m)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'RS485'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
else if(res==p)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'SH10'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
else if(res==z)
{
gtk_label_set_text(GTK_LABEL(Mrq_Deff), "");
format = "<span foreground=\"#000000\"><b>\%s</b></span>";
sprintf(msg, "la marque la plus defectueuse est 'STEVENS'");
markup = g_markup_printf_escaped(format, msg);
gtk_label_set_markup(GTK_LABEL(Mrq_Deff), markup);}
}
}

