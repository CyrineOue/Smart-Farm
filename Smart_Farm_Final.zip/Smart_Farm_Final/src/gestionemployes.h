
#include<stdio.h>
#include<stdlib.h>
#include <gtk/gtk.h>
#include<string.h>

typedef struct {
int jour;
int mois;
int annee;
}Datecy;
typedef struct {
char cin[60];
char matricule[30];
char password[30];
char nom[20];
char prenom[20];
char numtel[30];
int role;
Datecy date;
} employe;

void ajouteremploye(employe e);              
void supprimeremploye(char *cin);
void afficherlisteemployes(GtkWidget *liste,employe e);
void afficherrecherchecin(GtkWidget *liste,employe e);
void rechercheemploye(employe e,char matricule[]);
int verifier (char login[50], char password[50]);

