
#include<stdio.h>
#include<stdlib.h>
#include <gtk/gtk.h>
#include<string.h>

typedef struct {
int jour;
int mois;
int annee;
}Dateeq;

typedef struct {
char type[30];
char reference[30];
char prix[50];
Dateeq dt;
char etat[50];

}equipement;

void ajouterequipement(equipement eq);              
void supprimerequipement(char *ref);

void afficherlisteequipements(GtkWidget *liste,equipement eq);
void afficherrecherche(GtkWidget *liste);
void Recherche(equipement eq,char type[]);
void listedefect(equipement eq);
void afficherdefect(GtkWidget *liste);
//Partie2
int statistiques();

