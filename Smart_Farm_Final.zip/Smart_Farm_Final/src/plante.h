#include <gtk/gtk.h>
typedef struct
{
    int jour, mois, annee;
} DATEE;

typedef struct
{
    char type[20];
    char id[20];
    char recoltee[20];
    int stock;
    char dtrec[30];
    char dtpl[30];
    DATEE plantation;
    DATEE recolte;
} PLANTE;

void ajouterplante(PLANTE p);
void Rechercheplante(char ref[20], GtkWidget *liste);
void suppressionplante(char ref[20]);
void affichageplante(GtkWidget *liste);
void modificationplante(char ref[20], PLANTE p);
//////////////////////////
int verifierpl(char ref[20]);
int is_empty(GtkWidget *entry) ;
//////////////////////////
int boardplantation (PLANTE p);
int roardplantation (PLANTE p);
//////////////////////////
