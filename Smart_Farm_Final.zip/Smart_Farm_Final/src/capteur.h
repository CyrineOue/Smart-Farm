#include <gtk/gtk.h>
typedef struct
{
    float Valeur;
    float Val_Inf;
    float Val_Sup;
} VA;
typedef struct
{
    int Jour;
    int Mois;
    int Annee;
} DATE;

typedef struct
{
    char Marque[30];
    char dt[30];
    char Ref_Cap[30];
    char Type_Cap[30];
    char V[30];
    char VI[30];
    char VS[30];
    char Etat[30];
    DATE d;
    VA v;
} CAPTEUR;

void ajoutcap(CAPTEUR c);
void recherchecap(GtkWidget *YBtreeview_LC);
void suppressioncap(char RF[30]);
void affichagecap(GtkWidget *YBtreeview_LC);
void modificationcap(char rf[30], CAPTEUR c);
int verifRef_Cap1(char RF[30]);
int verifRef_Cap(char ref[]);

