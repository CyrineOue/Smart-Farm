
#include <gtk/gtk.h>


typedef struct 
{
int id;
char nom[25];
char prenom[50];
char sexe[20];
char cin[20];
int jour ; 
int mois ; 
int anne ; 
char tel[15];
char tache[100];
}Ouvrier;

typedef struct 
{
int id ;
char nom[25]; 
char prenom[50]; 
int j ; 
int m ; 
int a ; 
char etat[20]; 
}Point;


void ajouter_ouv (Ouvrier ouv);
void supprimer_ouv(char id[]);
void modifier_ouv(char id1[], char ntel[], char ntache[]);
void rechercher_ouv(GtkWidget *liste,char id2[]);
void afficher_ouv(GtkWidget *liste);



void pointage(Point p,char id[]); 
void absence(Point p,char id1[]);
void afficherbest(GtkWidget *liste);
int TauxTotal();
int idtop() ; 
void Top(int x);
void affichertop(GtkWidget *liste);

