#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "capteur.h"

enum
{
   YBREF,
   YBMRQ,
   YBTYPE,
   YBDATE,
   YBVAL,
   YBVAL_INF,
   YBVAL_SUP,
   YBETAT,
   COLUMNS
};
//------------------------------------------------------********---------------------------------------------------
void affichagecap(GtkWidget *YBtreeview_LC)
{
   CAPTEUR c;
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;

   gtk_list_store_clear(YBtreeview_LC);
   FILE *f = NULL;
   store = gtk_tree_view_get_model(YBtreeview_LC);
   if (store == NULL)
   {
      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" REFERENCE", renderer, "text", YBREF, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" MARQUE", renderer, "text", YBMRQ, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" TYPE", renderer, "text", YBTYPE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" DATE", renderer, "text", YBDATE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR", renderer, "text", YBVAL, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR INF", renderer, "text", YBVAL_INF, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR SUP", renderer, "text", YBVAL_SUP, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" ETAT", renderer, "text", YBETAT, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);
   }
   store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   f = fopen("capteurs.txt", "r");
   if (f == NULL)
   {
      return;
   }
   else
   {
    
      while (fscanf(f, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
      {
         gtk_list_store_append(store, &iter);
         gtk_list_store_set(store, &iter, YBREF, c.Ref_Cap, YBMRQ, c.Marque, YBTYPE, c.Type_Cap, YBDATE, c.dt, YBVAL, c.V, YBVAL_INF, c.VI, YBVAL_SUP, c.VS, YBETAT, c.Etat, -1);
      }
      
      gtk_tree_view_set_model(GTK_TREE_VIEW(YBtreeview_LC), GTK_TREE_MODEL(store));
      g_object_unref(store);
   }
   fclose(f);
}

//-------------------------------------------------------*******-----------------------------------------------------------
void ajoutcap(CAPTEUR c)
{
   FILE *f;
   sprintf(c.dt, "%d/%d/%d", c.d.Jour, c.d.Mois, c.d.Annee);
   sprintf(c.V, "%.2f", c.v.Valeur);
   sprintf(c.VI, "%.2f", c.v.Val_Inf);
   sprintf(c.VS, "%.2f", c.v.Val_Sup);
   f = fopen("capteurs.txt", "a+");
   if (f != NULL)
   {
      fprintf(f, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat);
      fclose(f);
   }
}
//------------------------------------------------------------------------------------------------------------------------

void suppressioncap(char ref[30])
{
   CAPTEUR c;
   FILE *f, *F;

   f = fopen("capteurs.txt", "a+");
   F = fopen("tmp.txt", "a+");

   if ((f == NULL) || (F == NULL))
   {
      return;
   }
   else
   {
      while (fscanf(f, "%s %s %s %s %s %s %s %s", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
      {
         if (strcmp(ref, c.Ref_Cap) != 0)
         {
            fprintf(F, "%s %s %s %s %s %s %s %s \n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat);
         }
      }
      fclose(f);
      fclose(F);
      remove("capteurs.txt");
      rename("tmp.txt", "capteurs.txt");
   }
}


//------------------------------------------------------------------------------------------------------------------------

void modificationcap(char rf[30], CAPTEUR c)
{
   CAPTEUR u;
   FILE *f1 = NULL, *f = NULL;
   sprintf(c.dt, "%d/%d/%d", c.d.Jour, c.d.Mois, c.d.Annee);
   sprintf(u.dt, "%d/%d/%d", u.d.Jour, u.d.Mois, u.d.Annee);

   sprintf(c.V, "%.2f", c.v.Valeur);
   sprintf(c.VI, "%.2f", c.v.Val_Inf);
   sprintf(c.VS, "%.2f", c.v.Val_Sup);

   sprintf(u.V, "%.2f", u.v.Valeur);
   sprintf(u.VI, "%.2f", u.v.Val_Inf);
   sprintf(u.VS, "%.2f", u.v.Val_Sup);
   f = fopen("capteurs.txt", "r");
   f1 = fopen("tmp.txt", "w");
   if ((f != NULL) && (f1 != NULL))
   {
      while (fscanf(f, "%s %s %s %s %s %s %s %s\n", u.Ref_Cap, u.Marque, u.Type_Cap, u.dt, u.V, u.VI, u.VS, u.Etat) != EOF)
      {
         if (strcmp(rf, u.Ref_Cap) != 0)
         {
            fprintf(f1, "%s %s %s %s %s %s %s %s\n", u.Ref_Cap, u.Marque, u.Type_Cap, u.dt, u.V, u.VI, u.VS, u.Etat);
         }
         else
         {
            fprintf(f1, "%s %s %s %s %s %s %s %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat);
         }
      }
   }
   fclose(f);
   fclose(f1);
   remove("capteurs.txt");
   rename("tmp.txt", "capteurs.txt");
}
//------------------------------------------------------------------------------------------------------------------------
void recherchecap(GtkWidget *YBtreeview_LC)
{
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   GtkListStore *store;

   store = NULL;
   CAPTEUR c;
   FILE *f2;
   sprintf(c.dt, "%d/%d/%d", c.d.Jour, c.d.Mois, c.d.Annee);
   store = gtk_tree_view_get_model(YBtreeview_LC);
   if (store == NULL)
   {

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" REFERENCE", renderer, "text", YBREF, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" MARQUE", renderer, "text", YBMRQ, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" TYPE", renderer, "text", YBTYPE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" DATE", renderer, "text", YBDATE, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR", renderer, "text", YBVAL, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR INF", renderer, "text", YBVAL_INF, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" VALEUR SUP", renderer, "text", YBVAL_SUP, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);

      renderer = gtk_cell_renderer_text_new();
      column = gtk_tree_view_column_new_with_attributes(" ETAT", renderer, "text", YBETAT, NULL);
      gtk_tree_view_append_column(GTK_TREE_VIEW(YBtreeview_LC), column);
   }

   store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   f2 = fopen("recherche.txt", "r");
   if (f2 == NULL)
   {
      return;
   }
   else
   {
      f2 = fopen("recherche.txt", "a+");
      while (fscanf(f2, "%s %s %s %s %s %s %s %s", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
      {
         gtk_list_store_append(store, &iter);
         gtk_list_store_set(store, &iter, YBREF, c.Ref_Cap, YBMRQ, c.Marque, YBTYPE, c.Type_Cap, YBDATE, c.dt, YBVAL, c.V, YBVAL_INF, c.VI, YBVAL_SUP, c.VS, YBETAT, c.Etat, -1);
      }
      fclose(f2);
      gtk_tree_view_set_model(GTK_TREE_VIEW(YBtreeview_LC), GTK_TREE_MODEL(store));
      g_object_unref(store);
   }
}
//--------------------------------------------------------------------------------------------------------------------------------------
int verifRef_Cap(char ref[])
{
   int r = 0;
   if (strcmp(ref, "") == 0)
   {
      r = 0;
   }
   else
   {
      r = 1;
   }
   return r;
}
//--------------------------------------------------------------------------------------------------------------------------------------
int verifRef_Cap1(char RF[30])
{
   CAPTEUR c;
   int res = 1;
   FILE *f;
   f = fopen("capteurs.txt", "a+");
   if (f != NULL)
   {
      while (fscanf(f, "%s %s %s %s %s %s %s %s", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, c.V, c.VI, c.VS, c.Etat) != EOF)
      {
         if (strcmp(RF, c.Ref_Cap) == 0)
         {
            res = 0;
         }
         else
         {
            res = 1;
         }
      }
   }
   fclose(f);
   return res;
}
//---------------------------------------------------------------------------------------------------------------------------------
void SupEsp(char rf[])
{
   int j = 0;
   for (int i = 0; rf[i]; i++)
   {
      if (rf[i] != ' ')
      {
         rf[j++] = rf[i];
      }
   }
   rf[j] = '\0';
}
//----------------------------------------------------------------------------------------------------------------------------------
int alarment(){
CAPTEUR c;
FILE *f,*F;
int n=0;
f=fopen("capteurs.txt","a+");
if(f!=NULL){
while (fscanf(f, "%s %s %s %s %f %f %f %s\n", c.Ref_Cap, c.Marque, c.Type_Cap, c.dt, &c.v.Valeur, &c.v.Val_Inf, &c.v.Val_Sup, c.Etat) != EOF)
{
	if (c.v.Valeur<c.v.Val_Inf || c.v.Valeur>c.v.Val_Sup)
	{
	n++;
	}
	
}
}
fclose(f);
return n;
}
