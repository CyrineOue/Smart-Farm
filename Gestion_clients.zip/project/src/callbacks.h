#include <gtk/gtk.h>


void
on_KLtreeview_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_KLbutton_rechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_ajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_enregistrer_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_afficher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_rechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_ajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_afficher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_retour1_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLtreeview_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_KLbutton_enregistrer_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_valider_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_retour2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KLbutton_fid_clicked                (GtkButton       *button,
                                        gpointer         user_data);
