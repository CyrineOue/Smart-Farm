#include <gtk/gtk.h>
typedef struct
{
    int jour;
    int mois;
    int annee;
} DATe;

typedef struct
{

    char nom[100];
    char prenom[100];
    char adresse[1000];
    char email[100];
    char identifiant[100];
    char cin[30];
    char numero[30];
    char dt[30];
    char sexe[50];
    char achat[50];  
    DATe d;

} CLIENT;

void ajout(CLIENT c);
void modification(char id[30], CLIENT c);
void suppression(char g[30]);
void recherche(GtkWidget *KLtreeview);
void affichage(GtkWidget *KLtreeview);
int verifid(char id[30]);
int vide(GtkWidget *entry);

