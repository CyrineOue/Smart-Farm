#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <gtk/gtk.h>
#include "client.h"

enum
{
	NOM,
	PRENOM,
	CIN,
	ADRESSE,
	EMAIL,
	NUMERO,
	IDENTIFIANT,
	DATE,
	SEXE,
        ACHAT,
	COLUMNS
};
//******************************************************************************************************************************************************************************//

void affichage(GtkWidget *KLtreeview)
{
	CLIENT c;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	gtk_list_store_clear(KLtreeview);
	FILE *f = NULL;
	store = gtk_tree_view_get_model(KLtreeview);
	if (store == NULL)

	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text", NOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text", PRENOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text", CIN, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("adresse", renderer, "text", ADRESSE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("email", renderer, "text", EMAIL, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("numero", renderer, "text", NUMERO, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text", IDENTIFIANT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text", DATE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text", SEXE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);
                
                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("achat", renderer, "text", ACHAT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);
	}

	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
	f = fopen("client.txt", "r");
	if (f == NULL)
	{
		return;
	}
	else
	{
		
		while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat) != EOF)
		{

			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store, &iter, NOM, c.nom, PRENOM, c.prenom, CIN, c.cin, ADRESSE, c.adresse, EMAIL, c.email, NUMERO, c.numero, IDENTIFIANT, c.identifiant, DATE, c.dt, SEXE, c.sexe, ACHAT, c.achat, -1);
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(KLtreeview), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
}

//******************************************************************************************************************************************************************************//

void ajout(CLIENT c)

{

	FILE *f;
	sprintf(c.dt, "%d/%d/%d", c.d.jour, c.d.mois, c.d.annee);
	f = fopen("client.txt", "a+");

	if (f != NULL)
	{
		fprintf(f, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat);
		fclose(f);
	}
}

//******************************************************************************************************************************************************************************//

void suppression(char g[30])
{
	CLIENT c;
	FILE *f, *F;

	f = fopen("client.txt", "a+");
	F = fopen("tmp.txt", "a+");

	if ((f == NULL) || (F == NULL))
	{
		return;
	}
	else
	{
		while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat) != EOF)
		{
			if (strcmp(c.identifiant, g) != 0)

				fprintf(F, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat);
		}
	}
	fclose(f);
	fclose(F);
	remove("client.txt");
	rename("tmp.txt", "client.txt");
}

//******************************************************************************************************************************************************************************//

void modification(char id[30], CLIENT c)
{

	CLIENT u;
	FILE *f1 = NULL, *f = NULL;
	sprintf(c.dt, "%d/%d/%d", c.d.jour, c.d.mois, c.d.annee);
	sprintf(u.dt, "%d/%d/%d", u.d.jour, u.d.mois, u.d.annee);
	f = fopen("client.txt", "r");
	f1 = fopen("tmp.txt", "w");
	if ((f != NULL) && (f1 != NULL))
	{
		while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s\n", u.nom, u.prenom, u.cin, u.adresse, u.email, u.numero, u.identifiant, u.dt, u.sexe, u.achat) != EOF)
		{
			if (strcmp(id, u.identifiant) != 0)
			{
				fprintf(f1, "%s %s %s %s %s %s %s %s %s %s\n", u.nom, u.prenom, u.cin, u.adresse, u.email, u.numero, u.identifiant, u.dt, u.sexe, u.achat);
			}
			else
			{
				fprintf(f1, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat);
			}
		}
	}
	fclose(f);
	fclose(f1);
	remove("client.txt");
	rename("tmp.txt", "client.txt");
}

//******************************************************************************************************************************************************************************//

void recherche(GtkWidget *KLtreeview)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	CLIENT c;
	store = NULL;
	FILE *f2;
	store = gtk_tree_view_get_model(KLtreeview);
	if (store == NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text", NOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text", PRENOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text", CIN, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("adresse", renderer, "text", ADRESSE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("email", renderer, "text", EMAIL, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("numero", renderer, "text", NUMERO, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text", IDENTIFIANT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("date", renderer, "text", DATE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text", SEXE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);

                renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("achat", renderer, "text", ACHAT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(KLtreeview), column);
	}

	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
	f2 = fopen("recherche.txt", "r");
	if (f2 == NULL)
	{
		return;
	}
	else
	{
		f2 = fopen("recherche.txt", "a+");
		while (fscanf(f2, "%s %s %s %s %s %s %s %s %s %s\n", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.achat) != EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store, &iter, NOM, c.nom, PRENOM, c.prenom, CIN, c.cin, ADRESSE, c.adresse, EMAIL, c.email, NUMERO, c.numero, IDENTIFIANT, c.identifiant, DATE, c.dt, SEXE, c.sexe, ACHAT, c.achat, -1);
		}
		fclose(f2);
		gtk_tree_view_set_model(GTK_TREE_VIEW(KLtreeview), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
}

//******************************************************************************************************************************************************************************//


int verifid(char id[30]) {
CLIENT c;
int val=1;
FILE* f;
f = fopen("client.txt", "a+");
if(f!=NULL){
      while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s", c.nom, c.prenom, c.cin, c.adresse, c.email, c.numero, c.identifiant, c.dt, c.sexe, c.sexe) != EOF)
      {
if(strcmp(id,c.identifiant)==0)
{
   val=0;
}
else{val=1;}
    }
    }
fclose(f);
return val;
}
//******************************************************************************************************************************************************************************//

int vide(GtkWidget *entry)
{
char id[30];
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(id,"")==0)return 0;
else return 1;
}



