#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "plante.h"
#include <gtk/gtk.h>
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	EID,
	ETYPE,
	ESTOCK,
	ERECOLTEE,
	EPLANTATION,
	ERECOLTE,
	COLUMNS
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ajouter(PLANTE p)

{
	FILE *f;
	f = fopen("plantations.txt", "a+");
	if (f != NULL)
	{
		fprintf(f, "%s %s %d %s %d/%d/%d %d/%d/%d\n", p.id, p.type, p.stock, p.recoltee, p.plantation.jour, p.plantation.mois, p.plantation.annee, p.recolte.jour, p.recolte.mois, p.recolte.annee);
		fclose(f);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////
void Recherche(char ref[20], GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char date1[20], date2[20], stock1[20];

	PLANTE p;
	store = NULL;

	FILE *f;
	gtk_list_store_clear(liste);
	store = gtk_tree_view_get_model(liste);
	if (store == NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Plante id ", renderer, "text", EID, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("     Type     ", renderer, "text", ETYPE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Stock (kg)", renderer, "text", ESTOCK, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Recolte (kg)", renderer, "text", ERECOLTEE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Date de plantation", renderer, "text", EPLANTATION, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Date de recolte", renderer, "text", ERECOLTE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	}
	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f = fopen("plantations.txt", "r");
	if (f == NULL)
	{
		return;
	}
	else
	{
		//f = fopen("plantations.txt", "a+");
		while (fscanf(f, "%s %s %s %s %s %s\n", p.id, p.type, stock1, p.recoltee, date1, date2) != EOF)

		{
			if (strcmp(p.id, ref) == 0)
			{
				gtk_list_store_append(store, &iter);
				gtk_list_store_set(store, &iter, EID, p.id, ETYPE, p.type, ESTOCK, p.recoltee, ERECOLTEE, stock1, EPLANTATION, date1, ERECOLTE, date2, -1);
			}
		}
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
	fclose(f);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
void affichage(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char date1[20], date2[20], stock1[20];

	PLANTE p;
	store = NULL;

	gtk_list_store_clear(liste);
	FILE *f = NULL;
	store = gtk_tree_view_get_model(liste);
	if (store == NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Plante id ", renderer, "text", EID, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("     Type     ", renderer, "text", ETYPE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Stock (kg)", renderer, "text", ESTOCK, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Recolte (kg)", renderer, "text", ERECOLTEE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Date de plantation", renderer, "text", EPLANTATION, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" Date de recolte", renderer, "text", ERECOLTE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	}
	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f = fopen("plantations.txt", "r");
	if (f == NULL)
	{
		return;
	}
	else
	{
		
		while (fscanf(f, "%s %s %s %s %s %s\n", p.id, p.type, stock1, p.recoltee, date1, date2) != EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store, &iter, EID, p.id, ETYPE, p.type, ESTOCK, p.recoltee, ERECOLTEE, stock1, EPLANTATION, date1, ERECOLTE, date2, -1);
		}

		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
	fclose(f);
}
//////////////////////////////////////////////////////////////////////////////////////////////
void suppression(char ref[20])
{

	PLANTE p;
	FILE *f, *F;

	f = fopen("plantations.txt", "r");
	F = fopen("tmp.txt", "w");

	if ((f == NULL) || (F == NULL))
		return;
	else
	{
		while (fscanf(f, "%s %s %d %s %d/%d/%d %d/%d/%d\n", p.id, p.type, &p.stock, p.recoltee, &p.plantation.jour, &p.plantation.mois, &p.plantation.annee, &p.recolte.jour, &p.recolte.mois, &p.recolte.annee) != EOF)
		{
			if (strcmp(ref, p.id) != 0)
			{
				fprintf(F, "%s %s %d %s %d/%d/%d %d/%d/%d\n", p.id, p.type, p.stock, p.recoltee, p.plantation.jour, p.plantation.mois, p.plantation.annee, p.recolte.jour, p.recolte.mois, p.recolte.annee);
			}
		}
		fclose(f);
		fclose(F);
		remove("plantations.txt");
		rename("tmp.txt", "plantations.txt");
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modification(char ref[20], PLANTE p)
{
	PLANTE u;
	FILE *f1 = NULL, *f = NULL;
	sprintf(p.dtpl, "%d/%d/%d", p.plantation.jour, p.plantation.mois, p.plantation.annee);
	sprintf(p.dtrec, "%d/%d/%d", p.recolte.jour, p.recolte.mois, p.recolte.annee);
	f = fopen("plantations.txt", "r");
	f1 = fopen("tmp.txt", "w");
	if ((f != NULL) && (f1 != NULL))
	{
		while (fscanf(f, "%s %s %d %s %s %s\n", u.id, u.type, &u.stock, u.recoltee, u.dtpl, u.dtrec) != EOF)
		{
			if (strcmp(ref, u.id) != 0)
			{
				fprintf(f1, "%s %s %d %s %s %s\n", u.id, u.type, u.stock, u.recoltee, u.dtpl, u.dtrec);
			}
			else
			{
				fprintf(f1, "%s %s %d %s %s %s\n", p.id, p.type, p.stock, p.recoltee, p.dtpl, p.dtrec);
			}
		}
	}
	fclose(f);
	fclose(f1);
	remove("plantations.txt");
	rename("tmp.txt", "plantations.txt");
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int verifier(char ref[20])
{
	PLANTE p;
	char date1[20], date2[20], stock1[20];
	int test = 0;
	FILE *f1;
	f1 = fopen("plantations.txt", "a+");
	if (f1 != NULL)
	{
		while (fscanf(f1, "%s %s %s %s %s %s\n", p.id, p.type, stock1, p.recoltee, date1, date2) != EOF)
		{
			if ((strcmp(ref, p.id) == 0))
			{
				test = 1;
			}
		}
		fclose(f1);
	}
	return test;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int boardplantation (PLANTE p){
FILE *f;
int indice,test;
int i,j,s,min;
int n=0;
int m[50][3];
for (i=0;i<50;i++)
{for(j=0;j<3;j++)
{	m[i][j]=0;
}}
f=fopen("plantations.txt","r+");
while(fscanf(f, "%s %s %d %s %d/%d/%d %d/%d/%d\n", p.id, p.type, &p.stock, p.recoltee, &p.plantation.jour, &p.plantation.mois, &p.plantation.annee, &p.recolte.jour, &p.recolte.mois, &p.recolte.annee) != EOF)
{
	indice=-1;
	test=0;
	i=0;
	while((i<=n)&&(test==0))
	{
		s=m[i][0];
		if(s==p.recolte.annee)
			{
			indice=i;
			test=1;
			}
		i++;
	}

	if(indice==-1)
	{
		n++;
		m[n-1][0]=p.recolte.annee;
		m[n-1][1]=p.stock;
	}
	else 
		{m[indice][1]+=p.stock;}
}
fclose(f);
min=0;
for(i=1;i<n;i++)
{
if(m[i][1]<m[min][1])
min=i;
}
return m[min][0];
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int roardplantation (PLANTE p){
FILE *f;
int indice,test;
int i,j,s,min;
int n=0;
int m[50][3];
for (i=0;i<50;i++)
{for(j=0;j<3;j++)
{	m[i][j]=0;
}}
f=fopen("plantations.txt","r+");
while(fscanf(f, "%s %s %d %s %d/%d/%d %d/%d/%d\n", p.id, p.type, &p.stock, p.recoltee, &p.plantation.jour, &p.plantation.mois, &p.plantation.annee, &p.recolte.jour, &p.recolte.mois, &p.recolte.annee) != EOF)
{
	indice=-1;
	test=0;
	i=0;
	while((i<=n)&&(test==0))
	{
		s=m[i][0];
		if(s==p.recolte.annee)
			{
			indice=i;
			test=1;
			}
		i++;
	}

	if(indice==-1)
	{
		n++;
		m[n-1][0]=p.recolte.annee;
		m[n-1][1]=p.stock;
	}
	else 
		{m[indice][1]+=p.stock;}
}
fclose(f);
min=0;
for(i=1;i<n;i++)
{
if(m[i][1]<m[min][1])
min=i;
}
return m[min][1];
}
