#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <string.h>
#include <gtk/gtk.h>
#include "plante.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
char gid[50];
char gtype[50], gstock[50], grecolte[50], gdtpl[50], gdtrec[50];
//////////////////////////////////////////////////////////////////////////////////////////////////////
void on_treeview1_row_activated(GtkTreeView *treeview1,
                                GtkTreePath *path,
                                GtkTreeViewColumn *column,
                                gpointer user_data)
{
  PLANTE p;
  GtkTreeIter iter;
  gchar *ID;
  gchar *TYPE;
  gchar *RECOLTE;
  gchar *STOCK;
  gchar *DTPL;
  gchar *DTREC;

  GtkWidget *window_calendrier = lookup_widget(treeview1, "window_calendrier");
  GtkTreeModel *model = gtk_tree_view_get_model(treeview1);
  if (gtk_tree_model_get_iter(model, &iter, path))
  {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &ID, 1, &TYPE, 2, &STOCK, 3, &RECOLTE, 4, &DTPL, 5, &DTREC, -1);
    strcpy(gid, ID);
    strcpy(gtype, TYPE);
    strcpy(gstock, STOCK);
    strcpy(grecolte, RECOLTE);
    strcpy(gdtpl, DTPL);
    strcpy(gdtrec, DTREC);
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void on_Supprimer_clicked(GtkButton *button,
                          gpointer user_data)
{
GtkWidget* p ,*afficher,*w1,*pQuestion;
afficher = lookup_widget(button, "window_calendrier");
GtkWidget  *treeview1 = lookup_widget(afficher, "treeview1");

pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cet plante ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

  suppression(gid);
	gtk_widget_destroy(pQuestion);
  affichage(treeview1);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void on_actualiser_clicked(GtkButton *button,
                           gpointer user_data)
{
  GtkWidget *fenetre_afficher;
  GtkWidget *treeview1;
  fenetre_afficher = lookup_widget(button, "window_calendrier");
  treeview1 = lookup_widget(fenetre_afficher, "treeview1");
  gtk_widget_show(fenetre_afficher);
  affichage(treeview1);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void on_rechercher_clicked(GtkButton *button,
                           gpointer user_data)
{
  GtkWidget *treeview, *recherche_plante, *fenetre_afficher;
  char ref[10];
  GtkWidget *control=lookup_widget(button,"Search");
  treeview = lookup_widget(button, "treeview1");
  recherche_plante = lookup_widget(button, "entry10");
	if((is_empty(recherche_plante)==0)  )
	{
		
gtk_label_set_markup(control,"<span foreground='red'><b>Champ manquant!!</b></span>");

	}
	else {
gtk_label_set_text(GTK_LABEL(control)," ");
  strcpy(ref, gtk_entry_get_text(GTK_ENTRY(recherche_plante)));
    Recherche(ref, treeview);}
  
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void on_Ajouter_clicked(GtkWidget *button,
                        gpointer user_data)
{
  PLANTE p;
  int cond1;
  GtkWidget *controld1=lookup_widget(button,"control1");
  GtkWidget *dialog;
  GtkWidget *input1, *input2;
  GtkWidget *ajout;
  GtkWidget *choix1, *choix2, *choix3, *choix4;
  GtkWidget *jour1, *mois1, *annee1;
  GtkWidget *jour2, *mois2, *annee2;
  GtkWidget *stock;

  choix1 = lookup_widget(button, "choix1");
  choix2 = lookup_widget(button, "choix2");
  choix3 = lookup_widget(button, "choix3");
  choix4 = lookup_widget(button, "choix4");
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix1)) == TRUE)
  {
    strcpy(p.type, "tomate");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix2)) == TRUE)
  {
    strcpy(p.type, "pomme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix3)) == TRUE)
  {
    strcpy(p.type, "fraise");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(choix4)) == TRUE)
  {
    strcpy(p.type, "avocat");
  }

  input2 = lookup_widget(button, "entry11");
  input1 = lookup_widget(button, "entryid");
  stock = lookup_widget(button, "spinbutton1");

  jour1 = lookup_widget(button, "jour1");
  mois1 = lookup_widget(button, "mois1");
  annee1 = lookup_widget(button, "annee1");

  jour2 = lookup_widget(button, "jour2");
  mois2 = lookup_widget(button, "mois2");
  annee2 = lookup_widget(button, "annee2");

  strcpy(p.recoltee, gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(p.id, gtk_entry_get_text(GTK_ENTRY(input1)));
  p.stock = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(stock));

  p.plantation.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
  p.plantation.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
  p.plantation.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));

  p.recolte.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour2));
  p.recolte.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois2));
  p.recolte.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee2));

	cond1=verifier(p.id);
if((is_empty(input1)==0) || (is_empty(input2)==0))
{

	gtk_label_set_markup(controld1,"<span foreground='red'><b>Remplir tous les champs SVP !!</b></span>");
}

else if((p.plantation.jour >= 32) || (p.plantation.mois >= 13) ||  (p.plantation.annee >= 2099) || (p.recolte.jour >= 32) || (p.recolte.mois >= 13) ||  (p.recolte.annee >= 2099)){

	gtk_label_set_markup(controld1,"<span foreground='red'><b>Format date invalide!!</b></span>");
}
else if (cond1==1){
	gtk_label_set_markup(controld1,"<span foreground='red'><b>Id déjà existant !</b></span>");}
else {
gtk_label_set_text(GTK_LABEL(controld1)," ");
  ajouter(p);
  dialog = create_dialog1();
  gtk_widget_show(dialog);}
}
////////////////////////////////////////////////////////////////////////////////
void on_retour_clicked(GtkButton *button,
                       gpointer user_data)
{
  GtkWidget *ajoutedate, *calendrier;

  ajoutedate = lookup_widget(button, "window_calendrier");
  gtk_widget_destroy(ajoutedate);

  calendrier = create_window_calendrier();
  gtk_widget_show(calendrier);
}

/////////////////////////////////////////////////////////////////////////////

void on_modifier_clicked(GtkButton *button,
                         gpointer user_data)
{
 PLANTE p;
  GtkWidget *ID;
  GtkWidget *TOMATE,*POMME,*FRAISE,*AVOCAT;
  GtkWidget *STOCK;
  GtkWidget *RECOLTE;
  GtkWidget *J1, *M1, *A1;
  GtkWidget *J2, *M2, *A2;
gchar *id;
gchar *type;
GtkTreeSelection *selection;
GtkTreeModel     *model;
GtkTreeIter iter;
gchar *stock,*recoltee,*plantation,*recolte;
  GtkWidget *window_calendrier = lookup_widget(button, "window_calendrier");
  GtkWidget *dialog4 = lookup_widget(button, "dialog4");
  dialog4 = create_dialog4();
  gtk_widget_show(dialog4);
GtkWidget *treeview; 
  ID = lookup_widget(dialog4, "entrymid");

treeview=lookup_widget(button,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        { 

gtk_tree_model_get ((model),&iter,0,&id,1,&type,2,&stock,3,plantation,4,recolte,-1);
strcpy(p.type,type);
  
  ID = lookup_widget(dialog4, "entrymid");
  STOCK = lookup_widget(dialog4, "mstock");
  RECOLTE = lookup_widget(dialog4, "entrymrecolte");

  J1 = lookup_widget(dialog4, "mjour1");
  M1 = lookup_widget(dialog4, "mmois1");
  A1 = lookup_widget(dialog4, "mannee1");
  J2 = lookup_widget(dialog4, "mjour2");
  M2 = lookup_widget(dialog4, "mmois2");
  A2 = lookup_widget(dialog4, "mannee2");
TOMATE= lookup_widget(dialog4,"tomate");
POMME= lookup_widget(dialog4,"pomme");
FRAISE= lookup_widget(dialog4,"fraise");
AVOCAT= lookup_widget(dialog4,"avocat");

if ((strcmp(p.type, "tomate") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 0);
    }
    else if ((strcmp(p.type, "pomme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 0);
    }
    else if ((strcmp(p.type, "fraise") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 0);
    }
    else if ((strcmp(p.type, "avocat") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(TOMATE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(POMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FRAISE), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AVOCAT), 1);
    }

  sscanf(grecolte, "%d", &p.stock);
  sscanf(gdtpl, "%d/%d/%d", &p.plantation.jour, &p.plantation.mois, &p.plantation.annee);
  sscanf(gdtrec, "%d/%d/%d", &p.recolte.jour, &p.recolte.mois, &p.recolte.annee);
  gtk_entry_set_text(GTK_ENTRY(ID), gid);
  gtk_entry_set_text(GTK_ENTRY(RECOLTE), gstock);
  gtk_entry_set_text(GTK_ENTRY(STOCK),grecolte);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(STOCK), p.stock);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(J1), p.plantation.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(M1), p.plantation.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(A1), p.plantation.annee);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(J2), p.recolte.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(M2), p.recolte.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(A2), p.recolte.annee);
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////
void on_sauvegarder_clicked(GtkButton *button,
                            gpointer user_data)
{
  
  PLANTE p;
  gchar *type;
  GtkWidget *ID;
  GtkWidget *STOCK,*RECOLTE;
  GtkWidget *TOMATE,*POMME,*FRAISE,*AVOCAT;
  GtkWidget *J1, *M1, *A1;
  GtkWidget *J2, *M2, *A2;
  GtkWidget *dialog4 = lookup_widget(button, "dialog4");
  GtkWidget *dialog;

  ID = lookup_widget(button, "entrymid");
  STOCK = lookup_widget(button, "mstock");
  RECOLTE = lookup_widget(button, "entrymrecolte");

  J1 = lookup_widget(button, "mjour1");
  M1 = lookup_widget(button, "mmois1");
  A1 = lookup_widget(button, "mannee1");
  J2 = lookup_widget(button, "mjour2");
  M2 = lookup_widget(button, "mmois2");
  A2 = lookup_widget(button, "mannee2");


   strcpy(p.id, gtk_entry_get_text(GTK_ENTRY(ID)));
  strcpy(p.recoltee, gtk_entry_get_text(GTK_ENTRY(RECOLTE)));
  gtk_entry_set_text(GTK_ENTRY(RECOLTE), grecolte);

TOMATE= lookup_widget(button,"tomate");
POMME= lookup_widget(button,"pomme");
FRAISE= lookup_widget(button,"fraise");
AVOCAT= lookup_widget(button,"avocat");

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(TOMATE)) == TRUE)
  {
    strcpy(p.type, "tomate");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(POMME)) == TRUE)
  {
    strcpy(p.type, "pomme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(FRAISE)) == TRUE)
  {
    strcpy(p.type, "fraise");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(AVOCAT)) == TRUE)
  {
    strcpy(p.type, "avocat");
  }

  p.stock = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(STOCK));
  p.plantation.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(J1));
  p.plantation.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(M1));
  p.plantation.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(A1));

  p.recolte.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(J2));
  p.recolte.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(M2));
  p.recolte.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(A2));
  modification(p.id, p);
	gtk_widget_hide(dialog4);
  dialog = create_dialog2();
  gtk_widget_show(dialog);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_aps_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
char ch1[50],ch2[50];
int year;
int rct;
year=boardplantation (p);
rct=roardplantation (p);

GtkWidget *window=lookup_widget(button,"window_calendrier");

GtkWidget *message1=lookup_widget(window,"labelapsA");
GtkWidget *message2=lookup_widget(window,"labelapsR");

sprintf(ch1,"l'annee la plus seche est = %d",year);
gtk_label_set_text(GTK_LABEL(message1),ch1);

sprintf(ch2,"avec un total de recolte = %d (kg)",rct);
gtk_label_set_text(GTK_LABEL(message2),ch2);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
