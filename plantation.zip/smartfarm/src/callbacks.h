#include <gtk/gtk.h>

void on_treeview1_row_activated(GtkTreeView *treeview1,
                                GtkTreePath *path,
                                GtkTreeViewColumn *column,
                                gpointer user_data);

void on_Supprimer_clicked(GtkButton *button,
                          gpointer user_data);

void on_actualiser_clicked(GtkButton *button,
                           gpointer user_data);

void on_rechercher_clicked(GtkButton *button,
                           gpointer user_data);

void on_Ajouter_clicked(GtkWidget *button,
                        gpointer user_data);

void on_retour_clicked(GtkButton *button,
                       gpointer user_data);

void on_ok1_activate(GtkButton *button,
                     gpointer user_data);

void on_ok2_clicked(GtkButton *button,
                    gpointer user_data);

void on_ok3_clicked(GtkButton *button,
                    gpointer user_data);

void on_modifier_clicked(GtkButton *button,
                         gpointer user_data);

void on_sauvegarder_clicked(GtkButton *button,
                            gpointer user_data);

void
on_aps_clicked                         (GtkButton       *button,
                                        gpointer         user_data);
